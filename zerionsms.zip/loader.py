import telebot
import logging
from config import TOKEN, DB_PATH
import sqlite3
import os

# Logging setup
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Bot init
bot = telebot.TeleBot(TOKEN)

# DB Init function
def init_db():
    if not os.path.exists(os.path.dirname(DB_PATH)):
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    c = conn.cursor()
    
    # Users table
    # Categories (Hosting, VPS, Dedicated)
    c.execute('''CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name_uz TEXT,
        name_ru TEXT,
        name_en TEXT,
        code TEXT UNIQUE -- hosting, vps, dedicated
    )''')

    # Locations
    c.execute('''CREATE TABLE IF NOT EXISTS locations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        flag_emoji TEXT,
        code TEXT UNIQUE
    )''')

    # OS Templates (Ubuntu, Windows...)
    c.execute('''CREATE TABLE IF NOT EXISTS os_templates (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        version TEXT,
        type TEXT -- linux, windows
    )''')

    # Users table
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        full_name TEXT,
        username TEXT,
        balance REAL DEFAULT 0,
        joined_at TEXT,
        language TEXT DEFAULT 'uz'
    )''')
    
    # Check/Migrate users table (Keep existing migration logic)
    try:
        c.execute("PRAGMA table_info(users)")
        columns = [info[1] for info in c.fetchall()]
        
        if 'language' not in columns:
            c.execute("ALTER TABLE users ADD COLUMN language TEXT DEFAULT 'uz'")
        if 'full_name' not in columns:
            c.execute("ALTER TABLE users ADD COLUMN full_name TEXT")
        if 'username' not in columns:
            c.execute("ALTER TABLE users ADD COLUMN username TEXT")
        if 'balance' not in columns:
            c.execute("ALTER TABLE users ADD COLUMN balance REAL DEFAULT 0")
        if 'joined_at' not in columns:
            c.execute("ALTER TABLE users ADD COLUMN joined_at TEXT")
    except Exception as e:
        logger.error(f"Error during schema migration: {e}")
    
    # Payments table
    c.execute('''CREATE TABLE IF NOT EXISTS payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        amount REAL,
        photo_id TEXT,
        status TEXT DEFAULT 'pending', 
        date TEXT
    )''')
    
    # Plans table (Expanded)
    c.execute('''CREATE TABLE IF NOT EXISTS plans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category_code TEXT, -- hosting, vps, dedicated
        name TEXT,
        size_gb INTEGER,
        price_monthly REAL,
        ram_limit_mb INTEGER,
        cpu_limit_percent INTEGER,
        is_active BOOLEAN DEFAULT 1,
        description TEXT
    )''')
    
    # Migrate plans table if missing columns
    try:
        c.execute("PRAGMA table_info(plans)")
        plan_cols = [info[1] for info in c.fetchall()]
        if 'category_code' not in plan_cols:
            c.execute("ALTER TABLE plans ADD COLUMN category_code TEXT DEFAULT 'hosting'")
        if 'description' not in plan_cols:
            c.execute("ALTER TABLE plans ADD COLUMN description TEXT")
    except: pass

    # Hosts table
    c.execute('''CREATE TABLE IF NOT EXISTS hosts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        plan_id INTEGER,
        path_id TEXT UNIQUE,
        expiry_date TEXT,
        is_active BOOLEAN DEFAULT 1,
        is_privileged BOOLEAN DEFAULT 0,
        location_id INTEGER,
        os_id INTEGER,
        FOREIGN KEY(user_id) REFERENCES users(user_id)
    )''')
    
    # Migrate hosts table
    try:
        c.execute("PRAGMA table_info(hosts)")
        host_cols = [info[1] for info in c.fetchall()]
        if 'location_id' not in host_cols:
            c.execute("ALTER TABLE hosts ADD COLUMN location_id INTEGER")
        if 'os_id' not in host_cols:
            c.execute("ALTER TABLE hosts ADD COLUMN os_id INTEGER")
    except: pass

    # Files table
    c.execute('''CREATE TABLE IF NOT EXISTS user_files (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        file_name TEXT,
        file_type TEXT, 
        upload_date TEXT
    )''')

    # Tickets
    c.execute('''CREATE TABLE IF NOT EXISTS tickets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        subject TEXT,
        status TEXT DEFAULT 'open', -- open, answered, closed
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )''')

    # Ticket Messages
    c.execute('''CREATE TABLE IF NOT EXISTS ticket_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ticket_id INTEGER,
        sender_id INTEGER, -- user_id or admin_id
        text TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )''')

    # Seed Default Data
    c.execute('SELECT count(*) FROM categories')
    if c.fetchone()[0] == 0:
        cats = [
            ('Python Hosting', 'Python Хостинг', 'Python Hosting', 'hosting'),
            ('VPS Server', 'VPS Сервер', 'VPS Server', 'vps'),
            ('Dedicated Server', 'Выделенный Сервер', 'Dedicated Server', 'dedicated')
        ]
        c.executemany('INSERT INTO categories (name_uz, name_ru, name_en, code) VALUES (?, ?, ?, ?)', cats)

    c.execute('SELECT count(*) FROM locations')
    if c.fetchone()[0] == 0:
        locs = [
            ('Uzbekistan', '🇺🇿', 'uz'),
            ('Germany', '🇩🇪', 'de'),
            ('USA', '🇺🇸', 'us')
        ]
        c.executemany('INSERT INTO locations (name, flag_emoji, code) VALUES (?, ?, ?)', locs)
        
    c.execute('SELECT count(*) FROM os_templates')
    if c.fetchone()[0] == 0:
        oss = [
            ('Ubuntu 22.04', '22.04', 'linux'),
            ('CentOS 9', '9', 'linux'),
            ('Windows Server 2022', '2022', 'windows')
        ]
        c.executemany('INSERT INTO os_templates (name, version, type) VALUES (?, ?, ?)', oss)

    # Default Plans (Update existing/Insert new)
    # We won't delete existing plans, but ensure we have at least some for new categories
    # Reset and Seed Plans
    c.execute("SELECT count(*) FROM plans")
    if c.fetchone()[0] < 5: # If fewer than our standard set, assume we need to seed/reset
        # Clear old plans to clean up
        c.execute("DELETE FROM plans")
        
        # New Standard Plans
        default_plans = [
             # category, name, size_gb, price, ram, cpu, active, desc
             ('hosting', 'Python Mini', 1, 15000, 512, 10, 1, '1GB SSD, 512MB RAM, Python Support'),
             ('hosting', 'Python Standard', 5, 30000, 1024, 25, 1, '5GB SSD, 1GB RAM, High Performance'),
             ('vps', 'VPS Start', 20, 60000, 2048, 100, 1, '2GB RAM, 1 Core, 20GB NVMe'),
             ('vps', 'VPS Pro', 40, 110000, 4096, 200, 1, '4GB RAM, 2 Core, 40GB NVMe'),
             ('vps', 'VPS Max', 80, 200000, 8192, 400, 1, '8GB RAM, 4 Core, 80GB NVMe')
        ]
        
        c.executemany('''INSERT INTO plans 
                         (category_code, name, size_gb, price_monthly, ram_limit_mb, cpu_limit_percent, is_active, description) 
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?)''', default_plans)

    conn.commit()
    return conn

# Global DB Connection
db_conn = init_db()
