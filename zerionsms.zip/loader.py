import telebot
import logging
from config import TOKEN, DB_PATH
import sqlite3
import os

# Logging setup
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Bot init
bot = telebot.TeleBot(TOKEN)

# DB Init function
def init_db():
    if not os.path.exists(os.path.dirname(DB_PATH)):
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    c = conn.cursor()
    
    # Users table
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        full_name TEXT,
        username TEXT,
        balance REAL DEFAULT 0,
        joined_at TEXT,
        language TEXT DEFAULT 'uz'
    )''')
    
    # Check/Migrate users table
    try:
        c.execute("PRAGMA table_info(users)")
        columns = [info[1] for info in c.fetchall()]
        
        if 'language' not in columns:
            c.execute("ALTER TABLE users ADD COLUMN language TEXT DEFAULT 'uz'")
            logger.info("Added missing column 'language' to users table.")
            
        if 'full_name' not in columns:
            c.execute("ALTER TABLE users ADD COLUMN full_name TEXT")
            logger.info("Added missing column 'full_name' to users table.")
            
        if 'username' not in columns:
            c.execute("ALTER TABLE users ADD COLUMN username TEXT")
            logger.info("Added missing column 'username' to users table.")
            
        if 'balance' not in columns:
            c.execute("ALTER TABLE users ADD COLUMN balance REAL DEFAULT 0")
            logger.info("Added missing column 'balance' to users table.")

        if 'joined_at' not in columns:
            c.execute("ALTER TABLE users ADD COLUMN joined_at TEXT")
            logger.info("Added missing column 'joined_at' to users table.")

    except Exception as e:
        logger.error(f"Error during schema migration: {e}")
    
    # Payments table (Check/Receipts)
    c.execute('''CREATE TABLE IF NOT EXISTS payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        amount REAL,
        photo_id TEXT,
        status TEXT DEFAULT 'pending', -- pending, approved, rejected
        date TEXT
    )''')
    
    # Plans table (Hosting Rejalari)
    c.execute('''CREATE TABLE IF NOT EXISTS plans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        size_gb INTEGER,
        price_monthly REAL,
        ram_limit_mb INTEGER,
        cpu_limit_percent INTEGER,
        is_active BOOLEAN DEFAULT 1
    )''')
    
    # Hosts table (Active Purchases)
    c.execute('''CREATE TABLE IF NOT EXISTS hosts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        plan_id INTEGER,
        path_id TEXT UNIQUE,
        expiry_date TEXT,
        is_active BOOLEAN DEFAULT 1,
        is_privileged BOOLEAN DEFAULT 0, -- Root permission
        FOREIGN KEY(user_id) REFERENCES users(user_id)
    )''')
    
    # Files table (User uploaded files tracking)
    c.execute('''CREATE TABLE IF NOT EXISTS user_files (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        file_name TEXT,
        file_type TEXT, -- py, js, zip
        upload_date TEXT
    )''')

    # Default Plans
    c.execute('SELECT count(*) FROM plans')
    if c.fetchone()[0] == 0:
        plans = [
             ('Boshlangich 5GB', 5, 10000, 512, 50),
             ('Professional 10GB', 10, 18000, 1024, 80),
             ('Biznes 20GB', 20, 35000, 2048, 100),
             ('Elite 50GB', 50, 80000, 4096, 200),
             ('Ultra 100GB', 100, 150000, 8192, 400)
        ]
        c.executemany('INSERT INTO plans (name, size_gb, price_monthly, ram_limit_mb, cpu_limit_percent) VALUES (?, ?, ?, ?, ?)', plans)

    conn.commit()
    return conn

# Global DB Connection
db_conn = init_db()
