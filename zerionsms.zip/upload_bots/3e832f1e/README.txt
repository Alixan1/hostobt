Welcome to your VPS space!
You can run python scripts here.