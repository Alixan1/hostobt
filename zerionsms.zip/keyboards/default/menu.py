from telebot.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from utils.locales import get_text

def main_menu_inline(is_admin=False, lang='uz'):
    markup = InlineKeyboardMarkup(row_width=2)
    
    markup.add(
        InlineKeyboardButton(get_text('my_hosts', lang), callback_data="my_hosts"),
        InlineKeyboardButton(get_text('balance', lang), callback_data="balance")
    )
    markup.add(
        InlineKeyboardButton(get_text('buy_host', lang), callback_data="buy_host"),
        InlineKeyboardButton(get_text('settings', lang), callback_data="settings")
    )
    markup.add(
        InlineKeyboardButton(get_text('help', lang), callback_data="help_support"),
        InlineKeyboardButton(get_text('referral', lang), callback_data="referral")
    )

    if is_admin:
        markup.add(InlineKeyboardButton(get_text('admin_panel', lang), callback_data="admin_panel_entry"))
        
    return markup

def admin_panel_kb(lang='uz'):
    markup = InlineKeyboardMarkup(row_width=2)
    markup.add(
        InlineKeyboardButton("👥 Users", callback_data="admin_users"),
        InlineKeyboardButton("📊 Stats", callback_data="admin_stats"),
        InlineKeyboardButton("🏷 Plans", callback_data="admin_plans"),
        InlineKeyboardButton("📢 Broadcast", callback_data="admin_broadcast"),
        InlineKeyboardButton("➕ Give Balance", callback_data="admin_give_balance"),
        InlineKeyboardButton("✅ Payments", callback_data="admin_payments"),
        InlineKeyboardButton("🔑 Active Hosts", callback_data="admin_all_hosts"),
        InlineKeyboardButton("📦 Products (VPS/Host)", callback_data="admin_products"),
        InlineKeyboardButton("🔓 Grant Root (ID)", callback_data="admin_grant_root") # New
    )
    return markup

def hosts_list_kb(hosts, lang='uz'):
    markup = InlineKeyboardMarkup(row_width=1)
    if not hosts:
        return markup
    for host_id, name, is_active in hosts:
        status_icon = "🟢" if is_active else "🔴"
        markup.add(InlineKeyboardButton(f"{status_icon} {name}", callback_data=f"host_{host_id}"))
    return markup

def host_control_kb(host_id, is_running, lang='uz'):
    markup = InlineKeyboardMarkup(row_width=2)
    
    run_text = get_text('host_running', lang) if is_running else "🟢 Start" # Simple fallback
    stop_text = "🔴 Stop"
    restart_text = "🔄 Restart"
    
    if is_running:
        markup.add(InlineKeyboardButton(stop_text, callback_data=f"stop_{host_id}"),
                   InlineKeyboardButton(restart_text, callback_data=f"restart_{host_id}"))
    else:
        markup.add(InlineKeyboardButton(run_text, callback_data=f"start_{host_id}"))
    
    markup.add(
        InlineKeyboardButton("📂 Files", callback_data=f"files_{host_id}"),
        InlineKeyboardButton("💻 Terminal", callback_data=f"term_{host_id}")
    )
    markup.add(
        InlineKeyboardButton("📜 Logs", callback_data=f"logs_{host_id}"),
        InlineKeyboardButton("⬆️ Upload", callback_data=f"upload_{host_id}")
    )
    markup.add(InlineKeyboardButton("🔙 Back", callback_data="my_hosts"))
    return markup

def vps_control_kb(host_id, status, lang='uz'):
    # status: running, stopped, installing...
    markup = InlineKeyboardMarkup(row_width=2)
    
    if status == 'running':
        markup.add(InlineKeyboardButton("🔴 Stop", callback_data=f"vps_stop_{host_id}"),
                   InlineKeyboardButton("🔄 Reboot", callback_data=f"vps_reboot_{host_id}"))
    else:
        markup.add(InlineKeyboardButton("🟢 Start", callback_data=f"vps_start_{host_id}"))
    
    markup.add(
        InlineKeyboardButton("💾 Reinstall OS", callback_data=f"vps_reinstall_{host_id}"),
        InlineKeyboardButton("🔑 Root Pass", callback_data=f"vps_root_{host_id}")
    )
    markup.add(
        InlineKeyboardButton("📂 Files", callback_data=f"files_{host_id}"),
        InlineKeyboardButton("⬆️ Upload", callback_data=f"upload_{host_id}")
    )
    markup.add(
         InlineKeyboardButton("💻 Terminal", callback_data=f"term_{host_id}"),
         InlineKeyboardButton("📊 Monitor", callback_data=f"vps_monitor_{host_id}")
    )
    markup.add(InlineKeyboardButton("🔙 Back", callback_data="my_hosts"))
    return markup
