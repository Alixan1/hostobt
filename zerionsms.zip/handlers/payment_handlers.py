# payment_handlers.py - Bu fayl endi user_handlers.py ichiga integratsiya qilindi
# Eski kodni saqlab qolamiz backup uchun lekin ishlatilmaydi

from aiogram import Router

router = Router()

# Barcha to'lov handlerlari user_handlers.py da amalga oshirildi
# Bu fayl bo'sh qoldirilgan
