﻿from aiogram import Router, F, types
from aiohttp import web
from database.db import get_db_connection
from utils.link_parser import LinkParser
import json
import logging

router = Router()
logger = logging.getLogger(__name__)

async def handle_create_ad_api(request):
    """WebApp dan HTTP POST orqali kelgan ma'lumotlarni qayta ishlash"""
    try:
        data = await request.json()
        logger.info(f"API API RECEIVED: {data}")
        
        # User ID authentication (simplified for now, ideally params validation)
        # We expect user_id in the payload
        user_id = data.get('user_id')
        try:
            user_id = int(str(user_id))
        except:
             return web.json_response({'error': 'User ID invalid'}, status=400)

        action = data.get("action")
        if action == "create_ad":
            text = data.get("text", "")
            interval_sec = int(data.get("interval", 30))
            # Method handling
            target_type = data.get("target_type") or data.get("method", "all")
            targets_raw = data.get("targets", "")
            photo_path = data.get("photo") # Extract photo path
            
            logger.info(f"Method: {target_type}, Targets: {targets_raw}, Photo: {photo_path}")
            
            if not text.strip() and not photo_path:
                return web.json_response({'error': 'Matn yoki rasm kiritilmagan'}, status=400)
            
            # Logic parser
            parser = LinkParser()
            valid_links = []
            
            if target_type == "manual":
                links = targets_raw.split('\n')
                for link in links:
                    link = link.strip()
                    if link:
                        valid_links.append(link) 
            elif target_type == "folder":
                # Folder ID. Ensure it's treated as string in DB
                pass 
            elif target_type == "all":
                pass
                
            # Final targets string
            if target_type == "all":
                parsed_targets = ""
            elif target_type == "folder":
                parsed_targets = str(targets_raw)
            else:
                parsed_targets = '\n'.join(valid_links)
            
            # Save to DB
            async with await get_db_connection() as db:
                await db.execute(
                    "INSERT INTO messages (user_id, text, photo_path, interval_sec, active, target_type, targets) VALUES (?,?,?,?,?,?,?)",
                    (user_id, text, photo_path, interval_sec, 1, target_type, parsed_targets)
                )
                await db.commit()
            
            # Notify user via Bot
            try:
                bot = request.app['bot']
                
                type_text = ""
                if target_type == "all":
                    type_text = "📁 Barcha guruhlar"
                elif target_type == "folder":
                    type_text = f"📂 Jild ID: {parsed_targets}"
                else:
                    count = len(valid_links)
                    type_text = f"📝 {count} ta kanal/guruh"
                    
                await bot.send_message(
                    user_id,
                    f"✅ <b>Reklama qo'shildi!</b>\n\n"
                    f"📝 Matn: {text[:30]}...\n"
                    f"⏱ Interval: {interval_sec} soniya\n"
                    f"🎯 Target: {type_text}\n"
                    f"🟢 Holat: Aktiv"
                )
            except Exception as e:
                logger.error(f"Failed to notify user: {e}")
                
            return web.json_response({'status': 'ok'})
            
        return web.json_response({'error': 'Unknown action'}, status=400)
            
    except Exception as e:
        logger.error(f"API Error: {e}", exc_info=True)
        return web.json_response({'error': str(e)}, status=500)
