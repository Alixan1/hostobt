from loader import bot, db_conn
from telebot.types import CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from utils.misc.process_manager import pm
from utils.db_api.sqlite import db
import os
from config import UPLOAD_DIR

@bot.callback_query_handler(func=lambda call: call.data.startswith(('approve_run_', 'reject_run_')))
def admin_approval_decision(call: CallbackQuery):
    action, _, host_id, user_id = call.data.split('_') # approve_run_12_5678
    host_id = int(host_id)
    user_id = int(user_id)
    
    host = db.get_host(host_id)
    if not host:
        bot.answer_callback_query(call.id, "Host topilmadi.")
        return

    # Userga va Adminga javob
    if action == 'approve':
        # Start script
        host_folder = os.path.join(UPLOAD_DIR, host[3])
        target_file = None
        if os.path.exists(host_folder):
            for f in os.listdir(host_folder):
                if f.endswith('.py') or f.endswith('.js'):
                    target_file = os.path.join(host_folder, f)
                    break
        
        if target_file:
            success, msg = pm.start_script(host_id, target_file)
            if success:
                bot.edit_message_text(f"✅ Host #{host_id} tasdiqlandi va ishga tushirildi.\nAdmin: {call.from_user.full_name}", 
                                      call.message.chat.id, call.message.message_id)
                bot.send_message(user_id, f"✅ Sizning Hosti #{host_id} Admin tomonidan tasdiqlandi va ishga tushdi!")
            else:
                bot.answer_callback_query(call.id, f"Xatolik: {msg}")
        else:
            bot.answer_callback_query(call.id, "Fayl topilmadi.")

    elif action == 'reject':
        bot.edit_message_text(f"❌ Host #{host_id} rad etildi.\nAdmin: {call.from_user.full_name}", 
                              call.message.chat.id, call.message.message_id)
        bot.send_message(user_id, f"❌ Sizning Hosti #{host_id} Admin tomonidan rad etildi.\nSabab: Xavfli kod yoki qoida buzilishi.")
