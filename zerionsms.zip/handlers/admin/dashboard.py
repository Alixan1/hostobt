from loader import bot
from telebot.types import Message, CallbackQuery
from keyboards.default.menu import admin_panel_kb
from config import ADMINS, OWNER_ID
from utils.locales import get_text
from utils.db_api.sqlite import db

@bot.message_handler(func=lambda message: message.text == "👑 Admin Panel" or message.text == "👑 Админ Панель")
def admin_panel_handler(message: Message):
    user_id = message.from_user.id
    if user_id not in ADMINS and user_id != OWNER_ID:
        bot.send_message(message.chat.id, "⛔ Siz admin emassiz!")
        return

    # Get language
    user = db.get_user(user_id)
    lang = user['language'] if user else 'uz'
    
    bot.send_message(message.chat.id, 
                     f"👑 <b>Admin Panelga xush kelibsiz!</b>\n\nQuyidagi bo'limlardan birini tanlang:", 
                     parse_mode="HTML", 
                     reply_markup=admin_panel_kb(lang))

@bot.callback_query_handler(func=lambda call: call.data == 'admin_panel')
def back_to_admin_panel(call: CallbackQuery):
    user_id = call.from_user.id
    if user_id not in ADMINS and user_id != OWNER_ID:
        return

    # Get language
    user = db.get_user(user_id)
    lang = user['language'] if user else 'uz'

    bot.edit_message_text(f"👑 <b>Admin Panel</b>\n\nAsosiy menyu:", 
                          call.message.chat.id, 
                          call.message.message_id, 
                          parse_mode="HTML", 
                          reply_markup=admin_panel_kb(lang))
