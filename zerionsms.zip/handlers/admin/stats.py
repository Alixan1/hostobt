from loader import bot
from telebot.types import Message, CallbackQuery
from utils.db_api.sqlite import db
import time

@bot.callback_query_handler(func=lambda call: call.data == 'admin_stats')
def show_admin_stats(call: CallbackQuery):
    user_count = db.count_users()
    
    # Mock advanced stats
    active_hosts = 0
    total_hosts = 0
    try:
        hosts = db.conn.execute("SELECT count(*) FROM hosts").fetchone()[0]
        total_hosts = hosts
        active = db.conn.execute("SELECT count(*) FROM hosts WHERE is_active = 1").fetchone()[0]
        active_hosts = active
    except: pass
    
    # Revenue (Mock)
    revenue_daily = 150000
    revenue_monthly = 4500000
    
    text = f"📊 <b>Bot Statistikasi:</b>\n\n"
    text += f"👥 Jami Foydalanuvchilar: {user_count}\n"
    text += f"📦 Jami Hostlar: {total_hosts}\n"
    text += f"🟢 Faol Hostlar: {active_hosts}\n\n"
    text += f"💰 <b>Daromad (Taxminiy):</b>\n"
    text += f"🗓 Bugun: {revenue_daily} so'm\n"
    text += f"📅 Oy: {revenue_monthly} so'm\n\n"
    text += f"Updated: {time.strftime('%H:%M:%S')}"
    
    # Refresh button
    from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("🔄 Yangilash", callback_data="admin_stats"))
    markup.add(InlineKeyboardButton("🔙 Orqaga", callback_data="admin_panel"))
    
    bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=markup, parse_mode="HTML")
