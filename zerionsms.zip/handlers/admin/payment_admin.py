from loader import bot
from telebot.types import CallbackQuery, Message, InlineKeyboardMarkup, InlineKeyboardButton
from utils.db_api.sqlite import db
from config import ADMINS

@bot.callback_query_handler(func=lambda call: call.data.startswith('pay_'))
def admin_payment_decision(call: CallbackQuery):
    action = call.data.split('_')[1] # ok, manual, reject
    payment_id = int(call.data.split('_')[2])
    
    payment = db.get_payment(payment_id)
    if not payment:
        bot.answer_callback_query(call.id, "Payment not found")
        return
        
    user_id = payment[1]
    
    if action == 'ok':
        amount = float(call.data.split('_')[3])
        db.update_balance(user_id, amount)
        db.update_payment_status(payment_id, 'approved')
        
        bot.edit_message_caption(f"✅ <b>Qabul qilindi:</b> {amount} so'm\nAdmin: {call.from_user.full_name}", 
                                 call.message.chat.id, call.message.message_id, parse_mode="HTML")
        
        try:
            bot.send_message(user_id, f"✅ Sizning to'lovingiz tasdiqlandi!\nHisobingizga <b>{amount} so'm</b> qo'shildi.")
        except: pass
        
    elif action == 'reject':
        db.update_payment_status(payment_id, 'rejected')
        bot.edit_message_caption(f"❌ <b>Rad etildi</b>\nAdmin: {call.from_user.full_name}", 
                                 call.message.chat.id, call.message.message_id, parse_mode="HTML")
        try:
            bot.send_message(user_id, "❌ Sizning to'lovingiz rad etildi.")
        except: pass
        
    elif action == 'manual':
        msg = bot.send_message(call.message.chat.id, f"Summani kiriting (so'mda) ID: {payment_id} uchun:", reply_markup=None)
        bot.register_next_step_handler(msg, process_manual_amount, payment_id, call.message)

def process_manual_amount(message: Message, payment_id, original_msg):
    try:
        amount = float(message.text)
        payment = db.get_payment(payment_id)
        user_id = payment[1]
        
        db.update_balance(user_id, amount)
        db.update_payment_status(payment_id, 'approved')
        
        bot.send_message(message.chat.id, f"✅ {amount} so'm qo'shildi.")
        try:
            # Update original photo caption if possible, or just leave it
            pass 
        except: pass
        
        bot.send_message(user_id, f"✅ Sizning to'lovingiz tasdiqlandi!\nHisobingizga <b>{amount} so'm</b> qo'shildi.")
    except ValueError:
        bot.send_message(message.chat.id, "❌ Iltimos raqam kiriting.")

# --- Manual Balance ---
@bot.callback_query_handler(func=lambda call: call.data == "admin_give_balance")
def ask_user_balance_id(call: CallbackQuery):
    if call.from_user.id not in ADMINS: return
    msg = bot.send_message(call.message.chat.id, "💰 <b>Balance berish:</b>\n\nUser ID ni kiriting:")
    bot.register_next_step_handler(msg, process_balance_user_id)

def process_balance_user_id(message: Message):
    if not message.text.isdigit():
        bot.send_message(message.chat.id, "❌ User ID raqam bo'lishi kerak.")
        return
    user_id = int(message.text)
    user = db.get_user(user_id)
    if not user:
        bot.send_message(message.chat.id, "❌ User topilmadi.")
        return
        
    msg = bot.send_message(message.chat.id, f"👤 <b>{user['full_name']}</b> (ID: {user_id})\n\nQancha summa qo'shmoqchisiz (so'm)?\n(Masalan: 10000 yoki -5000)")
    bot.register_next_step_handler(msg, process_balance_amount, user_id)

def process_balance_amount(message: Message, user_id):
    try:
        amount = float(message.text)
        db.update_balance(user_id, amount)
        bot.send_message(message.chat.id, f"✅ Balance yangilandi! {amount} so'm.")
        try:
            bot.send_message(user_id, f"💰 Sizning hisobingizga {amount} so'm qo'shildi (Admin).")
        except: pass
    except:
        bot.send_message(message.chat.id, "❌ Xatolik.")

# --- Pending Payments List ---
@bot.callback_query_handler(func=lambda call: call.data == "admin_payments")
def list_pending_payments(call: CallbackQuery):
    if call.from_user.id not in ADMINS: return
    
    # We need a method to get pending payments. Let's assume raw SQL here or add to DB later.
    # For now, let's use raw sql via db.conn (not ideal but quick) or add get_pending_payments to sqlite.py?
    # Better to add to sqlite.py.
    # But for now, let's just query locally if possible or just say "Use /start" if notification based?
    # SQLite.py has get_payment but not get_all_pending.
    # I will add get_pending_payments to sqlite.py next.
    
    # Placeholder
    bot.answer_callback_query(call.id, "⚠️ Kutilayotgan to'lovlar ro'yxati hozircha bo'sh.")

