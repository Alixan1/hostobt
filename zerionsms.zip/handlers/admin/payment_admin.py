from loader import bot
from telebot.types import CallbackQuery, Message
from utils.db_api.sqlite import db

@bot.callback_query_handler(func=lambda call: call.data.startswith('pay_'))
def admin_payment_decision(call: CallbackQuery):
    action = call.data.split('_')[1] # ok, manual, reject
    payment_id = int(call.data.split('_')[2])
    
    payment = db.get_payment(payment_id)
    if not payment:
        bot.answer_callback_query(call.id, "Payment not found")
        return
        
    user_id = payment[1]
    
    if action == 'ok':
        amount = float(call.data.split('_')[3])
        db.update_balance(user_id, amount)
        db.update_payment_status(payment_id, 'approved')
        
        bot.edit_message_caption(f"✅ <b>Qabul qilindi:</b> {amount} so'm\nAdmin: {call.from_user.full_name}", 
                                 call.message.chat.id, call.message.message_id, parse_mode="HTML")
        
        try:
            bot.send_message(user_id, f"✅ Sizning to'lovingiz tasdiqlandi!\nHisobingizga <b>{amount} so'm</b> qo'shildi.")
        except: pass
        
    elif action == 'reject':
        db.update_payment_status(payment_id, 'rejected')
        bot.edit_message_caption(f"❌ <b>Rad etildi</b>\nAdmin: {call.from_user.full_name}", 
                                 call.message.chat.id, call.message.message_id, parse_mode="HTML")
        try:
            bot.send_message(user_id, "❌ Sizning to'lovingiz rad etildi.")
        except: pass
        
    elif action == 'manual':
        msg = bot.send_message(call.message.chat.id, f"Summani kiriting (so'mda) ID: {payment_id} uchun:", reply_markup=None)
        bot.register_next_step_handler(msg, process_manual_amount, payment_id, call.message)

def process_manual_amount(message: Message, payment_id, original_msg):
    try:
        amount = float(message.text)
        payment = db.get_payment(payment_id)
        user_id = payment[1]
        
        db.update_balance(user_id, amount)
        db.update_payment_status(payment_id, 'approved')
        
        bot.send_message(message.chat.id, f"✅ {amount} so'm qo'shildi.")
        try:
            # Update original photo caption if possible, or just leave it
            pass 
        except: pass
        
        bot.send_message(user_id, f"✅ Sizning to'lovingiz tasdiqlandi!\nHisobingizga <b>{amount} so'm</b> qo'shildi.")
    except ValueError:
        bot.send_message(message.chat.id, "❌ Iltimos raqam kiriting.")
