from loader import bot
from telebot.types import CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from utils.db_api.sqlite import db
from config import ADMINS, UPLOAD_DIR
from utils.locales import get_text
import os

@bot.callback_query_handler(func=lambda call: call.data == "admin_all_hosts")
def admin_list_hosts(call: CallbackQuery):
    if call.from_user.id not in ADMINS: return
    
    hosts = db.get_all_hosts()
    markup = InlineKeyboardMarkup(row_width=1)
    
    if not hosts:
        bot.answer_callback_query(call.id, "Hostlar yo'q")
        return

    for h in hosts:
        # h: id, user_id, plan_id, path_id, expiry, full_name, plan_name
        btn_text = f"🆔 {h['id']} | 👤 {h['full_name']} | 📦 {h['plan_name']}"
        markup.add(InlineKeyboardButton(btn_text, callback_data=f"adm_host_{h['id']}"))
    
    markup.add(InlineKeyboardButton("🔙 Admin Panel", callback_data="admin_panel_entry"))
    
    bot.edit_message_text(f"🔑 <b>Faol Hostlar Ro'yxati ({len(hosts)}):</b>", 
                          call.message.chat.id, call.message.message_id, 
                          reply_markup=markup, parse_mode="HTML")

@bot.callback_query_handler(func=lambda call: call.data.startswith('adm_host_'))
def admin_host_detail(call: CallbackQuery):
    if call.from_user.id not in ADMINS: return
    
    host_id = int(call.data.split('_')[2])
    host = db.get_host(host_id) # Basic info
    # We might need joined info again or just basic
    
    if not host:
        bot.answer_callback_query(call.id, "Host topilmadi")
        return
        
    path_id = host['path_id']
    full_path = os.path.join(UPLOAD_DIR, path_id)
    files_count = len(os.listdir(full_path)) if os.path.exists(full_path) else 0
    
    txt = f"🔧 <b>Admin Host Boshqaruv:</b>\n"
    txt += f"🆔 ID: {host_id}\n"
    txt += f"👤 Owner ID: {host['user_id']}\n"
    txt += f"📂 Path: <code>{path_id}</code>\n"
    txt += f"💾 Files: {files_count} ta fayl\n"
    
    is_root = host.get('is_privileged', 0)
    root_text = "🔒 Enable Root" if not is_root else "🔓 Disable Root"
    root_val = 1 if not is_root else 0
    
    markup = InlineKeyboardMarkup(row_width=2)
    markup.add(
        InlineKeyboardButton("💻 Terminal", callback_data=f"term_{host_id}"),
        InlineKeyboardButton("📂 Fayllar", callback_data=f"adm_files_{host_id}")
    )
    markup.add(
        InlineKeyboardButton(root_text, callback_data=f"adm_root_{host_id}_{root_val}")
    )
    markup.add(
        InlineKeyboardButton("🛑 Stop", callback_data=f"vps_stop_{host_id}"), 
        InlineKeyboardButton("🗑 O'chirish (Delete)", callback_data=f"adm_del_host_{host_id}")
    )
    markup.add(InlineKeyboardButton("🔙 Ro'yxatga qaytish", callback_data="admin_all_hosts"))
    
    bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=markup, parse_mode="HTML")

@bot.callback_query_handler(func=lambda call: call.data.startswith('adm_root_'))
def admin_toggle_root(call: CallbackQuery):
    if call.from_user.id not in ADMINS: return
    
    parts = call.data.split('_')
    host_id = int(parts[2])
    status = int(parts[3])
    
    db.toggle_host_privilege(host_id, status)
    
    status_text = "Yoqildi" if status else "O'chirildi"
    bot.answer_callback_query(call.id, f"Root huquqi {status_text}!")
    
    # Reload info
    # Trick: change call data to redirect
    call.data = f"adm_host_{host_id}"
    admin_host_detail(call)

@bot.callback_query_handler(func=lambda call: call.data.startswith('adm_files_'))
def admin_file_manager(call: CallbackQuery):
    host_id = int(call.data.split('_')[2])
    host = db.get_host(host_id)
    path = os.path.join(UPLOAD_DIR, host['path_id'])
    
    try:
        files = os.listdir(path)
    except:
        files = []
        
    txt = f"📂 <b>Fayllar ({host['path_id']}):</b>\n\n"
    for f in files:
        txt += f"📄 {f}\n"
        
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("🔙 Ortga", callback_data=f"adm_host_{host_id}"))
    
    bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=markup, parse_mode="HTML")
