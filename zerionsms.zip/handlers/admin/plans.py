from loader import bot
from telebot.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from utils.db_api.sqlite import db
from config import ADMINS

# --- Plan Management Menu ---
@bot.callback_query_handler(func=lambda call: call.data == 'admin_plans')
def admin_plans_menu(call: CallbackQuery):
    plans = db.get_plans()
    markup = InlineKeyboardMarkup(row_width=1)
    for plan in plans:
        # plan: id, name, size, price, ram, cpu, active
        markup.add(InlineKeyboardButton(f"{plan[1]} ({plan[3]} so'm)", callback_data=f"edit_plan_{plan[0]}"))
    
    markup.add(InlineKeyboardButton("➕ Yangi Reja Qo'shish", callback_data="add_new_plan"))
    markup.add(InlineKeyboardButton("🔙 Orqaga", callback_data="admin_panel"))
    
    bot.edit_message_text("hosting Rejalarini Boshqarish:", call.message.chat.id, call.message.message_id, reply_markup=markup)

# --- Edit Specific Plan ---
@bot.callback_query_handler(func=lambda call: call.data.startswith('edit_plan_'))
def edit_plan_details(call: CallbackQuery):
    plan_id = int(call.data.split('_')[2])
    plan = db.get_plan(plan_id)
    
    text = f"<b>Reja: {plan[1]}</b>\n\n"
    text += f"💾 Hajm: {plan[2]} GB\n"
    text += f"💰 Narx: {plan[3]} so'm\n"
    text += f"🧠 RAM: {plan[4]} MB\n"
    text += f"⚙️ CPU: {plan[5]}%\n"
    
    markup = InlineKeyboardMarkup(row_width=2)
    markup.add(
        InlineKeyboardButton("✏️ Narxni o'zgartirish", callback_data=f"set_price_{plan_id}"),
        InlineKeyboardButton("✏️ Hajmni o'zgartirish", callback_data=f"set_size_{plan_id}")
    )
    markup.add(InlineKeyboardButton("❌ O'chirish", callback_data=f"delete_plan_{plan_id}")) # Logical delete (is_active=0)
    markup.add(InlineKeyboardButton("🔙 Orqaga", callback_data="admin_plans"))
    
    bot.edit_message_text(text, call.message.chat.id, call.message.message_id, parse_mode="HTML", reply_markup=markup)

# --- Set Price Logic ---
@bot.callback_query_handler(func=lambda call: call.data.startswith('set_price_'))
def set_price_init(call: CallbackQuery):
    plan_id = call.data.split('_')[2]
    msg = bot.send_message(call.message.chat.id, "Yangi narxni kiriting (so'mda):")
    bot.register_next_step_handler(msg, save_new_price, plan_id, call.message)

def save_new_price(message: Message, plan_id, original_msg):
    try:
        new_price = float(message.text)
        # DB update SQL needed
        # We need a db method for this. Assuming generic execute or adding method.
        # For now, adding direct execute here for speed, but cleaner to put in sqlite.py
        conn = db.conn
        c = conn.cursor()
        c.execute("UPDATE plans SET price_monthly = ? WHERE id = ?", (new_price, plan_id))
        conn.commit()
        
        bot.send_message(message.chat.id, "✅ Narx yangilandi!")
    except:
        bot.send_message(message.chat.id, "❌ Xatolik.")
