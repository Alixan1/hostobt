from loader import bot
from telebot.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from utils.db_api.sqlite import db
from config import ADMINS

@bot.callback_query_handler(func=lambda call: call.data == "admin_grant_root")
def ask_root_target(call: CallbackQuery):
    if call.from_user.id not in ADMINS: return
    
    msg = bot.send_message(call.message.chat.id, "🔓 <b>Root berish uchun ID kiriting:</b>\n\n- <b>User ID</b> (foydalanuvchining barcha hostlariga beradi)\n- <b>Host ID</b> (bitta hostga beradi)\n\nID ni yuboring:", parse_mode="HTML")
    bot.register_next_step_handler(msg, process_root_grant)

def process_root_grant(message: Message):
    if message.text in ['/start', '/menu', 'exit']: 
        bot.send_message(message.chat.id, "Bekor qilindi.")
        return

    try:
        target_id = int(message.text)
    except ValueError:
        bot.send_message(message.chat.id, "❌ Iltimos, raqamli ID kiriting.")
        return

    # Check if Host ID
    host = db.get_host(target_id)
    if host:
        db.toggle_host_privilege(target_id, 1) # 1 = Enabled
        bot.send_message(message.chat.id, f"✅ <b>Host ID: {target_id}</b> uchun Root yoqildi!")
        return

    # Check if User ID
    user_hosts = db.get_user_hosts(target_id)
    if user_hosts:
        count = 0
        for h in user_hosts:
            db.toggle_host_privilege(h['id'], 1)
            count += 1
        bot.send_message(message.chat.id, f"✅ <b>User ID: {target_id}</b> ning {count} ta hosti uchun Root yoqildi!")
        return

    bot.send_message(message.chat.id, "❌ Bunday Host ID yoki User ID (hostlari bilan) topilmadi.")
