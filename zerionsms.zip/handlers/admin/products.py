from loader import bot
from telebot.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from utils.db_api.sqlite import db
from config import ADMINS

# --- Main Products Menu ---
@bot.callback_query_handler(func=lambda call: call.data == 'admin_products')
def admin_products_menu(call: CallbackQuery):
    markup = InlineKeyboardMarkup(row_width=2)
    markup.add(
        InlineKeyboardButton("📂 Categories", callback_data="adm_prod_cats"),
        InlineKeyboardButton("🌍 Locations", callback_data="adm_prod_locs"),
        InlineKeyboardButton("💻 OS Templates", callback_data="adm_prod_os"),
        InlineKeyboardButton("🏷 Plans", callback_data="adm_prod_plans")
    )
    markup.add(InlineKeyboardButton("🔙 Back to Panel", callback_data="admin_panel"))
    bot.edit_message_text("📦 <b>mahsulotlarni Boshqarish</b>\n\nBo'limni tanlang:", 
                          call.message.chat.id, call.message.message_id, 
                          reply_markup=markup, parse_mode="HTML")

# ==========================================
#               CATEGORIES
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == 'adm_prod_cats')
def admin_cats_list(call: CallbackQuery):
    cats = db.get_categories()
    markup = InlineKeyboardMarkup(row_width=1)
    for c in cats:
        markup.add(InlineKeyboardButton(f"{c['name_uz']} ({c['code']})", callback_data=f"adm_edit_cat_{c['id']}"))
    
    markup.add(InlineKeyboardButton("➕ Add Category", callback_data="adm_add_cat"))
    markup.add(InlineKeyboardButton("🔙 Back", callback_data="admin_products"))
    
    bot.edit_message_text("📂 <b>Kategoriyalar:</b>", call.message.chat.id, call.message.message_id, reply_markup=markup, parse_mode="HTML")

@bot.callback_query_handler(func=lambda call: call.data == 'adm_add_cat')
def admin_add_cat_start(call: CallbackQuery):
    msg = bot.send_message(call.message.chat.id, "Kategoriya kodini kiriting (masalan: `minecraft`):", parse_mode="Markdown")
    bot.register_next_step_handler(msg, admin_add_cat_code, call.message)

def admin_add_cat_code(message: Message, original_msg):
    code = message.text.lower().strip()
    msg = bot.send_message(message.chat.id, "O'zbekcha nomini kiriting:")
    bot.register_next_step_handler(msg, admin_add_cat_uz, code, original_msg)

def admin_add_cat_uz(message: Message, code, original_msg):
    name_uz = message.text
    msg = bot.send_message(message.chat.id, "Ruscha nomini kiriting:")
    bot.register_next_step_handler(msg, admin_add_cat_ru, code, name_uz, original_msg)

def admin_add_cat_ru(message: Message, code, name_uz, original_msg):
    name_ru = message.text
    msg = bot.send_message(message.chat.id, "Inglizcha nomini kiriting:")
    bot.register_next_step_handler(msg, admin_add_cat_finish, code, name_uz, name_ru, original_msg)

def admin_add_cat_finish(message: Message, code, name_uz, name_ru, original_msg):
    name_en = message.text
    try:
        db.add_category(name_uz, name_ru, name_en, code)
        bot.send_message(message.chat.id, "✅ Kategoriya qo'shildi!")
    except Exception as e:
        bot.send_message(message.chat.id, f"❌ Xatolik: {e}")

@bot.callback_query_handler(func=lambda call: call.data.startswith('adm_edit_cat_'))
def admin_edit_cat(call: CallbackQuery):
    cat_id = int(call.data.split('_')[3])
    cat = db.get_category(cat_id)
    
    text = f"📂 <b>Category Info:</b>\n"
    text += f"Code: {cat['code']}\n"
    text += f"UZ: {cat['name_uz']}\nRU: {cat['name_ru']}\nEN: {cat['name_en']}"
    
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("🗑 O'chirish (Delete)", callback_data=f"adm_del_cat_{cat_id}"))
    markup.add(InlineKeyboardButton("🔙 Orqaga", callback_data="adm_prod_cats"))
    
    bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=markup, parse_mode="HTML")

@bot.callback_query_handler(func=lambda call: call.data.startswith('adm_del_cat_'))
def admin_delete_cat(call: CallbackQuery):
    cat_id = int(call.data.split('_')[3])
    db.delete_category(cat_id)
    bot.answer_callback_query(call.id, "Kategoriya o'chirildi.")
    admin_cats_list(call)

# ==========================================
#               LOCATIONS
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == 'adm_prod_locs')
def admin_locs_list(call: CallbackQuery):
    locs = db.get_locations()
    markup = InlineKeyboardMarkup(row_width=1)
    for l in locs:
        markup.add(InlineKeyboardButton(f"{l['flag_emoji']} {l['name']}", callback_data=f"adm_del_loc_{l['id']}")) # Click to delete simplication
    
    markup.add(InlineKeyboardButton("➕ Add Location", callback_data="adm_add_loc"))
    markup.add(InlineKeyboardButton("🔙 Back", callback_data="admin_products"))
    bot.edit_message_text("🌍 <b>Lokatsiyalar (O'chirish uchun bosing):</b>", call.message.chat.id, call.message.message_id, reply_markup=markup, parse_mode="HTML")

@bot.callback_query_handler(func=lambda call: call.data == 'adm_add_loc')
def admin_add_loc_start(call: CallbackQuery):
    msg = bot.send_message(call.message.chat.id, "Lokatsiya nomini kiriting (masalan: Germany):")
    bot.register_next_step_handler(msg, admin_add_loc_name, call.message)

def admin_add_loc_name(message: Message, original_msg):
    name = message.text
    msg = bot.send_message(message.chat.id, "Bayroq emojisini yuboring (🇩🇪):")
    bot.register_next_step_handler(msg, admin_add_loc_flag, name, original_msg)

def admin_add_loc_flag(message: Message, name, original_msg):
    flag = message.text
    code = name.lower()[:3]
    db.add_location(name, flag, code)
    bot.send_message(message.chat.id, "✅ Lokatsiya qo'shildi!")

@bot.callback_query_handler(func=lambda call: call.data.startswith('adm_del_loc_'))
def admin_delete_loc(call: CallbackQuery):
    loc_id = int(call.data.split('_')[3])
    db.delete_location(loc_id)
    bot.answer_callback_query(call.id, "Lokatsiya o'chirildi.")
    admin_locs_list(call)

# ==========================================
#               OS TEMPLATES
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == 'adm_prod_os')
def admin_os_list(call: CallbackQuery):
    oss = db.get_os_templates()
    markup = InlineKeyboardMarkup(row_width=1)
    for o in oss:
        markup.add(InlineKeyboardButton(f"{o['name']} {o['version']} ({o['type']})", callback_data=f"adm_del_os_{o['id']}"))
    
    markup.add(InlineKeyboardButton("➕ Add OS", callback_data="adm_add_os"))
    markup.add(InlineKeyboardButton("🔙 Back", callback_data="admin_products"))
    
    bot.edit_message_text("💻 <b>OS Templates (O'chirish uchun bosing):</b>", call.message.chat.id, call.message.message_id, reply_markup=markup, parse_mode="HTML")

@bot.callback_query_handler(func=lambda call: call.data == 'adm_add_os')
def admin_add_os_start(call: CallbackQuery):
    msg = bot.send_message(call.message.chat.id, "OS nomini kiriting (Ubuntu):")
    bot.register_next_step_handler(msg, admin_add_os_name, call.message)

def admin_add_os_name(message: Message, original_msg):
    name = message.text
    msg = bot.send_message(message.chat.id, "Versiyasini kiriting (22.04):")
    bot.register_next_step_handler(msg, admin_add_os_ver, name, original_msg)

def admin_add_os_ver(message: Message, name, original_msg):
    ver = message.text
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("Linux", callback_data=f"adm_save_os_linux_{name}_{ver}"),
               InlineKeyboardButton("Windows", callback_data=f"adm_save_os_windows_{name}_{ver}"))
    bot.send_message(message.chat.id, "Turini tanlang:", reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data.startswith('adm_save_os_'))
def admin_save_os(call: CallbackQuery):
    # adm_save_os_linux_Ubuntu_22.04
    parts = call.data.split('_')
    os_type = parts[3]
    name = parts[4]
    ver = parts[5]
    
    db.add_os_template(name, ver, os_type)
    bot.edit_message_text("✅ OS qo'shildi!", call.message.chat.id, call.message.message_id)

@bot.callback_query_handler(func=lambda call: call.data.startswith('adm_del_os_'))
def admin_delete_os(call: CallbackQuery):
    os_id = int(call.data.split('_')[3])
    db.delete_os_template(os_id)
    bot.answer_callback_query(call.id, "OS o'chirildi.")
    admin_os_list(call)

# ==========================================
#               PLANS (Basic integration)
# ==========================================
@bot.callback_query_handler(func=lambda call: call.data == 'adm_prod_plans')
def admin_plans_redirect(call: CallbackQuery):
    # Reuse existing plans handler but might need upgrade later
    from handlers.admin.plans import admin_plans_menu
    admin_plans_menu(call)
