from loader import bot
from telebot.types import CallbackQuery, Message
from utils.db_api.sqlite import db
from config import ADMINS, OWNER_ID
from keyboards.default.menu import main_menu_inline

# --- Helper to return to main menu ---
@bot.callback_query_handler(func=lambda call: call.data == 'main_menu')
def back_to_main(call: CallbackQuery):
    user_id = call.from_user.id
    user = db.get_user(user_id)
    lang = user['language'] if user else 'uz'
    is_admin = user_id in ADMINS or user_id == OWNER_ID
    
    text = f"🚀 <b>HostBot Menu</b>\n\nQuyidagi bo'limlardan birini tanlang:"
    bot.edit_message_text(text, call.message.chat.id, call.message.message_id, 
                          reply_markup=main_menu_inline(is_admin, lang), parse_mode="HTML")

# --- Routing for Main Menu Items ---

@bot.callback_query_handler(func=lambda call: call.data == 'my_hosts')
def route_my_hosts(call: CallbackQuery):
    # Call existing logic but we need to trigger it. 
    # Since existing logic uses Message handler mostly, we might need to adapt hosting.py 
    # OR we trick it.
    # BEST PRACTICE: Import the function from hosting.py if it was separated, 
    # but currently hosting.py listens to text "🖥 Mening Hostlarim".
    # So we call the function directly.
    from handlers.users.hosting import my_hosts_inline
    my_hosts_inline(call)

@bot.callback_query_handler(func=lambda call: call.data == 'balance')
def route_balance(call: CallbackQuery):
    user_id = call.from_user.id
    user = db.get_user(user_id)
    lang = user['language']
    
    txt = f"💰 <b>Sizning Balansingiz:</b>\n\n"
    txt += f"💳 Asosiy hisob: <b>{user['balance']:,.0f} so'm</b>\n\n"
    txt += "Hisobni to'ldirish uchun payme yoki click orqali to'lov qilishingiz mumkin."
    
    # Inline KB for payment
    from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("💸 To'ldirish", callback_data="add_balance"))
    markup.add(InlineKeyboardButton("🔙 Ortga", callback_data="main_menu"))
    
    bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=markup, parse_mode="HTML")

@bot.callback_query_handler(func=lambda call: call.data == 'buy_host')
def route_buy_host(call: CallbackQuery):
    from handlers.users.hosting import buy_hosting_entry_inline
    buy_hosting_entry_inline(call)

@bot.callback_query_handler(func=lambda call: call.data == 'settings')
def route_settings(call: CallbackQuery):
    from handlers.users.settings import settings_inline
    settings_inline(call)

@bot.callback_query_handler(func=lambda call: call.data == 'help_support')
def route_help(call: CallbackQuery):
    from handlers.users.support import support_inline
    support_inline(call)

@bot.callback_query_handler(func=lambda call: call.data == 'referral')
def route_referral(call: CallbackQuery):
    from handlers.users.referral import referral_inline
    referral_inline(call)

@bot.callback_query_handler(func=lambda call: call.data == 'admin_panel_entry')
def route_admin(call: CallbackQuery):
    if call.from_user.id not in ADMINS and call.from_user.id != OWNER_ID:
        return
    import handlers.admin.dashboard
    handlers.admin.dashboard.entry_admin_inline(call)
