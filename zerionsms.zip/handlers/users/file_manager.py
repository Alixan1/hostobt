from loader import bot
from telebot.types import CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, Message
from utils.db_api.sqlite import db
from config import UPLOAD_DIR
import os
import html

# --- Entry Point ---
@bot.callback_query_handler(func=lambda call: call.data.startswith('files_'))
def file_manager_entry(call: CallbackQuery):
    # files_{host_id}_{rel_path}
    parts = call.data.split('_')
    host_id = int(parts[1])
    # Optional rel_path handling could be added later, for now flattened or root
    
    user_id = call.from_user.id
    host = db.get_host(host_id)
    
    if not host or host['user_id'] != user_id:
        bot.answer_callback_query(call.id, "❌ Ruxsat yo'q!")
        return

    path_id = host['path_id']
    base_path = os.path.join(UPLOAD_DIR, path_id)
    
    if not os.path.exists(base_path):
        os.makedirs(base_path, exist_ok=True)
        
    files = os.listdir(base_path)
    
    # Auto-create default file if empty
    if not files:
        with open(os.path.join(base_path, "README.txt"), "w") as f:
            f.write("Welcome to your VPS space!\nYou can run python scripts here.")
        files = ["README.txt"]
    
    markup = InlineKeyboardMarkup(row_width=2)
    
    txt = f"📂 <b>Fayl Menejeri</b>\nPath: <code>/home/container/</code>\n\n"
    
    if not files:
        txt += "<i>Papkada fayllar yo'q.</i>"
    else:
        for f in files:
            # Check if file or dir (simple implementation)
            full_p = os.path.join(base_path, f)
            icon = "📁" if os.path.isdir(full_p) else "📄"
            
            # Button to View/Action
            markup.add(InlineKeyboardButton(f"{icon} {f}", callback_data=f"fview_{host_id}_{f}"))
            
    markup.add(InlineKeyboardButton("🔙 Ortga", callback_data="my_hosts")) # Or generic back?
    
    bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=markup, parse_mode="HTML")

# --- View File / Actions ---
@bot.callback_query_handler(func=lambda call: call.data.startswith('fview_'))
def file_view(call: CallbackQuery):
    _, host_id, filename = call.data.split('_', 2)
    host_id = int(host_id)
    
    user_id = call.from_user.id
    host = db.get_host(host_id)
    if not host or host['user_id'] != user_id:
        return
        
    path_id = host['path_id']
    file_path = os.path.join(UPLOAD_DIR, path_id, filename)
    
    if not os.path.exists(file_path):
        bot.answer_callback_query(call.id, "Fayl topilmadi!")
        return
        
    # Actions Menu
    txt = f"📄 <b>Fayl:</b> {filename}\n"
    size = os.path.getsize(file_path)
    txt += f"📦 <b>Hajmi:</b> {size} bytes\n\n"
    txt += "Nima qilmoqchisiz?"
    
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("👁 Ko'rish (Text)", callback_data=f"fread_{host_id}_{filename}"))
    markup.add(InlineKeyboardButton("🗑 O'chirish", callback_data=f"fdel_{host_id}_{filename}"))
    markup.add(InlineKeyboardButton("🔙 Orqaga", callback_data=f"files_{host_id}"))
    
    bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=markup, parse_mode="HTML")

# --- Read Content ---
@bot.callback_query_handler(func=lambda call: call.data.startswith('fread_'))
def file_read(call: CallbackQuery):
    _, host_id, filename = call.data.split('_', 2)
    host_id = int(host_id)
    host = db.get_host(host_id)
    file_path = os.path.join(UPLOAD_DIR, host['path_id'], filename)
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read(3000) # Limit 3000 chars
            
        if len(content) >= 3000: content += "\n... [Kesilgan]"
        if not content: content = "[Bo'sh fayl]"
        
        txt = f"📄 <b>{filename}</b>:\n<pre>{html.escape(content)}</pre>"
        
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🔙 Orqaga", callback_data=f"fview_{host_id}_{filename}"))
        
        bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=markup, parse_mode="HTML")
        
    except Exception as e:
        bot.answer_callback_query(call.id, "Faylni o'qib bo'lmadi (Binary?).")

# --- Delete File ---
@bot.callback_query_handler(func=lambda call: call.data.startswith('fdel_'))
def file_delete(call: CallbackQuery):
    _, host_id, filename = call.data.split('_', 2)
    host_id = int(host_id)
    host = db.get_host(host_id)
    file_path = os.path.join(UPLOAD_DIR, host['path_id'], filename)
    
    try:
        os.remove(file_path)
        bot.answer_callback_query(call.id, "✅ Fayl o'chirildi.")
        # Return to list
        # Trick: create mock call setup or just call direct if we import or separate logic?
        # Simplest: manually trigger entry logic basics
        file_manager_entry_manual(call, host_id)
        
    except Exception as e:
        bot.answer_callback_query(call.id, f"Xatolik: {e}", show_alert=True)

def file_manager_entry_manual(call, host_id):
    # Re-use logic helper
    host = db.get_host(host_id)
    base_path = os.path.join(UPLOAD_DIR, host['path_id'])
    files = os.listdir(base_path) if os.path.exists(base_path) else []
    
    markup = InlineKeyboardMarkup(row_width=2)
    for f in files:
        full_p = os.path.join(base_path, f)
        icon = "📁" if os.path.isdir(full_p) else "📄"
        markup.add(InlineKeyboardButton(f"{icon} {f}", callback_data=f"fview_{host_id}_{f}"))
    markup.add(InlineKeyboardButton("🔙 Ortga", callback_data="my_hosts"))
    
    try:
        bot.edit_message_text(f"📂 <b>Fayl Menejeri (Yangilandi)</b>", 
                              call.message.chat.id, call.message.message_id, 
                              reply_markup=markup, parse_mode="HTML")
    except: pass

@bot.callback_query_handler(func=lambda call: call.data.startswith('upload_'))
def upload_request(call: CallbackQuery):
    host_id = int(call.data.split('_')[1])
    bot.send_message(call.message.chat.id, "📤 <b>Fayl yuklash:</b>\n\nIstasangiz oddiy fayl (.py, .html...), istasangiz ZIP arxiv yuboring.\nZIP bo'lsa avtomatik arxivdan chiqariladi.", parse_mode="HTML")
    bot.register_next_step_handler(call.message, process_file_upload, host_id)

def process_file_upload(message: Message, host_id):
    if not message.document:
        bot.send_message(message.chat.id, "❌ Fayl yuborilmadi.")
        return

    try:
        host = db.get_host(host_id)
        if not host:
             bot.send_message(message.chat.id, "❌ Host topilmadi.")
             return

        work_dir = os.path.join(UPLOAD_DIR, host['path_id'])
        file_info = bot.get_file(message.document.file_id)
        downloaded_file = bot.download_file(file_info.file_path)
        
        file_name = message.document.file_name
        file_path = os.path.join(work_dir, file_name)
        
        with open(file_path, 'wb') as new_file:
            new_file.write(downloaded_file)
            
        msg = f"✅ <b>Fayl yuklandi:</b> {file_name}"
        
        # Auto-Unzip
        import zipfile
        if file_name.endswith('.zip'):
             with zipfile.ZipFile(file_path, 'r') as zip_ref:
                 zip_ref.extractall(work_dir)
             os.remove(file_path) 
             msg += "\n📦 <b>ZIP arxivdan chiqarildi!</b>"
             
        bot.send_message(message.chat.id, msg, parse_mode="HTML")
        
    except Exception as e:
        bot.send_message(message.chat.id, f"❌ Xatolik: {e}")
