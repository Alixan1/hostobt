from telebot.types import Message, CallbackQuery
from loader import bot, db_conn
from utils.db_api.sqlite import db
from utils.locales import get_text
from config import ADMINS

@bot.message_handler(func=lambda message: message.text in ["💰 Balans", "💰 Balance", "💰 Баланс"])
def balance_handler(message: Message):
    user_id = message.from_user.id
    user = db.get_user(user_id)
    lang = user['language'] # Language
    balance = user['balance'] # Balance
    
    text = get_text('balance_info', lang).format(balance)
    bot.send_message(message.chat.id, text, parse_mode="HTML")
    
    # Ask for receipt
    bot.send_message(message.chat.id, get_text('send_receipt', lang))

@bot.callback_query_handler(func=lambda call: call.data == 'add_balance')
def add_balance_callback(call: CallbackQuery):
    user_id = call.from_user.id
    user = db.get_user(user_id)
    lang = user['language'] if user else 'uz'
    
    from config import PAYMENT_CARD
    
    text = f"💳 <b>Karta:</b> <code>{PAYMENT_CARD}</code>\n"
    text += f"👤 <b>Ega:</b> UZHOST ADMIN\n\n"
    text += f"{get_text('send_receipt', lang)}\n\n"
    text += "<i>To'lov chekini rasm ko'rinishida yuboring.</i>"
    
    from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("🔙 Bekor qilish", callback_data="main_menu"))
    
    bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=markup, parse_mode="HTML")

@bot.message_handler(content_types=['photo'])
def handle_receipt(message: Message):
    user_id = message.from_user.id
    user = db.get_user(user_id)
    lang = user['language']
    
    # Check if this is a payment context (simplification: any photo sent is treated as potential receipt if user has low balance or just sent 'Balance')
    # Better: User context state. For now, valid for simplicity.
    
    photo_id = message.photo[-1].file_id
    caption = message.caption or ""
    
    # Create payment request in DB
    # We don't know amount yet, Admin will set it or we ask user? 
    # Let's ask user for amount first (in flow), but for "Just sent photo", we assume admin decides.
    # Logic: Admin sees photo -> Admin clicks "Approve 10,000" or Input amount.
    
    payment_id = db.add_payment(user_id, 0, photo_id) # Amount 0 initially
    
    bot.send_message(message.chat.id, get_text('receipt_received', lang))
    
    # Notify Admins
    from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
    markup = InlineKeyboardMarkup()
    markup.add(
        InlineKeyboardButton("✅ 10 000", callback_data=f"pay_ok_{payment_id}_10000"),
        InlineKeyboardButton("✅ 20 000", callback_data=f"pay_ok_{payment_id}_20000"),
        InlineKeyboardButton("✅ 50 000", callback_data=f"pay_ok_{payment_id}_50000")
    )
    markup.add(
        InlineKeyboardButton("✏️ Manual Amount", callback_data=f"pay_manual_{payment_id}"),
        InlineKeyboardButton("❌ Reject", callback_data=f"pay_reject_{payment_id}")
    )
    
    admin_caption = f"💸 <b>Yangi To'lov Cheki!</b>\nUser: {user['full_name']} (@{user['username']})\nID: {user_id}\n\nSummani tasdiqlang:"
    
    for admin in ADMINS:
        try:
            bot.send_photo(admin, photo_id, caption=admin_caption, parse_mode="HTML", reply_markup=markup)
        except: pass
