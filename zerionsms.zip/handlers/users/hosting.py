from telebot.types import Message, CallbackQuery
from loader import bot
from utils.db_api.sqlite import db
from keyboards.default.menu import hosts_list_kb, host_control_kb
import os
import shutil
from config import UPLOAD_DIR
from datetime import datetime, timedelta

# --- Mening Hostlarim ---
@bot.message_handler(func=lambda message: message.text == "🖥 Mening Hostlarim")
def my_hosts(message: Message):
    user_id = message.from_user.id
    hosts = db.get_user_hosts(user_id)
    
    if not hosts:
        bot.send_message(message.chat.id, "❌ Sizda faol hostlar yo'q. 'Host Sotib Olish' bo'limidan xarid qiling.")
        return

    bot.send_message(message.chat.id, "📦 Sizning Hostlaringiz:", reply_markup=hosts_list_kb(hosts))

# --- Hostni Tanlash ---
@bot.callback_query_handler(func=lambda call: call.data.startswith('host_'))
def show_host_details(call: CallbackQuery):
    host_id = int(call.data.split('_')[1])
    host = db.get_host(host_id) # (id, user_id, plan_id, path_id, expiry, active, priv)
    
    if not host:
        bot.answer_callback_query(call.id, "Host topilmadi.")
        return

    # Folder tekshirish
    host_folder = os.path.join(UPLOAD_DIR, host[3]) # path_id
    if not os.path.exists(host_folder):
        os.makedirs(host_folder, exist_ok=True)
    
    # Running state check
    from utils.misc.process_manager import pm
    is_running = pm.is_running(host_id)
    
    status_text = "🟢 Ishlamoqda" if is_running else "🔴 To'xtatilgan"
    
    msg = f"🆔 Host ID: {host_id}\n"
    msg += f"📅 Tugash vaqti: {host[4]}\n"
    msg += f"📊 Status: {status_text}\n"
    
    bot.edit_message_text(msg, call.message.chat.id, call.message.message_id, reply_markup=host_control_kb(host_id, is_running))

@bot.callback_query_handler(func=lambda call: call.data.startswith(('start_', 'stop_', 'restart_', 'logs_')))
def handle_process_actions(call: CallbackQuery):
    action, host_id = call.data.split('_')
    host_id = int(host_id)
    host = db.get_host(host_id)
    
    if not host:
        bot.answer_callback_query(call.id, "Host topilmadi.")
        return

    # Asosiy faylni topish (main.py yoki bot.py yoki shunga o'xshash)
    # Hozircha biz user papkasidagi birinchi .py faylni olamiz yoki user tanlashi kerak
    host_folder = os.path.join(UPLOAD_DIR, host[3])
    
    # Oddiy logika: papkadagi birinchi .py faylni topish
    target_file = None
    if os.path.exists(host_folder):
        for f in os.listdir(host_folder):
            if f.endswith('.py') or f.endswith('.js'):
                target_file = os.path.join(host_folder, f)
                break
    
    from utils.misc.process_manager import pm
    from utils.misc.security import security
    from config import ADMINS
    from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
    
    if action == 'start':
        if not target_file:
            bot.answer_callback_query(call.id, "❌ Papkada .py yoki .js fayl topilmadi!", show_alert=True)
            return
        
        # 1. Security Scan
        safe, scan_msg = security.scan_file(target_file)
        if not safe:
            bot.answer_callback_query(call.id, f"⛔ Security Alert: {scan_msg}", show_alert=True)
            bot.send_message(call.message.chat.id, f"⛔ <b>Xavfsizlik Tizimi:</b>\nSizning kodingizda taqiqlangan buyruqlar aniqlandi.\n\nSabab: {scan_msg}\n\nQayta urinmang, aks holda ban olishingiz mumkin.", parse_mode="HTML")
            return

        # 2. Admin Approval Request
        user_id = call.from_user.id
        admin_markup = InlineKeyboardMarkup()
        admin_markup.add(
            InlineKeyboardButton("✅ Ruxsat berish", callback_data=f"approve_run_{host_id}_{user_id}"),
            InlineKeyboardButton("❌ Rad etish", callback_data=f"reject_run_{host_id}_{user_id}")
        )
        
        # Send file to admins
        try:
            with open(target_file, 'rb') as f:
                caption = f"🛡 <b>Yangi Host So'rovi:</b>\nUser: {call.from_user.full_name} (ID: {user_id})\nHost ID: {host_id}\n\nKodni tekshirib ruxsat bering."
                for admin_id in ADMINS:
                    try:
                        bot.send_document(admin_id, f, caption=caption, parse_mode="HTML", reply_markup=admin_markup)
                    except: pass
            
            bot.answer_callback_query(call.id, "⏳ Admin tasdiqlashi uchun yuborildi.", show_alert=True)
            bot.send_message(call.message.chat.id, "⏳ <b>Kodingiz Adminga yuborildi.</b>\nAdmin tasdiqlaganidan so'ng avtomatik ishga tushadi.")
        except Exception as e:
            bot.send_message(call.message.chat.id, f"❌ Xatolik yuz berdi: {e}")
        
    elif action == 'stop':
        success, msg = pm.stop_script(host_id)
        bot.answer_callback_query(call.id, msg, show_alert=True)
        
    elif action == 'restart':
        success, msg = pm.restart_script(host_id)
        bot.answer_callback_query(call.id, msg, show_alert=True)
        
    elif action == 'logs':
        logs = pm.get_logs(host_id)
        # Log juda uzun bo'lsa file qilib tashlash kerak, hozircha text
        if len(logs) > 4000:
            logs = logs[-4000:]
        try:
            bot.send_message(call.message.chat.id, f"📜 <b>Host #{host_id} Loglari:</b>\n\n<pre>{logs}</pre>", parse_mode="HTML")
        except:
             bot.send_message(call.message.chat.id, "❌ Loglarni o'qishda xatolik yoki ular juda uzun.")
        return # Don't refresh menu for logs

    # Refresh menu
    is_running = pm.is_running(host_id)
    status_text = "🟢 Ishlamoqda" if is_running else "🔴 To'xtatilgan"
    msg_text = f"🆔 Host ID: {host_id}\n📅 Tugash vaqti: {host[4]}\n📊 Status: {status_text}"
    
    try:
        bot.edit_message_text(msg_text, call.message.chat.id, call.message.message_id, reply_markup=host_control_kb(host_id, is_running))
    except:
        pass

# --- Sotib Olish Logic ---
@bot.message_handler(func=lambda message: message.text == "🛒 Host Sotib Olish")
def buy_hosting(message: Message):
    plans = db.get_plans()
    text = "📦 Mavjud Rejalar:\n\n"
    # Oddiy text ko'rinishida, keyin inline keyboard qilsa bo'ladi
    for p in plans:
        text += f"🔹 <b>{p[1]}</b> - {p[2]}GB\n💰 Narxi: {p[3]} so'm/oy\n\n"
    
    text += "Sotib olish uchun Balansni to'ldiring va Admin bilan bog'laning (Vaqtinchalik)."
    bot.send_message(message.chat.id, text, parse_mode="HTML")

# --- Fayl Yuklash (Zip) ---
@bot.message_handler(content_types=['document'])
def handle_zip_upload(message: Message):
    # Bu yerda qaysi hostga yuklashni so'rash kerak
    # Hozircha oddiy logika
    pass 
