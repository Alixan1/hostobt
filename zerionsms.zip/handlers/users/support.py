from loader import bot
from telebot.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from utils.db_api.sqlite import db
from config import ADMINS

@bot.callback_query_handler(func=lambda call: call.data == "help_support")
def support_inline(call: CallbackQuery):
    user_id = call.from_user.id
    tickets = db.get_user_tickets(user_id)
    
    txt = "🆘 <b>Yordam Markazi</b>\n\nMuammolar bo'yicha bizga murojaat qiling.\nJavoblar shu yerda ko'rinadi."
    
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("➕ Yangi Ticket Ochish", callback_data="new_ticket"))
    
    if tickets:
        txt += "\n\n📋 <b>Sizning murojaatlaringiz:</b>"
        for t in tickets:
            status = "🟢" if t['status'] == 'open' else ("🔴" if t['status'] == 'closed' else "🟡")
            markup.add(InlineKeyboardButton(f"{status} #{t['id']} {t['subject']}", callback_data=f"view_ticket_{t['id']}"))
            
    markup.add(InlineKeyboardButton("🔙 Bosh Menyu", callback_data="main_menu"))
    bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=markup, parse_mode="HTML")

@bot.callback_query_handler(func=lambda call: call.data == 'new_ticket')
def new_ticket_start(call: CallbackQuery):
    msg = bot.send_message(call.message.chat.id, "Muammo mavzusini qisqacha yozing (masalan: VPS ishlamayapti):")
    bot.register_next_step_handler(msg, create_ticket_subject)

def create_ticket_subject(message: Message):
    subject = message.text
    ticket_id = db.create_ticket(message.from_user.id, subject)
    
    bot.send_message(message.chat.id, f"✅ Ticket #{ticket_id} yaratildi!\n\nEndi batafsil xabaringizni yozing:")
    bot.register_next_step_handler(message, add_ticket_msg, ticket_id)

def add_ticket_msg(message: Message, ticket_id):
    text = message.text
    db.add_ticket_message(ticket_id, message.from_user.id, text)
    bot.send_message(message.chat.id, "✅ Xabar yuborildi. Javobni kuting.")
    
    # Notify Admins
    for admin in ADMINS:
        try:
            bot.send_message(admin, f"🆘 <b>Yangi Ticket #{ticket_id}</b>\nUser: {message.from_user.full_name}\nMavzu: {text}", parse_mode="HTML")
        except: pass

@bot.callback_query_handler(func=lambda call: call.data.startswith('view_ticket_'))
def view_ticket(call: CallbackQuery):
    ticket_id = int(call.data.split('_')[2])
    ticket = db.get_ticket(ticket_id)
    msgs = db.get_ticket_messages(ticket_id)
    
    txt = f"🎫 <b>Ticket #{ticket_id}</b>\nMavzu: {ticket['subject']}\nStatus: {ticket['status']}\n\n"
    for m in msgs:
        sender = "Siz" if m['sender_id'] == call.from_user.id else "Admin"
        txt += f"👤 <b>{sender}:</b> {m['text']}\n"
        
    markup = InlineKeyboardMarkup()
    if ticket['status'] != 'closed':
        markup.add(InlineKeyboardButton("✍️ Javob yozish", callback_data=f"reply_ticket_{ticket_id}"))
        markup.add(InlineKeyboardButton("🔒 Yopish", callback_data=f"close_ticket_{ticket_id}"))
    markup.add(InlineKeyboardButton("🔙 Orqaga", callback_data="support_back")) # Should trigger support_handler logic
    
    bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=markup, parse_mode="HTML")

@bot.callback_query_handler(func=lambda call: call.data.startswith('reply_ticket_'))
def reply_ticket_start(call: CallbackQuery):
    ticket_id = int(call.data.split('_')[2])
    msg = bot.send_message(call.message.chat.id, "Xabaringizni yozing:")
    bot.register_next_step_handler(msg, add_ticket_msg, ticket_id)

@bot.callback_query_handler(func=lambda call: call.data.startswith('close_ticket_'))
def close_ticket(call: CallbackQuery):
    ticket_id = int(call.data.split('_')[2])
    db.close_ticket(ticket_id)
    bot.answer_callback_query(call.id, "Ticket yopildi.")
    view_ticket(call) # Refresh

@bot.callback_query_handler(func=lambda call: call.data == 'support_back')
def back_to_support(call: CallbackQuery):
    # Call original handler logic
    # Trick: Create fake message object
    class FakeMessage:
        def __init__(self, u, c):
            self.from_user = u
            self.chat = c
            self.text = "🆘 Yordam"
            
    support_handler(FakeMessage(call.from_user, call.message.chat))
