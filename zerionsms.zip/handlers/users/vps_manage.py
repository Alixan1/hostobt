from loader import bot
from telebot.types import CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from utils.db_api.sqlite import db
from utils.vps.controller import vps_manager
from keyboards.default.menu import vps_control_kb
import time

# Helper to check ownership
def check_owner(call, host_id):
    host = db.get_host(host_id)
    if not host or host['user_id'] != call.from_user.id:
        bot.answer_callback_query(call.id, "Host sizniki emas!")
        return None
    return host

# Progress Bar Helper
def _progress_bar(percent):
    blocks = int(percent // 10)
    return "🟩" * blocks + "⬜" * (10 - blocks)

@bot.callback_query_handler(func=lambda call: call.data.startswith('vps_'))
def vps_action_handler(call: CallbackQuery):
    action = call.data.split('_')[1] # start, stop, reboot, reinstall, root, monitor
    host_id = int(call.data.split('_')[2])
    
    host = check_owner(call, host_id)
    if not host: return
    
    # Use path_id as container_id for stable mapping
    container_id = str(host['path_id'])
    
    info = vps_manager.get_info(container_id)
    if not info and action not in ['reinstall']: 
        # Create default state if missing
        vps_manager.create_container(call.from_user.id, host['plan_id'], "Ubuntu 22.04", "Germany", custom_id=container_id)
        info = vps_manager.get_info(container_id)

    if action == 'start':
        success, msg = vps_manager.start_vps(container_id)
        bot.answer_callback_query(call.id, msg)
        refresh_vps_panel(call, host_id)
        
    elif action == 'stop':
        success, msg = vps_manager.stop_vps(container_id)
        bot.answer_callback_query(call.id, msg)
        refresh_vps_panel(call, host_id)

    elif action == 'reboot':
        bot.answer_callback_query(call.id, "Rebooting...")
        vps_manager.reboot_vps(container_id)
        bot.send_message(call.message.chat.id, "✅ VPS qayta ishga tushdi.")
        refresh_vps_panel(call, host_id)

    elif action == 'reinstall':
        bot.answer_callback_query(call.id, "Reinstalling...")
        bot.edit_message_text("⏳ OS o'rnatilmoqda... (5 soniya)", call.message.chat.id, call.message.message_id)
        success, msg = vps_manager.reinstall_os(container_id, "Ubuntu 22.04")
        bot.send_message(call.message.chat.id, msg)
        refresh_vps_panel(call, host_id)

    elif action == 'root':
        info = vps_manager.get_info(container_id)
        if info:
            ip = info.get('ip', '1.1.1.1')
            pwd = info.get('root_pass', '****')
            bot.send_message(call.message.chat.id, f"🔑 <b>Root Access:</b>\n\n🌍 IP: <code>{ip}</code>\n👤 User: <code>root</code>\n🔑 Pass: <code>{pwd}</code>", parse_mode="HTML")
        else:
            bot.answer_callback_query(call.id, "Info yo'q")

    elif action == 'monitor':
        from utils.vps.monitor import monitor
        stats = monitor.get_stats(container_id)
        
        # Premium Design for Stats
        txt = f"📊 <b>VPS Monitor (Live)</b>\n"
        txt += f"━━━━━━━━━━━━━━━\n"
        txt += f"🧠 <b>CPU:</b> {stats['cpu']}%\n"
        txt += _progress_bar(stats['cpu']) + "\n"
        txt += f"💾 <b>RAM:</b> {stats['ram']} MB\n"
        txt += _progress_bar(min(stats['ram']/4096*100, 100)) + "\n"
        txt += f"💿 <b>Disk:</b> {stats['disk']} GB\n"
        txt += f"━━━━━━━━━━━━━━━\n"
        
        bot.send_message(call.message.chat.id, txt, parse_mode="HTML")
        bot.answer_callback_query(call.id, "Statistika yangilandi")

def refresh_vps_panel(call, host_id):
    container_id = str(db.get_host(host_id)['path_id'])
    info = vps_manager.get_info(container_id)
    status = info.get('status', 'stopped') if info else 'stopped'
    ip = info.get('ip', 'N/A') if info else 'N/A'
    
    icon = "🟢" if status == "running" else "🔴"
    
    txt = f"🖥 <b>VPS Boshqaruv Paneli</b>\n"
    txt += f"━━━━━━━━━━━━━━━\n"
    txt += f"🆔 <b>ID:</b> <code>{host_id}</code>\n"
    txt += f"🌍 <b>IP:</b> <code>{ip}</code>\n"
    txt += f"📊 <b>Status:</b> {icon} {status.upper()}\n"
    txt += f"━━━━━━━━━━━━━━━\n"
    txt += "⚙️ <i>Serverni boshqarish uchun tugmalardan foydalaning:</i>"
    
    try:
        bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=vps_control_kb(host_id, status), parse_mode="HTML")
    except: pass
