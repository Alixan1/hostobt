from loader import bot
from telebot.types import CallbackQuery
from utils.db_api.sqlite import db
from utils.vps.controller import vps_manager
from keyboards.default.menu import vps_control_kb
import time

# Helper to check ownership
def check_owner(call, host_id):
    host = db.get_host(host_id)
    if not host or host['user_id'] != call.from_user.id:
        bot.answer_callback_query(call.id, "Host sizniki emas!")
        return None
    return host

@bot.callback_query_handler(func=lambda call: call.data.startswith('vps_'))
def vps_action_handler(call: CallbackQuery):
    action = call.data.split('_')[1] # start, stop, reboot, reinstall, root, monitor
    host_id = int(call.data.split('_')[2])
    
    host = check_owner(call, host_id)
    if not host: return
    
    # Check if container exists in vps_manager (simulated)
    # If not, create it (lazy init for simulation)
    # We use path_id as container_id for mapping simplicity in this demo, 
    # OR we use the container_id mapped.
    # Let's assume we map host_id -> container_id logic here. 
    # For simulation, we treat host_id string as container key if we want stable state.
    container_id = str(host_id)
    
    info = vps_manager.get_info(container_id)
    if not info and action not in ['reinstall']: 
        # Create default state if missing
        vps_manager.create_container(call.from_user.id, host['plan_id'], "Ubuntu 22.04", "Uzbekistan")
        info = vps_manager.get_info(container_id)

    if action == 'start':
        success, msg = vps_manager.start_vps(container_id)
        bot.answer_callback_query(call.id, msg)
        refresh_vps_panel(call, host_id)
        
    elif action == 'stop':
        success, msg = vps_manager.stop_vps(container_id)
        bot.answer_callback_query(call.id, msg)
        refresh_vps_panel(call, host_id)

    elif action == 'reboot':
        bot.answer_callback_query(call.id, "Rebooting...")
        vps_manager.reboot_vps(container_id)
        bot.send_message(call.message.chat.id, "✅ VPS qayta ishga tushdi.")
        refresh_vps_panel(call, host_id)

    elif action == 'reinstall':
        # Ask for OS? For now default Ubuntu
        bot.answer_callback_query(call.id, "Reinstalling...")
        bot.edit_message_text("⏳ OS o'rnatilmoqda... (5 soniya)", call.message.chat.id, call.message.message_id)
        success, msg = vps_manager.reinstall_os(container_id, "Ubuntu 22.04")
        bot.send_message(call.message.chat.id, msg)
        refresh_vps_panel(call, host_id)

    elif action == 'root':
        info = vps_manager.get_info(container_id)
        if info:
            ip = info.get('ip', '1.1.1.1')
            pwd = info.get('root_pass', '****')
            bot.send_message(call.message.chat.id, f"🔑 <b>Root Access:</b>\nIP: {ip}\nUser: root\nPass: <code>{pwd}</code>", parse_mode="HTML")
        else:
            bot.answer_callback_query(call.id, "Info yo'q")

    elif action == 'monitor':
        from utils.vps.monitor import monitor
        stats = monitor.get_stats(container_id)
        txt = f"📊 <b>VPS Monitor:</b>\n"
        txt += f"CPU: {stats['cpu']}%\n"
        txt += f"RAM: {stats['ram']} MB\n"
        txt += f"Disk: {stats['disk']} GB\n"
        bot.answer_callback_query(call.id, "Statistika yangilandi", show_alert=True)
        # In real app sending a graph image

def refresh_vps_panel(call, host_id):
    container_id = str(host_id)
    info = vps_manager.get_info(container_id)
    status = info['status'] if info else 'stopped'
    
    txt = f"🖥 <b>VPS Boshqaruv:</b>\nID: {host_id}\nStatus: {status}\nIP: {info.get('ip', 'N/A')}"
    try:
        bot.edit_message_text(txt, call.message.chat.id, call.message.message_id, reply_markup=vps_control_kb(host_id, status), parse_mode="HTML")
    except: pass
