from loader import bot
from telebot.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from utils.db_api.sqlite import db

# Need ref to sqlite updates for referral logic, but we'll mock or assume columns for now
# Ideally we add 'referrer_id' to users table.
# Let's add that to loader.py in next pass if needed, or just handle logic here.

@bot.message_handler(func=lambda message: message.text in ["🗣 Referal", "🗣 Referral", "🗣 Партнерка"])
def referral_handler(message: Message):
    user_id = message.from_user.id
    bot_username = bot.get_me().username
    link = f"https://t.me/{bot_username}?start={user_id}"
    
    # Mock stats
    count = 0
    earnings = 0
    
    text = f"🗣 <b>Referal Tizimi</b>\n\n"
    text += f"Sizning havolangiz:\n<code>{link}</code>\n\n"
    text += f"👥 Taklif qilingan: {count} ta\n"
    text += f"💰 Ishlangan summa: {earnings} so'm\n\n"
    text += "Har bir taklif qilingan do'stingiz uchun 1000 so'm olasiz!"
    
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("💸 Pulni yechib olish", callback_data="withdraw_ref"))
    
    bot.send_message(message.chat.id, text, reply_markup=markup, parse_mode="HTML")

@bot.callback_query_handler(func=lambda call: call.data == 'withdraw_ref')
def withdraw_ref(call: CallbackQuery):
    bot.answer_callback_query(call.id, "Minimal summa: 50,000 so'm", show_alert=True)
