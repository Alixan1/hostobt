from loader import bot
from telebot.types import CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from utils.db_api.sqlite import db

def referral_inline(call: CallbackQuery):
    user_id = call.from_user.id
    bot_username = bot.get_me().username
    
    link = f"https://t.me/{bot_username}?start={user_id}"
    
    text = "🗣 <b>Referral Tizimi</b>\n\n"
    text += f"🔗 Sizning havolangiz:\n<code>{link}</code>\n\n"
    text += "Har bir taklif qilingan do'stingiz uchun <b>50 so'm</b> bonus oling!\n"
    text += "Do'stingiz ushbu havola orqali botga kirishi kerak."

    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("🔙 Ortga", callback_data="main_menu"))
    
    bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=markup, parse_mode="HTML")
