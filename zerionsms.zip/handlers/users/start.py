from telebot.types import Message, CallbackQuery
from loader import bot
from utils.db_api.sqlite import db
from utils.locales import get_text
from keyboards.default.menu import main_menu_inline
from config import OWNER_ID, ADMINS

@bot.message_handler(commands=['start'])
def bot_start(message: Message):
    user_id = message.from_user.id
    full_name = message.from_user.full_name
    username = message.from_user.username
    
    # Check if user exists BEFORE adding to know if new
    user = db.get_user(user_id)
    
    if not user:
        # New user found
        db.add_user(user_id, full_name, username)
        
        # Check for referral args
        args = message.text.split()
        if len(args) > 1:
            try:
                referrer_id = int(args[1])
                if referrer_id != user_id:
                    # Credit Referrer (50 sum)
                    db.update_balance(referrer_id, 50)
                    try:
                        bot.send_message(referrer_id, f"🎉 <b>Yangi Referal!</b>\n\nSizga 50 so'm bonus berildi!", parse_mode="HTML")
                    except: pass
            except ValueError:
                pass
                
        user = db.get_user(user_id) # Refresh
    
    lang = user['language'] if user else 'uz'
    
    is_admin = user_id in ADMINS or user_id == OWNER_ID
    
    text = f"👋 <b>Assalomu alaykum, {full_name}!</b>\n\n"
    text += "🚀 <b>HostBot</b> - Zamonaviy va Tezkor Hosting Botiga xush kelibsiz.\n\n"
    text += "💎 <i>Bizning xizmatlarimiz:</i>\n"
    text += "• 🐍 Python Hosting (FastAPI, Django, Botlar)\n"
    text += "• 💻 VPS & Dedicated Serverlar\n"
    text += "• 🛡 24/7 Qo'llab-quvvatlash\n\n"
    text += "👇 <b>Boshqaruv uchun menyudan foydalaning:</b>"
    
    bot.send_message(message.chat.id, text, parse_mode="HTML", reply_markup=main_menu_inline(is_admin, lang))

# Remove old text handlers for ReplyKeyboard buttons as they are no longer used
# Clean up old imports in next steps if needed
