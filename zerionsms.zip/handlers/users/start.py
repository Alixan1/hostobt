from telebot.types import Message, ReplyKeyboardMarkup, KeyboardButton
from loader import bot
from utils.db_api.sqlite import db
from utils.locales import get_text
from keyboards.default.menu import main_menu_kb
from config import OWNER_ID, ADMINS

@bot.message_handler(commands=['start'])
def bot_start(message: Message):
    user_id = message.from_user.id
    full_name = message.from_user.full_name
    username = message.from_user.username
    
    # Add user (default lang 'uz')
    db.add_user(user_id, full_name, username)
    user = db.get_user(user_id)
    lang = user['language'] if user else 'uz'

    # Check if there is a language param (e.g. /start lang=uz logic, but usually done via menu)
    text = get_text('start_welcome', lang).format(full_name)
    
    # Language Selection Keyboard
    lang_kb = ReplyKeyboardMarkup(resize_keyboard=True, row_width=3)
    lang_kb.add(KeyboardButton("🇺🇿 O'zbek"), KeyboardButton("🇷🇺 Русский"), KeyboardButton("🇬🇧 English"))
    
    bot.send_message(message.chat.id, text, parse_mode="HTML", reply_markup=lang_kb)

@bot.message_handler(func=lambda message: message.text in ["🇺🇿 O'zbek", "🇷🇺 Русский", "🇬🇧 English"])
def set_language_handler(message: Message):
    user_id = message.from_user.id
    text = message.text
    
    lang_code = 'uz'
    if "Русский" in text: lang_code = 'ru'
    elif "English" in text: lang_code = 'en'
    
    db.set_language(user_id, lang_code)
    
    confirm_text = get_text('lang_selected', lang_code)
    menu_text = get_text('main_menu', lang_code)
    
    is_admin = user_id in ADMINS or user_id == OWNER_ID
    # We need to update main_menu_kb to support language args or dynamic text
    # For now, let's create a dynamic one here or refactor menu.py
    # Refactoring menu.py is better.
    
    bot.send_message(message.chat.id, confirm_text, reply_markup=main_menu_kb(is_admin, lang_code))
