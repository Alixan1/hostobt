from loader import bot
from telebot.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from utils.db_api.sqlite import db

@bot.callback_query_handler(func=lambda call: call.data == "settings")
def settings_inline(call: CallbackQuery):
    user_id = call.from_user.id
    user = db.get_user(user_id)
    lang = user['language'] if user else 'uz'
    
    text = f"⚙️ <b>Sozlamalar</b>\n\nHozirgi til: {lang.upper()}\nTilni o'zgartirish uchun tanlang:"
    
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton("🇺🇿 O'zbekcha", callback_data="set_lang_uz"))
    markup.add(InlineKeyboardButton("🇷🇺 Русский", callback_data="set_lang_ru"))
    markup.add(InlineKeyboardButton("🇬🇧 English", callback_data="set_lang_en"))
    markup.add(InlineKeyboardButton("🔙 Ortga", callback_data="main_menu"))
    
    bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=markup, parse_mode="HTML")

@bot.callback_query_handler(func=lambda call: call.data.startswith('set_lang_'))
def set_language(call: CallbackQuery):
    lang = call.data.split('_')[2]
    user_id = call.from_user.id
    
    db.set_language(user_id, lang)
    
    msgs = {
        'uz': "✅ Til o'zgartirildi: O'zbekcha",
        'ru': "✅ Язык изменен: Русский",
        'en': "✅ Language changed: English"
    }
    
    bot.answer_callback_query(call.id, msgs.get(lang, "OK"))
    bot.delete_message(call.message.chat.id, call.message.message_id)
    
    from keyboards.default.menu import main_menu_kb
    bot.send_message(call.message.chat.id, msgs.get(lang, "OK"), reply_markup=main_menu_kb(False, lang))
