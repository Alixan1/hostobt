from loader import bot
from telebot.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from utils.db_api.sqlite import db
from config import UPLOAD_DIR, ADMINS
from utils.misc.process_manager import pm
import os
import subprocess
import html

# --- Terminal Handler ---

@bot.callback_query_handler(func=lambda call: call.data.startswith('term_'))
def terminal_start(call: CallbackQuery):
    host_id = int(call.data.split('_')[1])
    user_id = call.from_user.id
    
    host = db.get_host(host_id)
    if not host:
        bot.answer_callback_query(call.id, "❌ Host topilmadi!")
        return

    # Check owner OR Admin
    if host['user_id'] != user_id and user_id not in ADMINS:
        bot.answer_callback_query(call.id, "❌ Host sizniki emas!")
        return

    path_id = host['path_id']
    work_dir = os.path.join(UPLOAD_DIR, path_id)
    
    # Ensure dir exists
    if not os.path.exists(work_dir):
        os.makedirs(work_dir, exist_ok=True)
    
    # Auto-populate if empty (to avoid empty ls output confusion)
    if not os.listdir(work_dir):
        with open(os.path.join(work_dir, "README.txt"), "w") as f:
            f.write("Welcome to your VPS space!\nYou can run python scripts here.")
        
    msg_text = f"💻 <b>Web Terminal (v1.0)</b>\n\n"
    msg_text += f"📂 <b>Path:</b> <code>/home/container/</code>\n"
    msg_text += f"👤 <b>User:</b> <code>root</code>\n\n"
    msg_text += "👇 <i>Buyruq kiriting (masalan: `ls`, `pip install aiogram`, `python main.py`):</i>\n"
    msg_text += "To'xtatish uchun /exit deb yozing."

    msg = bot.send_message(call.message.chat.id, msg_text, parse_mode="HTML")
    
    # Register next step for command input
    bot.register_next_step_handler(msg, process_terminal_command, host_id, work_dir, msg.message_id)

def process_terminal_command(message: Message, host_id, work_dir, prev_msg_id):
    user_id = message.from_user.id
    cmd = message.text
    
    if cmd in ['/exit', '/stop', 'exit']:
        bot.send_message(message.chat.id, "🔌 Terminal yopildi.")
        return

    if cmd in ['clear', 'cls']:
        bot.delete_message(message.chat.id, message.message_id) # Delete command
        bot.delete_message(message.chat.id, prev_msg_id) # Delete old output
        
        # New clean session
        new_msg = bot.send_message(message.chat.id, f"💻 <b>Terminal (Tozalandi)</b>\n👇 <i>Buyruq kiriting:</i>", parse_mode="HTML")
        bot.register_next_step_handler(new_msg, process_terminal_command, host_id, work_dir, new_msg.message_id)
        return

    # Delete command message to keep clean (optional, keeping it for history is usually better)
    # bot.delete_message(message.chat.id, message.message_id)

    # Status message
    status_msg = bot.send_message(message.chat.id, f"⏳ <code>root@host:~$ {cmd}</code>\nExecuting...", parse_mode="HTML")
    
    try:
        # Check privilege
        host = db.get_host(host_id)
        is_root = host['is_privileged'] if host and 'is_privileged' in host.keys() else 0

        # Security check: Block dangerous commands
        # Simple string matching (can be bypassed, but sufficient for basic bot)
        blocked_keywords = [
            'rm ', 'rm-', 'mv ', 'cp ', 'chmod', 'chown', 'sudo', 'su ', 
            '/etc', '/bin', '/usr', '/var',
            ':(){ :|:& };:', 'mkfs', 'dd '
        ]
        
        # Check if any blocked keyword exists in the command (ONLY if not root)
        # Removed 'cd' manually from strict list, handled by logic below
        if not is_root and (any(b in cmd for b in blocked_keywords) or cmd.strip() in ['rm', 'mv', 'cp', 'su', 'sudo', 'ls /']):
             bot.edit_message_text(f"❌ <b>Xatolik:</b> Xavfsizlik tufayli ushbu buyruq bloklangan!", message.chat.id, status_msg.message_id, parse_mode="HTML")
             bot.register_next_step_handler(status_msg, process_terminal_command, host_id, work_dir, status_msg.message_id)
             return

        # Custom CD Logic (Persistent Shell Simulation)
        if cmd.strip().startswith('cd'):
            parts = cmd.strip().split(maxsplit=1)
            target_dir = parts[1].strip() if len(parts) > 1 else "~"
            
            # Need to get host root again to be sure
            host_row = db.get_host(host_id)
            root_path = os.path.abspath(os.path.join(UPLOAD_DIR, host_row['path_id']))
            
            # Handle ~ alias
            if target_dir.startswith("~"):
                 # Replace ~ with root path
                 expanded = target_dir.replace("~", root_path, 1)
                 new_work_dir = os.path.abspath(expanded)
            else:
                 new_work_dir = os.path.abspath(os.path.join(work_dir, target_dir))
            
            # Security: Ensure we are still inside user's root using commonpath
            if os.path.commonpath([new_work_dir, root_path]) == root_path:
                if os.path.exists(new_work_dir) and os.path.isdir(new_work_dir):
                    work_dir = new_work_dir # Update state for next step
                    
                    # Pretty path for display
                    rel_path = os.path.relpath(work_dir, root_path)
                    nice_path = "/home/container" if rel_path == "." else f"/home/container/{rel_path}"
                    
                    bot.edit_message_text(f"📂 <b>Directory changed:</b>\n<code>{nice_path}</code>", message.chat.id, status_msg.message_id, parse_mode="HTML")
                    bot.register_next_step_handler(status_msg, process_terminal_command, host_id, work_dir, status_msg.message_id)
                    return
                else:
                    bot.edit_message_text(f"❌ <b>Error:</b> Directory not found.", message.chat.id, status_msg.message_id, parse_mode="HTML")
                    bot.register_next_step_handler(status_msg, process_terminal_command, host_id, work_dir, status_msg.message_id)
                    return
            else:
                 bot.edit_message_text(f"❌ <b>Xatolik:</b> Ruxsat etilmagan hudud! (Sandbox Violation)", message.chat.id, status_msg.message_id, parse_mode="HTML")
                 bot.register_next_step_handler(status_msg, process_terminal_command, host_id, work_dir, status_msg.message_id)
                 return

        # Virtual PWD (Override for consistency)
        if cmd.strip() == 'pwd':
             host_row = db.get_host(host_id)
             root_path = os.path.abspath(os.path.join(UPLOAD_DIR, host_row['path_id']))
             rel_path = os.path.relpath(work_dir, root_path)
             nice_path = "/home/container" if rel_path == "." else f"/home/container/{rel_path}"
             
             res_text = f"💻 <b>Output:</b>\n<pre>{nice_path}</pre>\n\n👇 Keyingi buyruqni kiriting:"
             bot.edit_message_text(res_text, message.chat.id, status_msg.message_id, parse_mode="HTML")
             bot.register_next_step_handler(status_msg, process_terminal_command, host_id, work_dir, status_msg.message_id)
             return

        # Windows Compatibility Layer
        import sys
        if sys.platform == 'win32':
             # Simple alias replacement for common commands
             if cmd.strip() == 'ls' or cmd.startswith('ls '):
                 cmd = cmd.replace('ls', 'dir /B', 1)
             elif cmd.strip() == 'cat' or cmd.startswith('cat '):
                 cmd = cmd.replace('cat', 'type', 1)
             elif cmd.strip() == 'clear':
                 cmd = 'cls'

        # Auto-Nohup for Python Scripts
        if cmd.strip().startswith(('python ', 'python3 ')) and cmd.strip().endswith('.py'):
            try:
                parts = cmd.strip().split()
                if len(parts) >= 2:
                    script_name = parts[1] # Take filename
                    
                    # Resolve full path
                    full_script_path = os.path.abspath(os.path.join(work_dir, script_name))
                    
                    # Check existence
                    if os.path.exists(full_script_path):
                        # Security check
                        host_row = db.get_host(host_id)
                        root_path = os.path.abspath(os.path.join(UPLOAD_DIR, host_row['path_id']))
                        
                        if os.path.commonpath([full_script_path, root_path]) == root_path:
                            success, info = pm.start_script(host_id, full_script_path)
                            if success:
                                res_text = f"✅ <b>Auto-Nohup:</b>\n{info}\n\n<i>Jarayon orqa fonda ishga tushdi (Loglar faylga yoziladi).</i>"
                            else:
                                res_text = f"❌ <b>Xatolik:</b>\n{info}"
                            
                            bot.edit_message_text(res_text, message.chat.id, status_msg.message_id, parse_mode="HTML")
                            bot.register_next_step_handler(status_msg, process_terminal_command, host_id, work_dir, status_msg.message_id)
                            return
            except: pass # Fallback to normal execution if parsing fails

        # Execute
        # Timeout 30s
        proc = subprocess.run(cmd, shell=True, cwd=work_dir, capture_output=True, text=True, timeout=30)
        
        output = proc.stdout
        error = proc.stderr
        
        full_res = ""
        if output: full_res += f"{output}\n"
        if error: full_res += f"⛔ {error}\n"
        if not full_res: full_res = "[No Output]"
        
        # Truncate if too long
        if len(full_res) > 3500:
            full_res = full_res[:3500] + "\n... [Truncated]"
        
        res_text = f"💻 <b>Output:</b>\n<pre>{html.escape(full_res)}</pre>\n\n👇 Keyingi buyruqni kiriting:"
        
        bot.edit_message_text(res_text, message.chat.id, status_msg.message_id, parse_mode="HTML")
        
    except subprocess.TimeoutExpired:
        bot.edit_message_text("❌ <b>Timeout:</b> Command took too long.", message.chat.id, status_msg.message_id, parse_mode="HTML")
    except Exception as e:
        bot.edit_message_text(f"❌ <b>Error:</b> {e}", message.chat.id, status_msg.message_id, parse_mode="HTML")
    
    # Loop back
    bot.register_next_step_handler(status_msg, process_terminal_command, host_id, work_dir, status_msg.message_id)
