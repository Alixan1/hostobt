from telebot.types import Message
from loader import bot

@bot.message_handler(commands=['help'])
@bot.message_handler(func=lambda message: message.text == "🆘 Yordam")
def bot_help(message: Message):
    text = "SOS 🆘 Yordam Bo'limi:\n\n"
    text += "1. <b>Host Sotib Olish</b>: 'Host Sotib Olish' tugmasini bosing va reja tanlang.\n"
    text += "2. <b>Fayl Yuklash</b>: Sotib olgandan so'ng, 'Mening Hostlarim' -> Hostni tanlang -> 'Fayl Menejeri'.\n"
    text += "3. <b>Terminal</b>: Bot ichidan buyruqlar (pip install) bajarish uchun.\n\n"
    text += "⚠️ Muammo bo'lsa Adminga yozing: @AdminUser (O'zgartiring)"
    
    bot.send_message(message.chat.id, text, parse_mode="HTML")
