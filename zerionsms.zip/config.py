from dotenv import load_dotenv
import os

load_dotenv()

API_ID = int(os.getenv("API_ID", "0"))
API_HASH = os.getenv("API_HASH", "")
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))

# Default settings (can be overridden by DB settings later)
DEFAULT_DAILY_PRICE = int(os.getenv("DAILY_PRICE", "1000"))
DEFAULT_HOURLY_PRICE = int(os.getenv("HOURLY_PRICE", "500"))
DEFAULT_WEEKLY_PRICE = int(os.getenv("WEEKLY_PRICE", "6000"))
DEFAULT_MONTHLY_PRICE = int(os.getenv("MONTHLY_PRICE", "20000"))
DEFAULT_YEARLY_PRICE = int(os.getenv("YEARLY_PRICE", "200000"))

DEFAULT_ADMIN_CARD = os.getenv("ADMIN_CARD", "0000 0000 0000 0000")
TAGLINE = os.getenv("TAGLINE", "Reklama tarqatuvchi bot @avtoreklamachibot")

# RasmiyPay
RASMIYPAY_SHOP_ID = os.getenv("RASMIYPAY_SHOP_ID", "")
RASMIYPAY_SHOP_KEY = os.getenv("RASMIYPAY_SHOP_KEY", "")

# WebApp URL (if needed)
WEBAPP_URL = os.getenv("WEBAPP_URL", "")

MAX_MESSAGE_INTERVAL_MINUTES = 30
MIN_MESSAGE_INTERVAL_MINUTES = 2
