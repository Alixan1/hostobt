import os

# Bot Token
TOKEN = '8470439773:AAFoPukzg1-o3zvEtSMhE6XGaQvmnxX9tLw' # Yangi tokenni shu yerga qo'ying
OWNER_ID = 6489892269
ADMINS = [6489892269]

# Paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_DIR = os.path.join(BASE_DIR, 'upload_bots')
DB_PATH = os.path.join(BASE_DIR, 'inf', 'bot_data.db')

# Limits
FREE_LIMIT = 1  # Free user bot limit
# Plan limits will be in DB

DEFAULT_ROOT_PASS = '12345678' # Change this in config if needed
PAYMENT_CARD = "8600 0000 0000 0000" # Card for balance top-up

