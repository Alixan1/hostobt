import random

class VPSMonitor:
    @staticmethod
    def get_stats(container_id):
        """Generates fake usage stats based on random fluctuation."""
        # In real world, would query docker stats or libvirt
        cpu_usage = random.randint(1, 90)
        ram_usage = random.randint(200, 4000) # MB
        disk_usage = random.randint(10, 50) # GB
        net_in = random.randint(100, 50000) # KB
        net_out = random.randint(100, 50000) # KB
        
        return {
            "cpu": cpu_usage,
            "ram": ram_usage,
            "disk": disk_usage,
            "net_in": net_in,
            "net_out": net_out
        }

    @staticmethod
    def generate_graph(container_id):
        """Placeholder for graph generation (would use matplotlib)."""
        # Return path to a fake image or generate one if libraries exist
        return None 

monitor = VPSMonitor()
