import time
import random
import logging
import json
import os
from datetime import datetime
from config import BASE_DIR

logger = logging.getLogger(__name__)

class VPSController:
    def __init__(self):
        self.state_file = os.path.join(BASE_DIR, 'inf', 'vps_states.json')
        self.load_states()

    def load_states(self):
        if os.path.exists(self.state_file):
            try:
                with open(self.state_file, 'r') as f:
                    self.states = json.load(f)
            except:
                self.states = {}
        else:
            self.states = {}

    def save_states(self):
        try:
            with open(self.state_file, 'w') as f:
                json.dump(self.states, f, indent=4)
        except Exception as e:
            logger.error(f"Failed to save VPS states: {e}")

    def create_container(self, user_id, plan_id, os_template, location):
        """Simulates creating a Docker/LXC container."""
        import uuid
        container_id = str(uuid.uuid4())[:12]
        
        # Simulate network assignment
        ip_base = "192.168.1."
        ip_addr = f"{ip_base}{random.randint(10, 250)}"
        
        logger.info(f"Creating container {container_id} for user {user_id}...")
        time.sleep(2) # Fake delay
        
        self.states[container_id] = {
            "status": "running",
            "ip": ip_addr,
            "os": os_template,
            "location": location,
            "plan_id": plan_id,
            "created_at": str(datetime.now()),
            "root_pass": self._generate_password(),
            "uptime": 0
        }
        self.save_states()
        return container_id, ip_addr

    def start_vps(self, container_id):
        if container_id not in self.states:
            return False, "VPS topilmadi"
        
        logger.info(f"Starting VPS {container_id}...")
        time.sleep(1)
        self.states[container_id]['status'] = "running"
        self.save_states()
        return True, "VPS ishga tushdi."

    def stop_vps(self, container_id):
        if container_id not in self.states:
            return False, "VPS topilmadi"
            
        logger.info(f"Stopping VPS {container_id}...")
        time.sleep(1)
        self.states[container_id]['status'] = "stopped"
        self.save_states()
        return True, "VPS to'xtatildi."

    def reboot_vps(self, container_id):
        if container_id not in self.states:
            return False, "VPS topilmadi"
            
        logger.info(f"Rebooting VPS {container_id}...")
        self.states[container_id]['status'] = "rebooting"
        self.save_states()
        time.sleep(3)
        self.states[container_id]['status'] = "running"
        self.save_states()
        return True, "VPS qayta ishga tushdi."

    def reinstall_os(self, container_id, new_os_template):
        if container_id not in self.states:
            return False, "VPS topilmadi"
            
        logger.info(f"Reinstalling OS on {container_id} to {new_os_template}...")
        self.states[container_id]['status'] = "installing"
        self.save_states()
        
        time.sleep(5) # Long delay for install
        
        self.states[container_id]['os'] = new_os_template
        self.states[container_id]['root_pass'] = self._generate_password()
        self.states[container_id]['status'] = "running"
        self.states[container_id]['uptime'] = 0
        self.save_states()
        
        return True, f"OS muvaffaqiyatli o'rnatildi! Yangi parol: {self.states[container_id]['root_pass']}"

    def get_info(self, container_id):
        return self.states.get(container_id, None)

    def _generate_password(self, length=12):
        chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*"
        return "".join(random.choice(chars) for _ in range(length))

vps_manager = VPSController()
