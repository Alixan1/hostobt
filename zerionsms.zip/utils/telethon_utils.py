from telethon import TelegramClient
from telethon.tl.functions.messages import GetDialogFiltersRequest
from telethon.tl.types import (
    DialogFilter,
    DialogFilterDefault,
    DialogFilterChatlist,
    InputPeerEmpty,
    InputPeerUser,
    InputPeerChat,
    InputPeerChannel,
    PeerUser,
    PeerChat,
    PeerChannel
)
from telethon.sessions import StringSession
from config import API_ID, API_HASH
import logging
import asyncio
from typing import List, Dict, Optional, Set

logger = logging.getLogger(__name__)

class TelegramFoldersManager:
    """
    Telegram jildlari bilan ishlash uchun to'liq sinf.
    Barcha xatoliklarni to'g'ri qayta ishlaydi va batafsil log yozadi.
    """
    
    def __init__(self, session_path: str, api_id: int = None, api_hash: str = None):
        """
        TelegramFoldersManager ni yaratish
        
        Args:
            session_path: Session fayl yo'li
            api_id: Telegram API ID (config dan oladi)
            api_hash: Telegram API Hash (config dan oladi)
        """
        self.session_path = session_path
        self.api_id = api_id or API_ID
        self.api_hash = api_hash or API_HASH
        self.client = None
        self._entity_cache = {}
        
    async def __aenter__(self):
        """Context manager kirish"""
        await self.connect()
        return self
        
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Context manager chiqish"""
        await self.disconnect()
        
    async def connect(self):
        """Telegram ga ulanish (Retry bilan)"""
        max_retries = 5
        for attempt in range(max_retries):
            try:
                if not self.session_path:
                    raise ValueError("Session path bo'sh!")
                
                # StringSession bilan client yaratish
                try:
                    # Session stringni tozalash va tekshirish
                    session_str = self.session_path.strip() if self.session_path else ""
                    self.client = TelegramClient(StringSession(session_str), self.api_id, self.api_hash)
                except Exception as e:
                    logger.error(f"Invalid session string: {e}")
                    raise ValueError("Akkaunt sessiyasi yaroqsiz! Iltimos akkauntni o'chirib qayta ulang.")
                await self.client.connect()
                
                if not await self.client.is_user_authorized():
                    raise PermissionError("Foydalanuvchi avtorizatsiya qilinmagan!")
                    
                me = await self.client.get_me()
                logger.info(f"✓ Muvaffaqiyatli ulanildi: {me.username or me.first_name} (ID: {me.id})")
                return True
                
            except Exception as e:
                # Agar database locked bo'lsa kutamiz
                if "database is locked" in str(e) and attempt < max_retries - 1:
                    wait_time = (attempt + 1) * 2
                    logger.warning(f"Database locked. Qayta urinish {wait_time}s dan keyin... ({attempt+1}/{max_retries})")
                    if self.client:
                        await self.client.disconnect()
                    await asyncio.sleep(wait_time)
                else:
                    logger.error(f"✗ Ulanishda xatolik: {e}")
                    raise
            
    async def disconnect(self):
        """Telegram dan uzilish"""
        if self.client and self.client.is_connected():
            await self.client.disconnect()
            logger.info("Telegram dan uzildi")
    
    def _extract_text(self, text_obj):
        """
        TextWithEntities yoki oddiy str dan matnni ajratib olish
        
        Args:
            text_obj: TextWithEntities obyekti yoki oddiy str
            
        Returns:
            Oddiy str matn
        """
        if text_obj is None:
            return ''
            
        # Agar oddiy str bo'lsa
        if isinstance(text_obj, str):
            return text_obj
            
        # Agar TextWithEntities bo'lsa
        if hasattr(text_obj, 'text'):
            return text_obj.text
            
        # Boshqa hollarda repr dan olish
        try:
            return str(text_obj)
        except:
            return ''
            
    async def _get_entity_safe(self, peer):
        """
        Peer dan entity ni xavfsiz olish, cache ishlatish bilan
        
        Args:
            peer: InputPeer yoki Peer obyekti
            
        Returns:
            Entity obyekti yoki None
        """
        try:
            # Cache tekshirish
            peer_id = None
            if hasattr(peer, 'user_id'):
                peer_id = peer.user_id
            elif hasattr(peer, 'chat_id'):
                peer_id = peer.chat_id
            elif hasattr(peer, 'channel_id'):
                peer_id = peer.channel_id
                
            if peer_id and peer_id in self._entity_cache:
                return self._entity_cache[peer_id]
                
            # Entity olish
            entity = await self.client.get_entity(peer)
            
            # Cache ga qo'shish
            if peer_id:
                self._entity_cache[peer_id] = entity
                
            return entity
            
        except Exception as e:
            logger.debug(f"Entity ololmadik {peer}: {e}")
            return None
            
    async def get_user_folders(self) -> List[Dict]:
        """
        Foydalanuvchining barcha jildlarini olish
        
        Returns:
            Jildlar ro'yxati: [{'id': int, 'title': str, 'type': str, 'emoji': str}, ...]
        """
        try:
            if not self.client or not self.client.is_connected():
                await self.connect()
                
            logger.info("Jildlarni olyapmiz...")
            
            # Dialog filtersni olish
            response = await self.client(GetDialogFiltersRequest())
            
            # Response dan filtersni ajratib olish
            if hasattr(response, 'filters'):
                filters = response.filters
            else:
                filters = response if isinstance(response, list) else []
                
            logger.info(f"Topildi: {len(filters)} ta filter")
            
            result = []
            
            for idx, f in enumerate(filters):
                try:
                    folder_info = {
                        'id': None,
                        'title': 'Unknown',
                        'type': type(f).__name__,
                        'emoji': '',
                        'is_default': False,
                        'is_chatlist': False
                    }
                    
                    # DialogFilter (oddiy jild)
                    if isinstance(f, DialogFilter):
                        folder_info['id'] = f.id
                        # Title ni to'g'ri olish (TextWithEntities yoki oddiy str)
                        folder_info['title'] = self._extract_text(f.title)
                        folder_info['emoji'] = getattr(f, 'emoticon', '')
                        folder_info['is_default'] = False
                        
                        logger.info(f"  {idx+1}. DialogFilter: '{folder_info['title']}' (ID: {f.id}, Emoji: {folder_info['emoji']})")
                        result.append(folder_info)
                        
                    # DialogFilterDefault (default "All Chats")
                    elif isinstance(f, DialogFilterDefault):
                        folder_info['id'] = 0
                        folder_info['title'] = 'All Chats'
                        folder_info['is_default'] = True
                        
                        logger.info(f"  {idx+1}. DialogFilterDefault: 'All Chats'")
                        result.append(folder_info)
                        
                    # DialogFilterChatlist (ulashilgan jildlar)
                    elif isinstance(f, DialogFilterChatlist):
                        folder_info['id'] = f.id
                        # Title ni to'g'ri olish
                        folder_info['title'] = self._extract_text(f.title)
                        folder_info['emoji'] = getattr(f, 'emoticon', '')
                        folder_info['is_chatlist'] = True
                        
                        logger.info(f"  {idx+1}. DialogFilterChatlist: '{folder_info['title']}' (ID: {f.id})")
                        result.append(folder_info)
                        
                    else:
                        logger.warning(f"  {idx+1}. Noma'lum filter turi: {type(f).__name__}")
                        
                except Exception as e:
                    logger.error(f"Filter {idx} ni qayta ishlashda xatolik: {e}")
                    continue
                    
            logger.info(f"✓ Jami {len(result)} ta jild topildi")
            return result
            
        except Exception as e:
            logger.error(f"✗ Jildlarni olishda xatolik: {e}")
            return []
            
    async def get_folder_chats(self, folder_id: int) -> List[Dict]:
        """
        Ma'lum bir jilddagi barcha chatlarni olish
        
        Args:
            folder_id: Jild ID si
            
        Returns:
            Chatlar ro'yxati: [{'id': int, 'title': str, 'username': str, 'type': str}, ...]
        """
        try:
            if not self.client or not self.client.is_connected():
                await self.connect()
                
            logger.info(f"Jild {folder_id} uchun chatlarni olyapmiz...")
            
            # Dialog filtersni olish
            response = await self.client(GetDialogFiltersRequest())
            
            if hasattr(response, 'filters'):
                filters = response.filters
            else:
                filters = response if isinstance(response, list) else []
                
            # Kerakli filterni topish
            target_filter = None
            for f in filters:
                if hasattr(f, 'id') and f.id == folder_id:
                    target_filter = f
                    break
                    
            if not target_filter:
                logger.warning(f"Filter ID {folder_id} topilmadi")
                return []
                
            logger.info(f"Filter topildi: {getattr(target_filter, 'title', 'Unknown')}")
            
            results = []
            processed_ids = set()
            
            # 1. Aniq ko'rsatilgan chatlar (include_peers)
            if hasattr(target_filter, 'include_peers'):
                logger.info(f"Include peers: {len(target_filter.include_peers)} ta")
                
                for peer in target_filter.include_peers:
                    try:
                        entity = await self._get_entity_safe(peer)
                        
                        if entity:
                            chat_info = self._extract_chat_info(entity)
                            if chat_info and chat_info['id'] not in processed_ids:
                                results.append(chat_info)
                                processed_ids.add(chat_info['id'])
                                logger.debug(f"  + {chat_info['title']}")
                                
                    except Exception as e:
                        logger.debug(f"Peer ni qayta ishlashda xatolik: {e}")
                        continue
                        
            # 2. Pinned chatlar
            if hasattr(target_filter, 'pinned_peers'):
                logger.info(f"Pinned peers: {len(target_filter.pinned_peers)} ta")
                
                for peer in target_filter.pinned_peers:
                    try:
                        entity = await self._get_entity_safe(peer)
                        
                        if entity:
                            chat_info = self._extract_chat_info(entity)
                            if chat_info and chat_info['id'] not in processed_ids:
                                results.append(chat_info)
                                processed_ids.add(chat_info['id'])
                                logger.debug(f"  + (pinned) {chat_info['title']}")
                                
                    except Exception as e:
                        logger.debug(f"Pinned peer xatolik: {e}")
                        continue
            
            # 3. Kategoriya bo'yicha qo'shish (contacts, non_contacts, groups, etc.)
            await self._add_chats_by_categories(target_filter, results, processed_ids)
            
            # 4. Exclude qilingan chatlarni o'chirish
            if hasattr(target_filter, 'exclude_peers'):
                exclude_ids = set()
                for peer in target_filter.exclude_peers:
                    try:
                        entity = await self._get_entity_safe(peer)
                        if entity:
                            exclude_ids.add(entity.id)
                    except:
                        pass
                        
                if exclude_ids:
                    results = [r for r in results if r['id'] not in exclude_ids]
                    logger.info(f"Exclude qilindi: {len(exclude_ids)} ta chat")
            
            logger.info(f"✓ Jami {len(results)} ta chat topildi")
            return results
            
        except Exception as e:
            logger.error(f"✗ Jild chatlarini olishda xatolik: {e}")
            return []
            
    async def _add_chats_by_categories(self, target_filter, results: List[Dict], processed_ids: Set[int]):
        """
        Filter kategoriyalari bo'yicha chatlarni qo'shish
        
        Args:
            target_filter: Dialog filter obyekti
            results: Natijalar ro'yxati (in-place o'zgaradi)
            processed_ids: Qayta ishlanganlar ID lari
        """
        try:
            # Filter parametrlarini olish
            include_contacts = getattr(target_filter, 'contacts', False)
            include_non_contacts = getattr(target_filter, 'non_contacts', False)
            include_groups = getattr(target_filter, 'groups', False)
            include_broadcasts = getattr(target_filter, 'broadcasts', False)
            include_bots = getattr(target_filter, 'bots', False)
            exclude_muted = getattr(target_filter, 'exclude_muted', False)
            exclude_read = getattr(target_filter, 'exclude_read', False)
            exclude_archived = getattr(target_filter, 'exclude_archived', False)
            
            logger.info(f"Kategoriya filterlari: contacts={include_contacts}, groups={include_groups}, "
                       f"broadcasts={include_broadcasts}, bots={include_bots}")
            
            # Agar hech qanday kategoriya tanlanmagan bo'lsa, chiqib ketamiz
            if not any([include_contacts, include_non_contacts, include_groups, 
                       include_broadcasts, include_bots]):
                logger.info("Hech qanday kategoriya filtri yo'q")
                return
            
            # Barcha dialoglarni ko'rib chiqish
            dialog_count = 0
            added_count = 0
            
            async for dialog in self.client.iter_dialogs():
                dialog_count += 1
                
                # Allaqachon qayta ishlangan bo'lsa, o'tkazib yuborish
                if dialog.id in processed_ids:
                    continue
                    
                # Exclude shartlarini tekshirish
                if exclude_muted and dialog.dialog.muted:
                    continue
                if exclude_read and dialog.unread_count == 0:
                    continue
                if exclude_archived and getattr(dialog, 'archived', False):
                    continue
                
                entity = dialog.entity
                should_include = False
                
                # Kontaktlarni tekshirish
                if include_contacts and dialog.is_user:
                    if entity.contact or entity.mutual_contact:
                        should_include = True
                        
                # Non-kontaktlarni tekshirish
                if include_non_contacts and dialog.is_user:
                    if not (entity.contact or entity.mutual_contact):
                        should_include = True
                        
                # Guruhlarni tekshirish
                if include_groups and dialog.is_group:
                    should_include = True
                    
                # Kanallarni tekshirish
                if include_broadcasts and dialog.is_channel and not dialog.is_group:
                    should_include = True
                    
                # Botlarni tekshirish
                if include_bots and dialog.is_user and entity.bot:
                    should_include = True
                
                # Qo'shish
                if should_include:
                    chat_info = self._extract_chat_info(entity)
                    if chat_info and chat_info['id'] not in processed_ids:
                        results.append(chat_info)
                        processed_ids.add(chat_info['id'])
                        added_count += 1
                        logger.debug(f"  + (category) {chat_info['title']}")
                        
            logger.info(f"Kategoriya bo'yicha: {dialog_count} ta dialog tekshirildi, {added_count} ta qo'shildi")
            
        except Exception as e:
            logger.error(f"Kategoriya bo'yicha qo'shishda xatolik: {e}")
            
    def _extract_chat_info(self, entity) -> Optional[Dict]:
        """
        Entity dan chat ma'lumotlarini ajratib olish
        
        Args:
            entity: User, Chat yoki Channel entity
            
        Returns:
            Chat ma'lumotlari yoki None
        """
        try:
            chat_info = {
                'id': entity.id,
                'title': '',
                'username': None,
                'type': 'unknown',
                'is_bot': False,
                'is_verified': False,
                'is_scam': False
            }
            
            # Title
            if hasattr(entity, 'title'):
                chat_info['title'] = entity.title
            elif hasattr(entity, 'first_name'):
                chat_info['title'] = entity.first_name
                if hasattr(entity, 'last_name') and entity.last_name:
                    chat_info['title'] += f" {entity.last_name}"
            else:
                chat_info['title'] = f"Chat {entity.id}"
                
            # Username
            if hasattr(entity, 'username') and entity.username:
                chat_info['username'] = f"@{entity.username}"
                
            # Type
            if hasattr(entity, 'broadcast'):
                if entity.broadcast:
                    chat_info['type'] = 'channel'
                else:
                    chat_info['type'] = 'group'
            elif hasattr(entity, 'megagroup'):
                chat_info['type'] = 'supergroup' if entity.megagroup else 'group'
            elif hasattr(entity, 'bot'):
                chat_info['type'] = 'bot' if entity.bot else 'user'
                chat_info['is_bot'] = entity.bot
            else:
                chat_info['type'] = 'user'
                
            # Additional flags
            if hasattr(entity, 'verified'):
                chat_info['is_verified'] = entity.verified
            if hasattr(entity, 'scam'):
                chat_info['is_scam'] = entity.scam
                
            return chat_info
            
        except Exception as e:
            logger.debug(f"Chat info ajratishda xatolik: {e}")
            return None
            
    async def search_groups_by_keyword(self, keyword: str, case_sensitive: bool = False) -> List[Dict]:
        """
        Kalit so'z bo'yicha guruhlarni qidirish
        
        Args:
            keyword: Qidiruv so'zi
            case_sensitive: Katta-kichik harflarni farqlash
            
        Returns:
            Topilgan guruhlar ro'yxati
        """
        try:
            if not self.client or not self.client.is_connected():
                await self.connect()
                
            logger.info(f"Guruhlarni qidiryapmiz: '{keyword}'")
            
            results = []
            checked_count = 0
            
            search_keyword = keyword if case_sensitive else keyword.lower()
            
            async for dialog in self.client.iter_dialogs():
                checked_count += 1
                
                # Faqat guruh va kanallar
                if not (dialog.is_group or dialog.is_channel):
                    continue
                    
                title = dialog.title or ''
                search_title = title if case_sensitive else title.lower()
                
                # Kalit so'zni qidirish
                if search_keyword in search_title:
                    chat_info = self._extract_chat_info(dialog.entity)
                    if chat_info:
                        results.append(chat_info)
                        logger.info(f"  ✓ Topildi: {chat_info['title']}")
                        
            logger.info(f"✓ {checked_count} ta dialog tekshirildi, {len(results)} ta topildi")
            return results
            
        except Exception as e:
            logger.error(f"✗ Qidirishda xatolik: {e}")
            return []
            
    async def get_all_groups(self, include_channels: bool = True) -> List[Dict]:
        """
        Barcha guruhlar ro'yxatini olish
        
        Args:
            include_channels: Kanallarni ham qo'shish
            
        Returns:
            Guruhlar ro'yxati
        """
        try:
            if not self.client or not self.client.is_connected():
                await self.connect()
                
            logger.info("Barcha guruhlarni olyapmiz...")
            
            results = []
            
            async for dialog in self.client.iter_dialogs():
                is_group = dialog.is_group
                is_channel = dialog.is_channel and not dialog.is_group
                
                if is_group or (include_channels and is_channel):
                    chat_info = self._extract_chat_info(dialog.entity)
                    if chat_info:
                        results.append(chat_info)
                        
            logger.info(f"✓ Jami {len(results)} ta guruh/kanal topildi")
            return results
            
        except Exception as e:
            logger.error(f"✗ Guruhlarni olishda xatolik: {e}")
            return []


# Eski funksiyalar uchun wrapper (backward compatibility)
async def get_user_folders(session_path: str) -> List[Dict]:
    """
    Eski API uchun wrapper funksiya
    """
    async with TelegramFoldersManager(session_path) as manager:
        return await manager.get_user_folders()


async def get_folder_peers(session_path: str, folder_id: int) -> List[str]:
    """
    Eski API uchun wrapper funksiya (faqat username/ID qaytaradi)
    """
    async with TelegramFoldersManager(session_path) as manager:
        chats = await manager.get_folder_chats(folder_id)
        return [chat['username'] or str(chat['id']) for chat in chats]


async def search_groups_by_keyword(session_path: str, keyword: str) -> List[Dict]:
    """
    Eski API uchun wrapper funksiya
    """
    async with TelegramFoldersManager(session_path) as manager:
        return await manager.search_groups_by_keyword(keyword)


async def get_all_user_groups(session_path: str) -> List[Dict]:
    """
    Eski API uchun wrapper funksiya
    """
    async with TelegramFoldersManager(session_path) as manager:
        groups = await manager.get_all_groups()
        # Eski format uchun konvertatsiya
        return [{
            'id': g['id'],
            'title': g['title'],
            'ref': g['username'] or str(g['id'])
        } for g in groups]


# Test funksiyasi
async def test_folders():
    """
    Test funksiyasi - barcha funksiyalarni sinab ko'rish
    """
    import sys
    
    if len(sys.argv) < 2:
        print("Foydalanish: python telegram_folders.py <session_path>")
        return
        
    session_path = sys.argv[1]
    
    print("=" * 60)
    print("TELEGRAM JILDLARI TEST")
    print("=" * 60)
    
    async with TelegramFoldersManager(session_path) as manager:
        # 1. Jildlarni olish
        print("\n1. JILDLAR RO'YXATI:")
        print("-" * 60)
        folders = await manager.get_user_folders()
        
        if not folders:
            print("Hech qanday jild topilmadi!")
            return
            
        for idx, folder in enumerate(folders, 1):
            emoji = folder.get('emoji', '')
            print(f"{idx}. [{folder['id']}] {emoji} {folder['title']} ({folder['type']})")
            
        # 2. Har bir jilddagi chatlarni olish
        print("\n2. HAR BIR JILDDAGI CHATLAR:")
        print("-" * 60)
        
        for folder in folders:
            if folder['id'] is None:
                continue
                
            print(f"\nJild: {folder['title']} (ID: {folder['id']})")
            chats = await manager.get_folder_chats(folder['id'])
            
            if chats:
                for chat in chats[:5]:  # Faqat birinchi 5 tani ko'rsatish
                    username = chat['username'] or f"ID: {chat['id']}"
                    print(f"  - {chat['title']} ({username}) [{chat['type']}]")
                    
                if len(chats) > 5:
                    print(f"  ... va yana {len(chats) - 5} ta")
            else:
                print("  (Bo'sh)")
                
        # 3. Qidirish testi
        print("\n3. QIDIRISH TESTI (kalit so'z: 'group'):")
        print("-" * 60)
        search_results = await manager.search_groups_by_keyword('group')
        
        for chat in search_results[:10]:
            username = chat['username'] or f"ID: {chat['id']}"
            print(f"  - {chat['title']} ({username})")
            
        if len(search_results) > 10:
            print(f"  ... va yana {len(search_results) - 10} ta")
            
        print("\n" + "=" * 60)
        print("TEST TUGADI")
        print("=" * 60)


if __name__ == '__main__':
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    asyncio.run(test_folders())