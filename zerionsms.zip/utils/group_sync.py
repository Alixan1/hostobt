import aiosqlite
from telethon import TelegramClient
from database.db import get_db_connection
import logging

logger = logging.getLogger(__name__)

async def sync_groups_for_user(client: TelegramClient, user_id: int):
    """
    Fetches all groups and channels from the connected client and saves them to the DB.
    """
    try:
        dialogs = await client.get_dialogs(limit=500)
        groups = []
        
        for d in dialogs:
            if d.is_group or d.is_channel:
                chat_id = str(d.id)
                chat_name = d.name or "Unknown"
                groups.append((user_id, chat_id, chat_name, 1))
                
        if not groups:
            return 0
            
        async with await get_db_connection() as db:
            # First, we might want to clear old groups or just insert ignore?
            # Clearing old ensures we don't keep left groups.
            # But currently `groups` table ID is not linked to messages table strongly (messages use global list or folder).
            # So deleting is safe-ish.
            
            await db.execute("DELETE FROM groups WHERE user_id=?", (user_id,))
            
            await db.executemany(
                "INSERT INTO groups (user_id, group_id, group_name, is_active) VALUES (?,?,?,?)",
                groups
            )
            await db.commit()
            
        return len(groups)
        
    except Exception as e:
        logger.error(f"Group Sync Error for {user_id}: {e}")
        return 0
