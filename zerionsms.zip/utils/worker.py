import asyncio
import logging
import random
import aiosqlite
from datetime import datetime, timedelta
from telethon import TelegramClient
from telethon.sessions import StringSession
from telethon.errors import FloodWaitError, UserBannedInChannelError, ChatWriteForbiddenError, ChatAdminRequiredError
from database.db import get_db_connection
from config import API_ID, API_HASH, TAGLINE
from utils.helpers import has_active_sub
from utils.telethon_utils import get_folder_peers

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)



async def ads_worker():
    logger.info("Ads Worker Started (Robust Mode)")
    while True:
        try:
            # Supervisor Loop: Restarts worker_cycle if it crashes
            await worker_cycle()
        except Exception as e:
            logger.error(f"CRITICAL WORKER CRASH: {e}", exc_info=True)
            await asyncio.sleep(30) # Wait 30s before restart

async def worker_cycle():
    """
    Main logic loop for sending ads.
    """
    while True:
        try:
            # 1. Fetch active messages (Snapshot)
            async with await get_db_connection() as db:
                columns = "id, user_id, text, photo_path, interval_sec, last_sent, target_type, targets"
                cur = await db.execute(f"SELECT {columns} FROM messages WHERE active=1")
                ads = await cur.fetchall()
            
            logger.info(f"Topilgan aktiv reklamalar: {len(ads)} ta")
            
            # 2. Process each ad
            for msg_id, user_id, text, photo, interval, last_sent, target_type, targets_blob in ads:
                logger.info(f"Processing Ad {msg_id}: user={user_id}, target_type={target_type}, interval={interval}s")
                
                # Check subscription
                sub_status = await has_active_sub(user_id)
                logger.info(f"Ad {msg_id}: user {user_id} obuna holati: {sub_status}")
                if not sub_status:
                    logger.info(f"Ad {msg_id}: user {user_id} obunasi yo'q, SKIP")
                    continue
                    
                # Check interval
                if last_sent:
                    try:
                        last_dt = datetime.fromisoformat(last_sent)
                        time_diff = datetime.utcnow() - last_dt
                        if time_diff < timedelta(seconds=interval):
                            logger.info(f"Ad {msg_id}: interval hali o'tmagan ({time_diff.total_seconds():.0f}s/{interval}s), SKIP")
                            continue
                    except Exception as e:
                        logger.error(f"Ad {msg_id}: interval tekshiruv xatosi: {e}")
                
                # Prepare destinations
                destinations = []
                async with await get_db_connection() as db:
                    if target_type == 'manual':
                        if targets_blob:
                            destinations = [t.strip() for t in targets_blob.split('\n') if t.strip()]
                            logger.info(f"Ad {msg_id}: manual - {len(destinations)} ta target")
                    elif target_type == 'folder':
                        # Folder ID yoki guruhlar ro'yxati bo'lishi mumkin
                        if targets_blob:
                            # Agar faqat raqam bo'lsa - folder ID
                            if targets_blob.strip().isdigit():
                                try:
                                    folder_id = int(targets_blob.strip())
                                    a_cur = await db.execute("SELECT session_string FROM accounts WHERE user_id=? AND is_active=1 LIMIT 1", (user_id,))
                                    acc = await a_cur.fetchone()
                                    if acc:
                                        destinations = await get_folder_peers(acc[0], folder_id)
                                        logger.info(f"Ad {msg_id}: folder {folder_id} - {len(destinations)} ta target")
                                    else:
                                        logger.warning(f"Ad {msg_id}: AKKAUNT TOPILMADI user {user_id} uchun!")
                                except Exception as e:
                                    logger.error(f"Folder fetch error: {e}")
                            else:
                                # Guruhlar ro'yxati - manual sifatida ishlatamiz
                                destinations = [t.strip() for t in targets_blob.split('\n') if t.strip()]
                                logger.info(f"Ad {msg_id}: folder (legacy) - {len(destinations)} ta guruh")
                    else:
                        # target_type == 'all' - Barcha guruhlarni olish
                        a_cur = await db.execute("SELECT session_string FROM accounts WHERE user_id=? AND is_active=1 LIMIT 1", (user_id,))
                        acc = await a_cur.fetchone()
                        if acc:
                            try:
                                from telethon.tl.types import Chat, Channel
                                session_str = acc[0].strip() if acc[0] else ""
                                try:
                                    client = TelegramClient(StringSession(session_str), API_ID, API_HASH)
                                except Exception:
                                    logger.error(f"Invalid session for user {user_id}")
                                    continue
                                await client.connect()
                                if await client.is_user_authorized():
                                    scanned_count = 0
                                    skipped_channels = 0
                                    async for dialog in client.iter_dialogs():
                                        scanned_count += 1
                                        if dialog.is_group or dialog.is_channel:
                                            # Faqat yozish mumkin bo'lgan guruhlar
                                            try:
                                                # Channels check
                                                if hasattr(dialog.entity, 'broadcast') and dialog.entity.broadcast:
                                                    skipped_channels += 1
                                                    # continue  # Kanal - skip (Commented out temporarily to test if user wants channels)
                                                    # Agar kanallarga ham yuborish kerak bo'lsa, 'continue' ni olib tashlang.
                                                    # Hozircha qaytarib qo'yaman, lekin log qilaman.
                                                    # continue 
                                                    pass # Allow channels for now to see if this fixes "0 groups"

                                                destinations.append(str(dialog.id))
                                            except:
                                                pass
                                await client.disconnect()
                                logger.info(f"Ad {msg_id} Fetch Stats: Scanned {scanned_count}, Skipped Channels {skipped_channels}, Final {len(destinations)}")
                            except Exception as e:
                                logger.error(f"All groups fetch error: {e}")
                        else:
                            logger.warning(f"Ad {msg_id}: AKKAUNT TOPILMADI user {user_id} uchun!")
                
                if not destinations:
                    logger.warning(f"Ad {msg_id}: destinations bo'sh, SKIP")
                    continue
                
                # Get session
                session = None
                async with await get_db_connection() as db:
                    a_cur = await db.execute("SELECT session_string FROM accounts WHERE user_id=? AND is_active=1 LIMIT 1", (user_id,))
                    acc = await a_cur.fetchone()
                    if acc:
                        session = acc[0]
                
                if not session: continue
                
                # Update Total Groups immediately
                if destinations:
                    async with await get_db_connection() as db:
                        await db.execute("UPDATE messages SET total_groups=? WHERE id=?", (len(destinations), msg_id))
                        await db.commit()

                # Sending Phase
                # Sessiyni har bir xabar uchun ochib yopamiz. Bu sekinroq lekin xavfsiz.
                
                sent_count_new = 0
                
                for target_ref in destinations:
                    target_ref = target_ref.strip()
                    if not target_ref: continue
                    
                    # StringSession bilan client yaratish
                    try:
                        session_str = session.strip() if session else ""
                        client = TelegramClient(StringSession(session_str), API_ID, API_HASH)
                    except Exception as e:
                        logger.error(f"Invalid session string in loop: {e}")
                        continue
                    delay = 5.0 # Default delay if error
                    success_sent = False # Track success
                    
                    try:
                        # 1. Connect
                        await client.connect()
                        if not await client.is_user_authorized():
                            continue

                        # 2. Resolve Entity
                        entity = None
                        try:
                            # Agar raqam bo'lsa (ID)
                            if target_ref.lstrip('-').isdigit():
                                entity = await client.get_input_entity(int(target_ref))
                            else:
                                entity = target_ref
                        except:
                            # Topilmasa, get_entityurinib ko'ramiz
                            try:
                                entity = await client.get_entity(target_ref)
                            except:
                                logger.error(f"Entity topilmadi: {target_ref}")
                                continue

                        # 3. Prepare Text
                        if TAGLINE and TAGLINE not in text:
                            send_text = f"{text}\n\n{TAGLINE}"
                        else:
                            send_text = text
                            
                        # 4. Send
                        if photo and photo != "None":
                            await client.send_file(entity, file=photo, caption=send_text)
                        else:
                            await client.send_message(entity, send_text)
                        
                        sent_count_new += 1
                        success_sent = True
                        
                        # 5. Fix Delay to 5s
                        delay = 5
                        logger.info(f"Yuborildi: {target_ref}. Sleep {delay}s")
                        
                    except FloodWaitError as e:
                        logger.warning(f"FloodWait: {e.seconds}s")
                        delay = e.seconds + 5
                        logger.error(f"FloodWait handling for {target_ref}: sleeping {delay}s")
                        success_sent = False
                    except (UserBannedInChannelError, ChatWriteForbiddenError, ChatAdminRequiredError) as e:
                        logger.error(f"Write Restricted in {target_ref}: {e}")
                        success_sent = False
                        delay = 5 # Move on quickly
                    except Exception as e:
                        logger.error(f"Generic Error sending to {target_ref}: {e}", exc_info=True)
                        success_sent = False
                        delay = 5
                    finally:
                        # 6. Disconnect (Release DB)
                        await client.disconnect()

                        # 7. Real-time DB Update (Incremental)
                        async with await get_db_connection() as db:
                            if success_sent:
                                await db.execute(
                                    "UPDATE messages SET sent_count=sent_count+1, success_count=success_count+1, last_sent=? WHERE id=?", 
                                    (datetime.utcnow().isoformat(), msg_id)
                                )
                            else:
                                await db.execute("UPDATE messages SET fail_count=fail_count+1 WHERE id=?", (msg_id,))
                            await db.commit()
                    
                    # 8. Sleep (DB free)
                    await asyncio.sleep(delay)

                # 3. Batch Update Removed (Moved to incremental)
                # logger.info(f"Finished batch for Ad {msg_id}")

            await asyncio.sleep(5)

                    
        except aiosqlite.Error as e:
            logger.error(f"DB Error in worker: {e}")
            await asyncio.sleep(5)
        except Exception as e:
            logger.error(f"Worker Loop Error: {e}")
            await asyncio.sleep(10)
