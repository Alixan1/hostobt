import logging
from datetime import datetime
from utils.db_api.sqlite import db

logger = logging.getLogger(__name__)

class BillingEngine:
    def __init__(self):
        pass

    def calculate_hourly_usage(self, user_id):
        """Simulates checking active services and charging hourly."""
        # This would run in a loop typically
        services = db.get_user_hosts(user_id)
        total_hourly_cost = 0
        
        for s in services:
            # s: id, name, active
            # We need plan price to calculate hourly
            # Assuming monthly price / 720 = hourly
            pass
            
        return total_hourly_cost

    def generate_invoice(self, user_id, amount, service_name):
        """Simulates calling a PDF generator or external payment gateway."""
        invoice_id = f"INV-{int(datetime.now().timestamp())}-{user_id}"
        
        # Log invoice to DB (we need an invoices table for full perfection, but let's mock log)
        logger.info(f"Generated Invoice {invoice_id} for user {user_id}: {amount} UZS for {service_name}")
        
        return {
            "id": invoice_id,
            "amount": amount,
            "desc": service_name,
            "date": datetime.now().strftime("%Y-%m-%d"),
            "status": "UNPAID"
        }

    def process_payment(self, user_id, invoice_id):
        """Simulates processing a payment for an invoice."""
        logger.info(f"Processing payment for invoice {invoice_id}...")
        return True

    def get_transaction_history(self, user_id):
        """Returns mock history."""
        # Real impl would query payments table
        # Let's query the payments table we actually have!
        
        # We need to add method to db for raw payment select
        # For now, return empty or mock
        return []

billing = BillingEngine()
