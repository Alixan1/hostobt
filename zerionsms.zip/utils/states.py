from aiogram.fsm.state import State, StatesGroup

class MsgStates(StatesGroup):
    waiting_text = State()
    waiting_image = State()
    waiting_interval = State()

class GroupStates(StatesGroup):
    waiting_group_pair = State()

class AccountStates(StatesGroup):
    waiting_phone = State()
    waiting_code = State()
    waiting_password = State() # 2FA

class PaymentStates(StatesGroup):
    waiting_days = State()
    waiting_method = State()
    waiting_cheque = State()
    waiting_promo_input = State()
    
class AdminStates(StatesGroup):
    waiting_user_id = State()
    waiting_days_add = State()
    waiting_broadcast_text = State()
    waiting_channel_id = State()
    waiting_channel_name = State()
    waiting_channel_url = State()
    waiting_promo_code = State()
    waiting_promo_days = State()
    waiting_promo_limit = State()

# ============ YANGI 2-USUL (ODDIY OQIM) ============
class SimpleFlow(StatesGroup):
    """Oddiy reklama yaratish oqimi"""
    waiting_text = State()           # Reklama matni
    waiting_photo = State()          # Rasm (ixtiyoriy)
    waiting_interval = State()       # Interval tanlash
    waiting_custom_interval = State() # O'zi kiritadigan interval
    waiting_group_method = State()   # Guruh tanlash usuli
    waiting_keyword = State()        # Kalit so'z
    waiting_folder = State()         # Jild tanlash
    waiting_folder = State()         # Jild tanlash
    waiting_link = State()           # Link/ID kiritish

class ScraperStates(StatesGroup):
    waiting_account = State()
    waiting_keyword = State()
