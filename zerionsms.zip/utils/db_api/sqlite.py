from loader import db_conn
import sqlite3

class Database:
    def __init__(self):
        self.conn = db_conn
        self.conn.row_factory = sqlite3.Row # Allow column access by name
        self._ensure_migrations()

    def _ensure_migrations(self):
        try:
            cursor = self.conn.cursor()
            cursor.execute("ALTER TABLE hosts ADD COLUMN is_privileged INTEGER DEFAULT 0")
            self.conn.commit()
        except: pass

    def add_user(self, user_id, full_name, username, language='uz'):
        try:
            cursor = self.conn.cursor()
            cursor.execute("INSERT OR IGNORE INTO users (user_id, full_name, username, joined_at, language) VALUES (?, ?, ?, datetime('now'), ?)",
                                (user_id, full_name, username, language))
            self.conn.commit()
        except Exception as e:
            print(f"Error adding user: {e}")

    def get_user(self, user_id):
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        return cursor.fetchone()

    def set_language(self, user_id, lang):
        cursor = self.conn.cursor()
        cursor.execute("UPDATE users SET language = ? WHERE user_id = ?", (lang, user_id))
        self.conn.commit()

    def get_language(self, user_id):
        cursor = self.conn.cursor()
        res = cursor.execute("SELECT language FROM users WHERE user_id = ?", (user_id,)).fetchone()
        return res[0] if res else 'uz'

    def add_payment(self, user_id, amount, photo_id):
        cursor = self.conn.cursor()
        cursor.execute("INSERT INTO payments (user_id, amount, photo_id, status, date) VALUES (?, ?, ?, 'pending', datetime('now'))",
                            (user_id, amount, photo_id))
        self.conn.commit()
        return cursor.lastrowid

    def update_payment_status(self, payment_id, status):
        cursor = self.conn.cursor()
        cursor.execute("UPDATE payments SET status = ? WHERE id = ?", (status, payment_id))
        self.conn.commit()

    def get_payment(self, payment_id):
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM payments WHERE id = ?", (payment_id,))
        return cursor.fetchone()

    def update_balance(self, user_id, amount):
        cursor = self.conn.cursor()
        cursor.execute("UPDATE users SET balance = balance + ? WHERE user_id = ?", (amount, user_id))
        self.conn.commit()

    def get_plans(self):
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM plans WHERE is_active = 1")
        return cursor.fetchall()

    def get_plan(self, plan_id):
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM plans WHERE id = ?", (plan_id,))
        return cursor.fetchone()

    def create_host(self, user_id, plan_id, path_id, expiry_date):
        cursor = self.conn.cursor()
        cursor.execute("INSERT INTO hosts (user_id, plan_id, path_id, expiry_date, is_privileged) VALUES (?, ?, ?, ?, 0)",
                            (user_id, plan_id, path_id, expiry_date))
        self.conn.commit()
        return cursor.lastrowid
    
    def toggle_host_privilege(self, host_id, status):
        cursor = self.conn.cursor()
        cursor.execute("UPDATE hosts SET is_privileged = ? WHERE id = ?", (status, host_id))
        self.conn.commit()

    def get_user_hosts(self, user_id):
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT h.id, p.name, h.is_active 
            FROM hosts h 
            JOIN plans p ON h.plan_id = p.id 
            WHERE h.user_id = ?
        """, (user_id,))
        return cursor.fetchall()

    def get_all_hosts(self):
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT h.id, h.user_id, h.plan_id, h.path_id, h.expiry_date, u.full_name, u.username, p.name as plan_name, h.is_active, h.is_privileged
            FROM hosts h
            LEFT JOIN users u ON h.user_id = u.user_id
            LEFT JOIN plans p ON h.plan_id = p.id
        """)
        return cursor.fetchall()

    def get_host(self, host_id):
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM hosts WHERE id = ?", (host_id,))
        return cursor.fetchone()

    # --- Categories CRUD ---
    def get_categories(self):
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM categories")
        return cursor.fetchall()

    def get_category(self, cat_id):
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM categories WHERE id = ?", (cat_id,))
        return cursor.fetchone()

    def add_category(self, name_uz, name_ru, name_en, code):
        cursor = self.conn.cursor()
        cursor.execute("INSERT INTO categories (name_uz, name_ru, name_en, code) VALUES (?, ?, ?, ?)", 
                            (name_uz, name_ru, name_en, code))
        self.conn.commit()

    def delete_category(self, cat_id):
        cursor = self.conn.cursor()
        cursor.execute("DELETE FROM categories WHERE id = ?", (cat_id,))
        self.conn.commit()

    # --- Locations CRUD ---
    def get_locations(self):
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM locations")
        return cursor.fetchall()

    def add_location(self, name, flag, code):
        cursor = self.conn.cursor()
        cursor.execute("INSERT INTO locations (name, flag_emoji, code) VALUES (?, ?, ?)", (name, flag, code))
        self.conn.commit()

    def delete_location(self, loc_id):
        cursor = self.conn.cursor()
        cursor.execute("DELETE FROM locations WHERE id = ?", (loc_id,))
        self.conn.commit()

    # --- OS Templates CRUD ---
    def get_os_templates(self):
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM os_templates")
        return cursor.fetchall()

    def add_os_template(self, name, version, os_type):
        cursor = self.conn.cursor()
        cursor.execute("INSERT INTO os_templates (name, version, type) VALUES (?, ?, ?)", (name, version, os_type))
        self.conn.commit()

    def delete_os_template(self, os_id):
        cursor = self.conn.cursor()
        cursor.execute("DELETE FROM os_templates WHERE id = ?", (os_id,))
        self.conn.commit()

    # --- Advanced Plan CRUD ---
    def add_plan(self, category, name, size, price, ram, cpu, description):
        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO plans (category_code, name, size_gb, price_monthly, ram_limit_mb, cpu_limit_percent, description, is_active)
            VALUES (?, ?, ?, ?, ?, ?, ?, 1)
        """, (category, name, size, price, ram, cpu, description))
        self.conn.commit()

    def delete_plan(self, plan_id):
        cursor = self.conn.cursor()
        cursor.execute("DELETE FROM plans WHERE id = ?", (plan_id,))
        self.conn.commit()

    def update_plan_field(self, plan_id, field, value):
        cursor = self.conn.cursor()
        cursor.execute(f"UPDATE plans SET {field} = ? WHERE id = ?", (value, plan_id))
        self.conn.commit()

    def count_users(self):
        cursor = self.conn.cursor()
        cursor.execute("SELECT count(*) FROM users")
        return cursor.fetchone()[0]

    # --- Ticket System ---
    def create_ticket(self, user_id, subject):
        cursor = self.conn.cursor()
        cursor.execute("INSERT INTO tickets (user_id, subject, status) VALUES (?, ?, 'open')", (user_id, subject))
        self.conn.commit()
        return cursor.lastrowid

    def add_ticket_message(self, ticket_id, sender_id, text):
        cursor = self.conn.cursor()
        cursor.execute("INSERT INTO ticket_messages (ticket_id, sender_id, text) VALUES (?, ?, ?)", 
                            (ticket_id, sender_id, text))
        self.conn.commit()

    def get_user_tickets(self, user_id):
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM tickets WHERE user_id = ? ORDER BY id DESC", (user_id,))
        return cursor.fetchall()

    def get_ticket(self, ticket_id):
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM tickets WHERE id = ?", (ticket_id,))
        return cursor.fetchone()

    def get_ticket_messages(self, ticket_id):
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM ticket_messages WHERE ticket_id = ? ORDER BY id ASC", (ticket_id,))
        return cursor.fetchall()

    def close_ticket(self, ticket_id):
        cursor = self.conn.cursor()
        cursor.execute("UPDATE tickets SET status = 'closed' WHERE id = ?", (ticket_id,))
        self.conn.commit()

db = Database()
