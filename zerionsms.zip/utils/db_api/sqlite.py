from loader import db_conn

class Database:
    def __init__(self):
        self.conn = db_conn
        self.cursor = self.conn.cursor()

    def add_user(self, user_id, full_name, username, language='uz'):
        try:
            self.cursor.execute("INSERT OR IGNORE INTO users (user_id, full_name, username, joined_at, language) VALUES (?, ?, ?, datetime('now'), ?)",
                                (user_id, full_name, username, language))
            self.conn.commit()
        except Exception as e:
            print(f"Error adding user: {e}")

    def get_user(self, user_id):
        self.cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
        return self.cursor.fetchone()

    def set_language(self, user_id, lang):
        self.cursor.execute("UPDATE users SET language = ? WHERE user_id = ?", (lang, user_id))
        self.conn.commit()

    def get_language(self, user_id):
        res = self.cursor.execute("SELECT language FROM users WHERE user_id = ?", (user_id,)).fetchone()
        return res[0] if res else 'uz'

    def add_payment(self, user_id, amount, photo_id):
        self.cursor.execute("INSERT INTO payments (user_id, amount, photo_id, status, date) VALUES (?, ?, ?, 'pending', datetime('now'))",
                            (user_id, amount, photo_id))
        self.conn.commit()
        return self.cursor.lastrowid

    def update_payment_status(self, payment_id, status):
        self.cursor.execute("UPDATE payments SET status = ? WHERE id = ?", (status, payment_id))
        self.conn.commit()

    def get_payment(self, payment_id):
        self.cursor.execute("SELECT * FROM payments WHERE id = ?", (payment_id,))
        return self.cursor.fetchone()

    def update_balance(self, user_id, amount):
        self.cursor.execute("UPDATE users SET balance = balance + ? WHERE user_id = ?", (amount, user_id))
        self.conn.commit()

    def get_plans(self):
        self.cursor.execute("SELECT * FROM plans WHERE is_active = 1")
        return self.cursor.fetchall()

    def get_plan(self, plan_id):
        self.cursor.execute("SELECT * FROM plans WHERE id = ?", (plan_id,))
        return self.cursor.fetchone()

    def create_host(self, user_id, plan_id, path_id, expiry_date):
        self.cursor.execute("INSERT INTO hosts (user_id, plan_id, path_id, expiry_date) VALUES (?, ?, ?, ?)",
                            (user_id, plan_id, path_id, expiry_date))
        self.conn.commit()
        return self.cursor.lastrowid

    def get_user_hosts(self, user_id):
        # Join with plans to get names
        self.cursor.execute("""
            SELECT h.id, p.name, h.is_active 
            FROM hosts h 
            JOIN plans p ON h.plan_id = p.id 
            WHERE h.user_id = ?
        """, (user_id,))
        return self.cursor.fetchall()

    def get_host(self, host_id):
        self.cursor.execute("SELECT * FROM hosts WHERE id = ?", (host_id,))
        return self.cursor.fetchone()

    def count_users(self):
        self.cursor.execute("SELECT count(*) FROM users")
        return self.cursor.fetchone()[0]

db = Database()
