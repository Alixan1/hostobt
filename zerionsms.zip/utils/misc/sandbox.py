import subprocess
import os
import logging

logger = logging.getLogger(__name__)

BLACKLISTED_COMMANDS = ['rm', 'del', 'shutdown', 'reboot', 'format', 'mkfs', 'dd', 'sudo', 'su', ':(){:|:&};:']

class Sandbox:
    def __init__(self, user_folder):
        self.cwd = user_folder

    def is_safe_command(self, command):
        # Juda oddiy tekshiruv (Windows command injectiondan to'liq himoya emas)
        cmd_lower = command.lower()
        for bad in BLACKLISTED_COMMANDS:
            if bad in cmd_lower: # Oddiy string match
                return False
        return True

    def run_command(self, command, timeout=10):
        if not self.is_safe_command(command):
            return "❌ Xavfli buyruq aniqlandi (Administrator tomonidan taqiqlangan)."
        
        try:
            # Shell=True xavfli, lekin user "terminal" so'ragani uchun kerak.
            # Biz cwd ni user papkasi bilan cheklaymiz.
            process = subprocess.run(
                command, 
                cwd=self.cwd, 
                shell=True, 
                capture_output=True, 
                text=True, 
                timeout=timeout,
                encoding='utf-8', 
                errors='ignore'
            )
            output = process.stdout + process.stderr
            if not output:
                output = "✅ Buyruq bajarildi (Javob yo'q)."
            return output
        except subprocess.TimeoutExpired:
            return "❌ Vaqt tugadi (Timeout)."
        except Exception as e:
            return f"❌ Xatolik: {e}"

    def list_files(self):
        try:
            return os.listdir(self.cwd)
        except Exception as e:
            return [f"Error: {e}"]
