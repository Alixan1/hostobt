import subprocess
import sys
import os
import json
import psutil
import logging
from config import BASE_DIR

PROCESS_DB_PATH = os.path.join(BASE_DIR, 'inf', 'processes.json')
logger = logging.getLogger(__name__)

class ProcessManager:
    def __init__(self):
        self.processes = self.load_processes()

    def load_processes(self):
        if os.path.exists(PROCESS_DB_PATH):
            try:
                with open(PROCESS_DB_PATH, 'r') as f:
                    return json.load(f)
            except:
                return {}
        return {}

    def save_processes(self):
        try:
            with open(PROCESS_DB_PATH, 'w') as f:
                json.dump(self.processes, f, indent=4)
        except Exception as e:
            logger.error(f"Failed to save processes: {e}")

    def start_script(self, host_id, file_path):
        """Scripts run in background (nohup-like)."""
        host_id = str(host_id)
        
        # Stop existing if running
        if self.is_running(host_id):
            return False, "⚠️ Bu host allaqachon ishlamoqda."

        if not os.path.exists(file_path):
            return False, "❌ Fayl topilmadi."

        working_dir = os.path.dirname(file_path)
        log_file = os.path.join(working_dir, "logs.txt")
        
        # Windows specific: Run detached
        # CREATE_NO_WINDOW = 0x08000000, CREATE_NEW_PROCESS_GROUP = 0x00000200
        creation_flags = 0x08000000 | 0x00000200 if sys.platform == 'win32' else 0

        try:
            # Outputni log faylga yo'naltiramiz
            with open(log_file, "a") as out:
                cmd = [sys.executable, file_path]
                if file_path.endswith('.js'):
                    cmd = ['node', file_path] # Node.js support
                
                proc = subprocess.Popen(
                    cmd,
                    cwd=working_dir,
                    stdout=out,
                    stderr=out,
                    creationflags=creation_flags,
                    close_fds=(sys.platform != 'win32')
                )
            
            self.processes[host_id] = {
                "pid": proc.pid,
                "file": file_path
            }
            self.save_processes()
            return True, f"✅ Bot ishga tushdi! (PID: {proc.pid})"
        except Exception as e:
            logger.error(f"Start error: {e}")
            return False, f"❌ Xatolik: {e}"

    def stop_script(self, host_id):
        host_id = str(host_id)
        if host_id not in self.processes:
            return False, "⚠️ Bu host faol emas."

        pid = self.processes[host_id]["pid"]
        try:
            process = psutil.Process(pid)
            process.terminate()  # Yoki process.kill()
            del self.processes[host_id]
            self.save_processes()
            return True, "🛑 Bot to'xtatildi."
        except psutil.NoSuchProcess:
            del self.processes[host_id]
            self.save_processes()
            return True, "⚠️ Jarayon allaqachon to'xtagan (Tozalandi)."
        except Exception as e:
            return False, f"❌ To'xtatishda xatolik: {e}"

    def restart_script(self, host_id):
        host_id = str(host_id)
        if host_id not in self.processes:
            return False, "⚠️ Qayta ishga tushirish uchun avval ishga tushiring."
        
        file_path = self.processes[host_id]["file"]
        self.stop_script(host_id)
        return self.start_script(host_id, file_path)

    def is_running(self, host_id):
        host_id = str(host_id)
        if host_id not in self.processes:
            return False
        
        pid = self.processes[host_id]["pid"]
        return psutil.pid_exists(pid)

    def get_logs(self, host_id):
        host_id = str(host_id)
        if host_id not in self.processes: 
            # Agar process listda bo'lmasa ham, file tizimidan logni qidirish mumkin
            # Hozircha faqat active process uchun
             return "⚠️ Bot ishlamayapti, loglar mavjud emas."
        
        file_path = self.processes[host_id]["file"]
        log_file = os.path.join(os.path.dirname(file_path), "logs.txt")
        
        if os.path.exists(log_file):
            try:
                with open(log_file, "r") as f:
                    # Oxirgi 2000 belgi
                    content = f.read()
                    return content[-2000:] if content else "📭 Loglar bo'sh."
            except Exception as e:
                return f"❌ Log o'qishda xatolik: {e}"
        return "📭 Log fayli topilmadi."

pm = ProcessManager()
