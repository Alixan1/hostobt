import re
import os

class SecurityScanner:
    def __init__(self):
        # Qora ro'yxatdagi so'zlar (Regex)
        self.banned_patterns = [
            r"rm\s+-rf", r"mkfs", r"dd\s+if=", r":\(\)\{\s*:\|:&",  # Fork bomb / Delete
            r"import\s+socket", r"socket\.socket", # Network flood
            r"import\s+requests", # Ddos ehtimoli (balki ruxsat berilishi kerak)
            r"os\.system", r"subprocess\.call", r"subprocess\.Popen", # Shell execution
            r"eval\(", r"exec\(", # Dynamic code
            r"adb\s+shell", 
            r"telegram-add-member", # Spam bots
            r"layer7", r"ddos", r"flood"
        ]
        
        # Ruxsat etilgan paketlar (Agar whitelist kerak bo'lsa)
        # Hozircha faqat blacklist ishlaydi.

    def scan_file(self, file_path):
        """Faylni xavfli kodlarga tekshiradi."""
        if not os.path.exists(file_path):
            return False, "Fayl topilmadi."
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                
            for pattern in self.banned_patterns:
                if re.search(pattern, content, re.IGNORECASE):
                    return False, f"⚠️ Xavfli kod aniqlandi: '{pattern}'"
            
            return True, "✅ Kod xavfsiz ko'rinadi."
        except Exception as e:
            return False, f"Tekshirishda xatolik: {e}"

    def scan_directory(self, folder_path):
        """Papka ichidagi barcha fayllarni tekshiradi."""
        for root, dirs, files in os.walk(folder_path):
            for file in files:
                if file.endswith('.py') or file.endswith('.js') or file.endswith('.sh'):
                    safe, msg = self.scan_file(os.path.join(root, file))
                    if not safe:
                        return False, f"{file}: {msg}"
        return True, "✅ Barcha fayllar toza."

security = SecurityScanner()
