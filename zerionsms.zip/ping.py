import telebot
import time

# ⚠️ Bu yerga o'z bot tokeningizni yozing (BotFather dan olingan)
TOKEN = '8341680164:AAG-Mscp2T6odJDviRaeF8rLFA2TfKhzdfw' 

bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "👋 Salom! Men Ping o'lchaydigan botman.\n/ping deb yozib ko'ring.")

@bot.message_handler(commands=['ping'])
def send_ping(message):
    start = time.time()
    # Avval javob yozamiz
    msg = bot.reply_to(message, "🏓 Pong...")
    # Keyin qancha vaqt ketganini o'lchaymiz
    delta = time.time() - start
    
    # Natijani millisekundda chiqaramiz
    ping_ms = int(delta * 1000)
    
    bot.edit_message_text(chat_id=message.chat.id, message_id=msg.message_id, 
                          text=f"🏓 <b>Pong!</b>\n📶 Javob tezligi: <b>{ping_ms}ms</b>", parse_mode="HTML")

if __name__ == "__main__":
    print("Ping Bot ishga tushdi...")
    try:
        bot.infinity_polling()
    except Exception as e:
        print(f"Xatolik: {e}")
