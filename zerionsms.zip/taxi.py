from telethon import TelegramClient, events
import asyncio
import re
from datetime import datetime

# Konfiguratsiya
API_ID = '20245388'  # my.telegram.org dan oling
API_HASH = '494389e155bd7d18e8656de2c4973073'  # my.telegram.org dan oling
SESSION_NAME = 'session_name'
# MAXFIY GURUH - ID orqali (username emas)
TARGET_GROUP_ID = -5078573459  # Maxfiy guruh ID raqamingizni qo'ying
ADMIN_ID = 6729747103  # Admin ID

# Taxi patterns (latin)
TAXI_PATTERNS = [
    r'\btaxi\b',
    r'\btaksi\b'
]

# Block words (agar bu so'zlar bo'lsa, xabarni HECH QACHON tashamaymiz)
BLOCK_WORDS = [
    'taxibor',
    'taxi bor',
    'ketamiz',
    'ketdik',
    'keldik',
    'boramiz',
    'kelamiz',
    'ketyapmiz',
    'kelyapmiz',
    'borish',
    'kelish',
    'borishimiz',
    'kelishimiz'
]

# Sozlamalar
CHECK_INTERVAL = 5  # 5 sekund
MESSAGE_LIMIT = 50  # Har bir tekshirish uchun xabarlar soni

# Saqlash uchun
processed_messages = set()  # Qayta ishlangan xabarlar ID'lari
client = TelegramClient(SESSION_NAME, API_ID, API_HASH)

def check_taxi_patterns(text):
    """Taxi patterns borligini tekshirish"""
    if not text:
        return False
    
    text_lower = text.lower()
    
    # Taxi patterns ni tekshirish
    for pattern in TAXI_PATTERNS:
        if re.search(pattern, text_lower, re.IGNORECASE):
            return True
    
    return False

def check_block_words(text):
    """Block words borligini tekshirish"""
    if not text:
        return False
    
    text_lower = text.lower()
    
    # Block words ni tekshirish (katta-kichik harflarga sezgir emas)
    for word in BLOCK_WORDS:
        word_lower = word.lower()
        # So'zni alohida tekshirish
        pattern = r'\b' + re.escape(word_lower) + r'\b'
        if re.search(pattern, text_lower):
            return True
    
    return False

def should_process_message(text):
    """Xabarni qayta ishlash kerakligini aniqlash"""
    if not text:
        return False
    
    # Agar block words bo'lsa, HECH QACHON qayta ishlamaymiz
    if check_block_words(text):
        return False
    
    # Faqat block words yo'q va taxi patterns bor bo'lsa qayta ishlaymiz
    return check_taxi_patterns(text)

async def forward_to_target_group(message):
    """Xabarni maxfiy guruhga forward qilish"""
    try:
        # Maxfiy guruhga forward qilish
        await client.forward_messages(TARGET_GROUP_ID, message)
        
        # Sender ma'lumotlarini olish
        sender = await message.get_sender()
        sender_name = sender.first_name if sender else "Noma'lum"
        chat_title = message.chat.title if message.chat and hasattr(message.chat, 'title') else "Shaxsiy chat"
        
        # Consolega ma'lumot chiqarish
        print(f"✅ Xabar {TARGET_GROUP_ID} guruhiga FORWARD qilindi")
        print(f"   👤 Foydalanuvchi: {sender_name}")
        print(f"   📍 Manba: {chat_title}")
        print(f"   🆔 User ID: {sender.id if sender else 'Noma/lum'}")
        print(f"   📅 Vaqt: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"   🔗 Xabar ID: {message.id}")
        print(f"   📝 Xabar: {message.text[:100]}...")
        print("-" * 50)
            
    except Exception as e:
        print(f"❌ Forward qilishda xato: {e}")

async def scan_dialogs():
    """Barcha dialog/suhbatlarni skaner qilish"""
    try:
        print(f"🔍 Dialoglar skanerlash boshlandi... ({datetime.now().strftime('%H:%M:%S')})")
        
        # Barcha dialoglarni olish
        dialogs = await client.get_dialogs()
        
        for dialog in dialogs:
            try:
                # Faqat guruh va kanallarni tekshirish
                if dialog.is_group or dialog.is_channel:
                    chat = dialog.entity
                    
                    # Oxirgi xabarlarni olish
                    messages = await client.get_messages(chat, limit=MESSAGE_LIMIT)
                    
                    for message in messages:
                        # Xabarni tekshirish
                        if (message.id not in processed_messages and 
                            message.text and 
                            not message.out and  # Faqat kelgan xabarlar
                            message.sender_id != ADMIN_ID):  # Admin xabarlarini o'tkazib yuborish
                            
                            message_text = message.text
                            
                            # Xabarni qayta ishlash kerakligini tekshirish
                            if should_process_message(message_text):
                                print(f"🚖 Taxi xabari topildi (block words YO'Q):")
                                print(f"   Guruh: {chat.title}")
                                print(f"   Xabar: {message_text[:100]}...")
                                
                                # Xabarni saqlash
                                processed_messages.add(message.id)
                                
                                # Maxfiy guruhga forward qilish
                                await forward_to_target_group(message)
                                
                                # Kichik kutish
                                await asyncio.sleep(0.5)
                                
                            else:
                                # Nega o'tkazib yuborilganligini ko'rsatish
                                has_taxi = check_taxi_patterns(message_text)
                                has_block = check_block_words(message_text)
                                
                                if has_block:
                                    print(f"⛔️ Xabar O'TKAZIB YUBORILDI (BLOCK WORDS bor):")
                                    print(f"   Guruh: {chat.title}")
                                    print(f"   Xabar: {message_text[:50]}...")
                                elif not has_taxi:
                                    # Taxi patterns yo'q, shunchaki skip qilamiz
                                    pass
                                
            except Exception as e:
                print(f"❌ Dialogda xato: {e}")
                continue
                
    except Exception as e:
        print(f"❌ Skanerlashda xato: {e}")

async def continuous_scan():
    """Davomiy skanerlash"""
    print("🚀 Bot ishga tushdi! Barcha guruhlar skanerlanmoqda...")
    print(f"⏰ Har {CHECK_INTERVAL} sekundda tekshiriladi")
    print(f"🎯 Maxfiy guruh ID: {TARGET_GROUP_ID}")
    print(f"🔍 Taxi patterns: taxi, taksi")
    print(f"🚫 BLOCK WORDS (agar bu so'zlar bo'lsa, HECH QACHON tashamaydi):")
    print(f"   {BLOCK_WORDS}")
    print("-" * 50)
    
    while True:
        try:
            await scan_dialogs()
            await asyncio.sleep(CHECK_INTERVAL)
            
        except Exception as e:
            print(f"❌ Davomiy skanerlashda xato: {e}")
            await asyncio.sleep(CHECK_INTERVAL)

@client.on(events.NewMessage(pattern='/start'))
async def start_command(event):
    """Start komandasi"""
    await event.reply(
        '🚖 **Taxi Bot ishga tushdi!**\n\n'
        f'**Sozlamalar:**\n'
        f'• Maxfiy guruh ID: `{TARGET_GROUP_ID}`\n'
        f'• Tekshirish intervali: `{CHECK_INTERVAL} sekund`\n'
        f'• Taxi patterns: `taxi, taksi`\n'
        f'• Block words: `{len(BLOCK_WORDS)} ta`\n\n'
        '**MUHIM QOIDA:**\n'
        '❌ Agar xabarda BLOCK WORDS bo\'lsa, HECH QACHON forward qilinmaydi!\n'
        '✅ Faqat taxi patterns bor VA block words yo\'q xabarlar forward qilinadi'
    )

@client.on(events.NewMessage(pattern='/stats'))
async def stats_command(event):
    """Statistika"""
    if event.sender_id == ADMIN_ID:
        stats_text = (
            f'📊 **Statistika:**\n'
            f'• Qayta ishlangan xabarlar: `{len(processed_messages)}`\n'
            f'• Skanerlash intervali: `{CHECK_INTERVAL} sekund`\n'
            f'• Maxfiy guruh ID: `{TARGET_GROUP_ID}`\n'
            f'• Oxirgi tekshiruv: `{datetime.now().strftime("%H:%M:%S")}`\n\n'
            f'**Filter sozlamalari:**\n'
            f'• Taxi patterns: {len(TAXI_PATTERNS)} ta\n'
            f'• Block words: {len(BLOCK_WORDS)} ta'
        )
        await event.reply(stats_text)

@client.on(events.NewMessage(pattern='/blockwords'))
async def blockwords_command(event):
    """Block words ro'yxatini ko'rsatish"""
    if event.sender_id == ADMIN_ID:
        block_list = '\n'.join([f'• `{word}`' for word in BLOCK_WORDS])
        await event.reply(
            f'🚫 **BLOCK WORDS ro\'yxati:**\n'
            f'Agar xabarda bu so\'zlardan biri bo\'lsa, HECH QACHON forward qilinmaydi!\n\n'
            f'{block_list}'
        )

@client.on(events.NewMessage(pattern='/addblock'))
async def addblock_command(event):
    """Yangi block word qo'shish"""
    if event.sender_id == ADMIN_ID:
        try:
            # /addblock ketdik migi
            command_parts = event.message.text.split(' ', 1)
            if len(command_parts) > 1:
                new_word = command_parts[1].strip()
                if new_word and new_word not in BLOCK_WORDS:
                    BLOCK_WORDS.append(new_word)
                    await event.reply(f'✅ Yangi block word qo\'shildi: `{new_word}`')
                else:
                    await event.reply(f'⚠️ Bu so\'z allaqachon ro\'yxatda yoki noto\'g\'ri')
        except Exception as e:
            await event.reply(f'❌ Xato: {e}')

@client.on(events.NewMessage(pattern='/clearcache'))
async def clearcache_command(event):
    """Cache tozalash"""
    if event.sender_id == ADMIN_ID:
        processed_messages.clear()
        await event.reply('✅ Cache tozalandi! Barcha xabarlar qayta tekshiriladi.')

async def setup_bot():
    """Botni sozlash"""
    print("🔧 Bot sozlanmoqda...")
    
    # Maxfiy guruhni tekshirish
    try:
        target_entity = await client.get_entity(TARGET_GROUP_ID)
        print(f"✅ Maxfiy guruh topildi: {target_entity.title if hasattr(target_entity, 'title') else 'Noma/lum'}")
        return True
    except Exception as e:
        print(f"❌ Maxfiy guruh topilmadi: {e}")
        print("Iltimos, TARGET_GROUP_ID ni to'g'ri kiriting!")
        return False

async def main():
    """Asosiy funksiya"""
    await client.start()
    
    if await setup_bot():
        # Davomiy skanerlashni boshlash
        asyncio.create_task(continuous_scan())
        
        # Botni ishga tushirish
        print("\n" + "="*50)
        print("✅ Bot muvaffaqiyatli ishga tushdi!")
        print("🤖 /start - Sozlamalarni ko'rish")
        print("📊 /stats - Statistika")
        print("🚫 /blockwords - Block words ro'yxati")
        print("➕ /addblock [so'z] - Yangi block word qo'shish")
        print("🧹 /clearcache - Cache tozalash")
        print("="*50 + "\n")
        
        await client.run_until_disconnected()
    else:
        print("❌ Botni sozlashda xatolik!")

if __name__ == '__main__':
    print("🚖 Telegram Taxi Bot (Block Words Filter)")
    print("\nDIQQAT! Kodni ishga tushirishdan oldin:")
    print("1. API_ID va API_HASH ni o'rnating")
    print("2. TARGET_GROUP_ID ni maxfiy guruh ID raqamingizga o'zgartiring")
    print("3. ADMIN_ID ni o'z ID'ingizga o'zgartiring")
    print("\n" + "="*50)
    print("⚠️ MUHIM QOIDA:")
    print("Agar xabarda BLOCK WORDS bo'lsa, HECH QACHON forward qilinmaydi!")
    print("Faqat taxi patterns bor VA block words yo'q xabarlar forward qilinadi")
    print("="*50 + "\n")
    
    with client:
        client.loop.run_until_complete(main())
    print("⚠️ QOIDA: Faqat taxi patterns bor VA block words yo'q xabarlar forward qilinadi!")
    print("="*50 + "\n")
    
    with client:
        client.loop.run_until_complete(main())

