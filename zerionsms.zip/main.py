from loader import bot
import handlers.users.start
import handlers.users.help
import handlers.users.hosting
import handlers.users.payment
import handlers.admin.approval
import handlers.admin.payment_admin
import handlers.admin.plans

if __name__ == '__main__':
    print("Bot ishga tushdi...")
    bot.infinity_polling()
