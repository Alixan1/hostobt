from loader import bot
import handlers.users.start
import handlers.users.help
import handlers.users.hosting
import handlers.users.vps_manage
import handlers.users.support
import handlers.users.referral
import handlers.users.settings
import handlers.users.payment
import handlers.users.menu_handlers
import handlers.users.terminal
import handlers.users.file_manager
import handlers.admin.approval
import handlers.admin.payment_admin
import handlers.admin.plans
import handlers.admin.dashboard
import handlers.admin.products
import handlers.admin.stats
import handlers.admin.hosts_manage
import handlers.admin.root_grant

if __name__ == '__main__':
    print("Bot ishga tushdi...")
    bot.infinity_polling()
# Bot is now running in pure mode without Web Admin
