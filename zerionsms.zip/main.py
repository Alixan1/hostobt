import asyncio
import logging
import sys
import os
import uuid
from aiogram import Bot, Dispatcher, types
from aiogram.fsm.storage.memory import MemoryStorage
from aiohttp import web
import aiohttp_cors
from config import BOT_TOKEN, WEBAPP_URL
from database.db import init_db, get_db_connection
from handlers import user_handlers, admin_handlers, payment_handlers, webapp_handlers
from utils.worker import ads_worker
from utils.telethon_utils import get_user_folders
import json

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

# Initialize Bot and Dispatcher
bot = Bot(token=BOT_TOKEN)
storage = MemoryStorage()
dp = Dispatcher(storage=storage)

# --- Web App API Handlers ---
async def handle_webapp_index(request):
    try:
        return web.FileResponse('./webapp/index.html')
    except Exception:
        return web.Response(text="Web App index.html not found", status=404)

async def handle_get_folders(request):
    try:
        # Validate init data (simplified for now, ideally verify hash)
        # We expect user_id in query params for this MVP
        user_id = request.query.get('user_id')
        if not user_id:
            return web.json_response({'error': 'User ID required'}, status=400)
            
        async with await get_db_connection() as db:
            cur = await db.execute("SELECT session_string FROM accounts WHERE user_id=? AND is_active=1 LIMIT 1", (user_id,))
            row = await cur.fetchone()
            
        if not row:
            return web.json_response({'error': 'No active account found. Please connect an account first in the bot.'}, status=404)
            
        session_string = row[0]
        try:
            folders = await get_user_folders(session_string)
            return web.json_response({'folders': folders})
        except ValueError as e:
            return web.json_response({'error': str(e)}, status=400)
    except Exception as e:
        logger.error(f"API Error: {e}")
        return web.json_response({'error': str(e)}, status=500)

async def handle_upload(request):
    try:
        reader = await request.multipart()
        field = await reader.next()
        if not field:
            return web.json_response({'error': 'No file uploaded'}, status=400)
            
        filename = field.filename
        if not filename:
            filename = f"{uuid.uuid4()}.jpg"
            
        # Extension check (basic)
        ext = os.path.splitext(filename)[1].lower()
        if ext not in ['.jpg', '.jpeg', '.png', '.webp']:
            return web.json_response({'error': 'Only images allowed'}, status=400)
            
        # Save file
        safe_filename = f"{uuid.uuid4()}{ext}"
        file_path = os.path.join('uploads', safe_filename)
        
        with open(file_path, 'wb') as f:
            while True:
                chunk = await field.read_chunk()
                if not chunk:
                    break
                f.write(chunk)
                
        # Return LOCAL absolute path or relative path that worker can use
        # Worker is in same project root, so 'uploads/filename' works if cwd is correct.
        # Let's verify cwd. Usually CWD is project root.
        
        full_path = os.path.abspath(file_path)
        return web.json_response({'path': full_path})
        
    except Exception as e:
        logger.error(f"Upload Error: {e}")
        return web.json_response({'error': str(e)}, status=500)

async def on_startup(app):
    # Ensure directories exist
    os.makedirs("sessions", exist_ok=True)
    os.makedirs("photos", exist_ok=True)
    os.makedirs("uploads", exist_ok=True)
    
    await init_db()
    
    # Include Routers
    dp.include_router(user_handlers.router)
    dp.include_router(admin_handlers.router)
    dp.include_router(payment_handlers.router)
    dp.include_router(webapp_handlers.router)
    
    # Start Worker
    app['worker_task'] = asyncio.create_task(ads_worker())
    
    # Store bot in app for API handlers
    app['bot'] = bot
    
    # Resume Auto-Join Tasks
    try:
        from utils.joiner import start_join_task
        async with await get_db_connection() as db:
            tasks = await (await db.execute("SELECT id FROM join_tasks WHERE status='running'")).fetchall()
            for (tid,) in tasks:
                asyncio.create_task(start_join_task(tid))
                logger.info(f"Resumed Join Task {tid}")
    except Exception as e:
        logger.error(f"Failed to resume join tasks: {e}")

    # Start Polling
    app['polling_task'] = asyncio.create_task(dp.start_polling(bot))
    
    logger.info("Bot and Web App Server Started")

async def on_shutdown(app):
    app['polling_task'].cancel()
    app['worker_task'].cancel()
    try:
        await app['polling_task']
    except asyncio.CancelledError:
        pass
    try:
        await app['worker_task']
    except asyncio.CancelledError:
        pass
        
    await bot.session.close()

def main():
    app = web.Application()
    
    # Routes
    app.router.add_get('/', handle_webapp_index)
    app.router.add_get('/webapp', handle_webapp_index)
    app.router.add_get('/api/get_folders', handle_get_folders)
    app.router.add_post('/api/upload', handle_upload)
    app.router.add_post('/api/create_ad', webapp_handlers.handle_create_ad_api)
    
    # CORS setup
    cors = aiohttp_cors.setup(app, defaults={
        "*": aiohttp_cors.ResourceOptions(
            allow_credentials=True,
            expose_headers="*",
            allow_headers="*",
        )
    })
    
    for route in list(app.router.routes()):
        cors.add(route)

    app.on_startup.append(on_startup)
    app.on_cleanup.append(on_shutdown)
    
    # Port 8080 or from env
    # For windows, ensuring event loop policy if needed
    if sys.platform == 'win32':
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
        
    web.run_app(app, port=8080)

if __name__ == "__main__":
    try:
        main()
    except (KeyboardInterrupt, SystemExit):
        logger.info("Bot stopped!")
