import asyncio
from database.db import get_db_connection

async def main():
    async with await get_db_connection() as db:
        async with db.execute("SELECT id, active, user_id, interval_sec, sent_count FROM messages") as cur:
            rows = await cur.fetchall()
            print("ADS IN DB:", rows)

if __name__ == "__main__":
    asyncio.run(main())
