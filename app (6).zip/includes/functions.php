
<?php
// includes/functions.php

if (session_status() === PHP_SESSION_NONE) session_start();

function clean($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

function redirect($url) {
    header("Location: $url");
    exit();
}

function set_flash($type, $message) {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function display_flash() {
    if (isset($_SESSION['flash'])) {
        echo '<div id="flash-data" data-type="'.$_SESSION['flash']['type'].'" data-message="'.$_SESSION['flash']['message'].'"></div>';
        unset($_SESSION['flash']);
    }
}

function format_money($amount) {
    return number_format($amount, 0, '.', ' ') . ' UZS';
}

function generate_csrf() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function check_csrf() {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("CSRF Validation Failed");
    }
}

function check_auth() {
    if (!isset($_SESSION['user_id'])) redirect('login.php');
}

function check_admin() {
    if (!isset($_SESSION['admin_id'])) redirect('admin/index.php'); // Admin login path
}

function log_action($pdo, $user_id, $action, $details = '') {
    $stmt = $pdo->prepare("INSERT INTO logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)");
    $stmt->execute([$user_id, $action, $details, $_SERVER['REMOTE_ADDR']]);
}

// Settings functions
function get_setting($pdo, $key) {
    $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = ?");
    $stmt->execute([$key]);
    return $stmt->fetchColumn();
}

function update_setting($pdo, $key, $value) {
    $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
    $stmt->execute([$key, $value, $value]);
}
?>
