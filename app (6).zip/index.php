
<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';

$stmt = $pdo->query("SELECT * FROM hosting_plans ORDER BY price_uzs ASC");
$plans = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <title>ProHost Uz - Professional Hosting</title>
    <link rel="stylesheet" href="assets/style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <nav class="navbar">
        <div class="container d-flex justify-between" style="height:100%">
            <a href="index.php" class="logo">ProHost <span>Uz</span></a>
            <div class="nav-links">
                <?php if(isset($_SESSION['user_id'])): ?>
                    <a href="dashboard.php" class="btn btn-primary">Kabinet</a>
                    <a href="logout.php">Chiqish</a>
                <?php else: ?>
                    <a href="login.php">Kirish</a>
                    <a href="register.php" class="btn btn-primary">Ro'yxatdan o'tish</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <header style="padding: 80px 0; text-align: center; background: radial-gradient(circle at center, #161b22 0%, #0d1117 100%);">
        <div class="container">
            <h1 style="font-size: 3rem; margin-bottom: 20px;">O'zbekistondagi Eng Tezkor Hosting</h1>
            <p style="color: var(--text-muted); font-size: 1.2rem; max-width: 600px; margin: 0 auto 30px;">
                NVMe SSD disklar, DDoS himoya va 99.9% kafolatlangan Uptime bilan biznesingizni rivojlantiring.
            </p>
            <a href="#plans" class="btn btn-primary" style="padding: 12px 30px; font-size: 16px;">Tariflarni Tanlash</a>
        </div>
    </header>

    <div class="container" id="plans">
        <div class="pricing-grid">
            <?php foreach($plans as $plan): ?>
            <div class="card price-card">
                <h3><?= clean($plan['name']) ?></h3>
                <div class="price-amount"><?= format_money($plan['price_uzs']) ?><small style="font-size:14px;color:var(--text-muted)">/oy</small></div>
                <ul class="price-features">
                    <li>Disk: <?= $plan['disk_gb'] ?> GB NVMe</li>
                    <li>CPU: <?= $plan['cpu_percent'] ?>% Core</li>
                    <li>RAM: <?= $plan['ram_mb'] ?> MB</li>
                    <li>IP Manzil: Shared</li>
                    <li>SSL: Bepul Let's Encrypt</li>
                </ul>
                <div style="margin-top: 20px;">
                    <a href="buy_hosting.php?plan_id=<?= $plan['id'] ?>" class="btn btn-outline w-100">Hoziroq sotib olish</a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script src="assets/script.js"></script>
</body>
</html>
