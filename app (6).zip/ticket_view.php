
<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';
check_auth();

$user_id = $_SESSION['user_id'];
$ticket_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Verify ownership
$stmt = $pdo->prepare("SELECT * FROM tickets WHERE id = ? AND user_id = ?");
$stmt->execute([$ticket_id, $user_id]);
$ticket = $stmt->fetch();

if (!$ticket) {
    set_flash('error', 'Tiket topilmadi');
    redirect('support.php');
}

// Handle Reply
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $message = clean($_POST['message']);
    if (!empty($message)) {
        $stmt = $pdo->prepare("INSERT INTO ticket_replies (ticket_id, user_id, message) VALUES (?, ?, ?)");
        $stmt->execute([$ticket_id, $user_id, $message]);
        // Update ticket status to open so admin sees it
        $pdo->prepare("UPDATE tickets SET status = 'open' WHERE id = ?")->execute([$ticket_id]);
        
        redirect("ticket_view.php?id=$ticket_id");
    }
}

// Get Messages
$stmt = $pdo->prepare("
    SELECT tr.*, u.username as user_name, a.username as admin_name 
    FROM ticket_replies tr 
    LEFT JOIN users u ON tr.user_id = u.id 
    LEFT JOIN admins a ON tr.admin_id = a.id 
    WHERE tr.ticket_id = ? 
    ORDER BY tr.created_at ASC
");
$stmt->execute([$ticket_id]);
$messages = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <title>Tiket #<?= $ticket_id ?> - ProHost Uz</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="dashboard-layout">
        <aside class="sidebar">
            <ul class="sidebar-menu">
                <li><a href="dashboard.php">🏠 Asosiy oyna</a></li>
                <li><a href="support.php" class="active">🎫 Qo'llab-quvvatlash</a></li>
            </ul>
        </aside>

        <main class="main-content">
            <div class="mb-20">
                <a href="support.php" style="color:var(--text-muted)">&larr; Orqaga</a>
            </div>
            
            <div class="card">
                <div class="card-header d-flex justify-between">
                    <span>#<?= $ticket_id ?> - <?= clean($ticket['subject']) ?></span>
                    <span class="badge badge-<?= $ticket['status'] ?>"><?= ucfirst($ticket['status']) ?></span>
                </div>
                
                <div class="chat-box" id="chatBox">
                    <?php foreach($messages as $msg): 
                        $is_admin = !empty($msg['admin_id']);
                        $class = $is_admin ? 'admin' : 'user';
                        $name = $is_admin ? 'Admin' : 'Siz';
                    ?>
                    <div class="message <?= $class ?>">
                        <div style="font-weight:bold; margin-bottom:5px"><?= $name ?></div>
                        <?= nl2br(clean($msg['message'])) ?>
                        <span class="message-meta"><?= date('d.m.Y H:i', strtotime($msg['created_at'])) ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>

                <div class="ticket-reply-area">
                    <form method="POST">
                        <input type="hidden" name="csrf_token" value="<?= generate_csrf() ?>">
                        <div class="form-group">
                            <textarea name="message" class="form-control" placeholder="Javob yozing..." required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Yuborish</button>
                    </form>
                </div>
            </div>
        </main>
    </div>
    <script>
        // Scroll to bottom
        const chatBox = document.getElementById('chatBox');
        chatBox.scrollTop = chatBox.scrollHeight;
    </script>
</body>
</html>
