
<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';
check_auth();

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// Active Services
$stmt = $pdo->prepare("
    SELECT o.*, p.name as plan_name 
    FROM hosting_orders o 
    JOIN hosting_plans p ON o.plan_id = p.id 
    WHERE o.user_id = ? 
    ORDER BY o.created_at DESC
");
$stmt->execute([$user_id]);
$orders = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - ProHost Uz</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <?php display_flash(); ?>
    <nav class="navbar">
        <div class="container d-flex justify-between" style="height:100%">
            <a href="index.php" class="logo">ProHost <span>Uz</span></a>
            <div class="d-flex">
                <span style="margin-right:20px">Balans: <b class="text-success"><?= format_money($user['balance']) ?></b></span>
                <a href="logout.php" class="btn btn-outline btn-sm">Chiqish</a>
            </div>
        </div>
    </nav>

    <div class="dashboard-layout">
        <aside class="sidebar">
            <ul class="sidebar-menu">
                <li><a href="dashboard.php" class="active">🏠 Asosiy oyna</a></li>
                <li><a href="buy_hosting.php">🛍️ Hosting sotib olish</a></li>
                <li><a href="payment.php">💳 Balansni to'ldirish</a></li>
                <li><a href="support.php">🎫 Qo'llab-quvvatlash</a></li>
                <li><a href="profile.php">👤 Sozlamalar</a></li>
            </ul>
        </aside>

        <main class="main-content">
            <h2>Xush kelibsiz, <?= clean($user['username']) ?>!</h2>
            
            <div class="stats-grid mt-20">
                <div class="stat-card">
                    <div class="stat-title">Mening Balansim</div>
                    <div class="stat-value text-success"><?= format_money($user['balance']) ?></div>
                    <a href="payment.php" style="font-size:12px; margin-top:5px; display:block">To'ldirish &rarr;</a>
                </div>
                <div class="stat-card">
                    <div class="stat-title">Aktiv Xizmatlar</div>
                    <div class="stat-value"><?= count($orders) ?> ta</div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <span>Mening Hostinglarim</span>
                    <a href="buy_hosting.php" class="btn btn-primary btn-sm">+ Yangi qo'shish</a>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Tarif</th>
                                <th>IP Manzil</th>
                                <th>Username / Parol</th>
                                <th>Holati</th>
                                <th>Tugash vaqti</th>
                                <th>Boshqaruv</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(empty($orders)): ?>
                                <tr><td colspan="7" class="text-center">Xizmatlar mavjud emas</td></tr>
                            <?php else: foreach($orders as $order): ?>
                                <tr>
                                    <td>#<?= $order['id'] ?></td>
                                    <td><?= clean($order['plan_name']) ?></td>
                                    <td><?= $order['server_ip'] ?></td>
                                    <td>
                                        <small>U: <?= $order['hosting_username'] ?></small><br>
                                        <small>P: <span id="pwd-<?= $order['id'] ?>"><?= $order['hosting_password'] ?></span></small>
                                        <button class="copy-btn btn-outline" style="border:none; padding:0 5px;" data-target="#pwd-<?= $order['id'] ?>">📋</button>
                                    </td>
                                    <td><span class="badge badge-<?= $order['status'] ?>"><?= ucfirst($order['status']) ?></span></td>
                                    <td><?= date('d.m.Y', strtotime($order['expires_at'])) ?></td>
                                    <td>
                                        <a href="#" class="btn btn-outline btn-sm">Panelga kirish</a>
                                    </td>
                                </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
    <script src="assets/script.js"></script>
</body>
</html>
