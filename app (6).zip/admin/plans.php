
<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

if (!isset($_SERVER['PHP_AUTH_USER'])) { header('Location: index.php'); exit; }

// Add Plan
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = clean($_POST['name']);
    $disk = (int)$_POST['disk'];
    $cpu = (int)$_POST['cpu'];
    $ram = (int)$_POST['ram'];
    $price = (float)$_POST['price'];
    
    $pdo->prepare("INSERT INTO hosting_plans (name, disk_gb, cpu_percent, ram_mb, price_uzs) VALUES (?, ?, ?, ?, ?)")
        ->execute([$name, $disk, $cpu, $ram, $price]);
    set_flash('success', 'Yangi tarif qo\'shildi');
    redirect('plans.php');
}

// Delete Plan
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $pdo->prepare("DELETE FROM hosting_plans WHERE id = ?")->execute([$id]);
    redirect('plans.php');
}

$plans = $pdo->query("SELECT * FROM hosting_plans")->fetchAll();
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <title>Tariflar - Admin</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <?php display_flash(); ?>
    <div class="dashboard-layout">
        <aside class="sidebar">
            <ul class="sidebar-menu">
                <li><a href="index.php">📊 Statistika</a></li>
                <li><a href="orders.php">📦 Buyurtmalar</a></li>
                <li><a href="plans.php" class="active">📋 Tariflar</a></li>
                <li><a href="settings.php">⚙️ Sozlamalar</a></li>
            </ul>
        </aside>
        <main class="main-content">
            <h2>Tariflar Rejasi</h2>
            
            <div class="d-flex justify-between" style="align-items:start; gap:20px;">
                <!-- List -->
                <div class="card w-100">
                    <div class="card-header">Mavjud Tariflar</div>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Nomi</th>
                                <th>Disk (GB)</th>
                                <th>CPU (%)</th>
                                <th>RAM (MB)</th>
                                <th>Narx (UZS)</th>
                                <th>Amal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($plans as $p): ?>
                            <tr>
                                <td><b><?= clean($p['name']) ?></b></td>
                                <td><?= $p['disk_gb'] ?></td>
                                <td><?= $p['cpu_percent'] ?></td>
                                <td><?= $p['ram_mb'] ?></td>
                                <td><?= format_money($p['price_uzs']) ?></td>
                                <td><a href="?delete=<?= $p['id'] ?>" class="text-danger" onclick="return confirm('O\'chirilsinmi?')">O'chirish</a></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Add Form -->
                <div class="card" style="min-width: 300px;">
                    <div class="card-header">Yangi Tarif</div>
                    <form method="POST">
                        <div class="form-group">
                            <label class="form-label">Nomi</label>
                            <input type="text" name="name" class="form-control" required placeholder="Masalan: Ultra">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Disk (GB)</label>
                            <input type="number" name="disk" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">CPU (%)</label>
                            <input type="number" name="cpu" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">RAM (MB)</label>
                            <input type="number" name="ram" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Narx (UZS)</label>
                            <input type="number" name="price" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Qo'shish</button>
                    </form>
                </div>
            </div>
        </main>
    </div>
    <script src="../assets/script.js"></script>
</body>
</html>
