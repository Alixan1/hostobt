
<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

if (!isset($_SERVER['PHP_AUTH_USER'])) { header('Location: index.php'); exit; }

// Process Payment
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $action = $_GET['action'];
    
    // Get payment details
    $stmt = $pdo->prepare("SELECT * FROM payments WHERE id = ?");
    $stmt->execute([$id]);
    $pay = $stmt->fetch();

    if ($pay && $pay['status'] === 'pending') {
        if ($action === 'approve') {
            $pdo->beginTransaction();
            try {
                // Update payment status
                $pdo->prepare("UPDATE payments SET status = 'completed' WHERE id = ?")->execute([$id]);
                // Add balance to user
                $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?")->execute([$pay['amount'], $pay['user_id']]);
                
                $pdo->commit();
                set_flash('success', 'To\'lov tasdiqlandi va balans to\'ldirildi');
            } catch (Exception $e) {
                $pdo->rollBack();
                set_flash('error', 'Xatolik: ' . $e->getMessage());
            }
        } elseif ($action === 'reject') {
            $pdo->prepare("UPDATE payments SET status = 'cancelled' WHERE id = ?")->execute([$id]);
            set_flash('success', 'To\'lov bekor qilindi');
        }
    }
    redirect('payments.php');
}

$payments = $pdo->query("
    SELECT p.*, u.username 
    FROM payments p 
    JOIN users u ON p.user_id = u.id 
    ORDER BY p.created_at DESC
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <title>To'lovlar - Admin</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <?php display_flash(); ?>
    <div class="dashboard-layout">
        <aside class="sidebar">
            <ul class="sidebar-menu">
                <li><a href="index.php">📊 Statistika</a></li>
                <li><a href="users.php">👥 Foydalanuvchilar</a></li>
                <li><a href="payments.php" class="active">💰 To'lovlar</a></li>
                <li><a href="settings.php">⚙️ Sozlamalar</a></li>
            </ul>
        </aside>
        <main class="main-content">
            <h2>To'lovlar Tarixi</h2>
            <div class="card mt-20">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Foydalanuvchi</th>
                            <th>Summa</th>
                            <th>Turi</th>
                            <th>Status</th>
                            <th>Sana</th>
                            <th>Amallar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($payments as $pay): ?>
                        <tr>
                            <td>#<?= $pay['id'] ?></td>
                            <td><?= clean($pay['username']) ?></td>
                            <td><?= format_money($pay['amount']) ?></td>
                            <td><?= ucfirst($pay['type']) ?></td>
                            <td><span class="badge badge-<?= $pay['status'] ?>"><?= $pay['status'] ?></span></td>
                            <td><?= $pay['created_at'] ?></td>
                            <td>
                                <?php if($pay['status'] === 'pending'): ?>
                                    <a href="?action=approve&id=<?= $pay['id'] ?>" class="btn btn-sm btn-primary">Tasdiqlash</a>
                                    <a href="?action=reject&id=<?= $pay['id'] ?>" class="btn btn-sm btn-danger">Bekor qilish</a>
                                <?php else: ?>
                                    <span style="color:var(--text-muted)">-</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
    <script src="../assets/script.js"></script>
</body>
</html>
