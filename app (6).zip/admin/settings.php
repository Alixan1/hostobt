
<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

if (!isset($_SERVER['PHP_AUTH_USER'])) { header('Location: index.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($_POST as $key => $value) {
        if ($key !== 'csrf_token') {
            update_setting($pdo, $key, clean($value));
        }
    }
    set_flash('success', 'Sozlamalar saqlandi');
    redirect('settings.php');
}

$site_name = get_setting($pdo, 'site_name') ?: 'ProHost Uz';
$min_payment = get_setting($pdo, 'min_payment') ?: '5000';
$contact_email = get_setting($pdo, 'site_email') ?: '';
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <title>Sozlamalar - Admin</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <?php display_flash(); ?>
    <div class="dashboard-layout">
        <aside class="sidebar">
            <ul class="sidebar-menu">
                <li><a href="index.php">📊 Statistika</a></li>
                <li><a href="users.php">👥 Foydalanuvchilar</a></li>
                <li><a href="orders.php">📦 Buyurtmalar</a></li>
                <li><a href="settings.php" class="active">⚙️ Sozlamalar</a></li>
            </ul>
        </aside>
        <main class="main-content">
            <h2>Sayt Sozlamalari</h2>
            <div class="card mt-20" style="max-width: 600px;">
                <form method="POST">
                    <div class="form-group">
                        <label class="form-label">Sayt Nomi</label>
                        <input type="text" name="site_name" class="form-control" value="<?= $site_name ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Minimal To'lov (UZS)</label>
                        <input type="number" name="min_payment" class="form-control" value="<?= $min_payment ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Aloqa Email</label>
                        <input type="email" name="site_email" class="form-control" value="<?= $contact_email ?>">
                    </div>
                    <button type="submit" class="btn btn-primary">Saqlash</button>
                </form>
            </div>
        </main>
    </div>
    <script src="../assets/script.js"></script>
</body>
</html>
