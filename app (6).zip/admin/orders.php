
<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

if (!isset($_SERVER['PHP_AUTH_USER'])) { header('Location: index.php'); exit; }

// Actions
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $action = $_GET['action'];
    
    if ($action === 'suspend') {
        $pdo->prepare("UPDATE hosting_orders SET status = 'suspended' WHERE id = ?")->execute([$id]);
        set_flash('success', 'Xizmat to\'xtatildi');
    } elseif ($action === 'activate') {
        $pdo->prepare("UPDATE hosting_orders SET status = 'active' WHERE id = ?")->execute([$id]);
        set_flash('success', 'Xizmat aktivlashtirildi');
    } elseif ($action === 'terminate') {
        $pdo->prepare("UPDATE hosting_orders SET status = 'terminated' WHERE id = ?")->execute([$id]);
        set_flash('success', 'Xizmat butunlay o\'chirildi');
    }
    redirect('orders.php');
}

$stmt = $pdo->query("
    SELECT o.*, u.username, p.name as plan_name 
    FROM hosting_orders o 
    JOIN users u ON o.user_id = u.id 
    JOIN hosting_plans p ON o.plan_id = p.id 
    ORDER BY o.created_at DESC
");
$orders = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <title>Buyurtmalar - Admin</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <?php display_flash(); ?>
    <div class="dashboard-layout">
        <aside class="sidebar">
            <ul class="sidebar-menu">
                <li><a href="index.php">📊 Statistika</a></li>
                <li><a href="users.php">👥 Foydalanuvchilar</a></li>
                <li><a href="orders.php" class="active">📦 Buyurtmalar</a></li>
                <li><a href="plans.php">📋 Tariflar</a></li>
                <li><a href="payments.php">💰 To'lovlar</a></li>
                <li><a href="logs.php">📜 Loglar</a></li>
                <li><a href="settings.php">⚙️ Sozlamalar</a></li>
            </ul>
        </aside>
        <main class="main-content">
            <h2>Barcha Hosting Buyurtmalari</h2>
            <div class="card mt-20">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>User</th>
                                <th>Tarif</th>
                                <th>Hosting Login</th>
                                <th>Status</th>
                                <th>Tugash sanasi</th>
                                <th>Boshqaruv</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($orders as $order): ?>
                            <tr>
                                <td>#<?= $order['id'] ?></td>
                                <td><?= clean($order['username']) ?></td>
                                <td><?= clean($order['plan_name']) ?></td>
                                <td><?= clean($order['hosting_username']) ?></td>
                                <td><span class="badge badge-<?= $order['status'] ?>"><?= ucfirst($order['status']) ?></span></td>
                                <td><?= date('d.m.Y', strtotime($order['expires_at'])) ?></td>
                                <td>
                                    <?php if($order['status'] === 'active'): ?>
                                        <a href="?action=suspend&id=<?= $order['id'] ?>" class="btn btn-sm btn-outline" style="color:var(--warning);border-color:var(--warning)">To'xtatish</a>
                                    <?php else: ?>
                                        <a href="?action=activate&id=<?= $order['id'] ?>" class="btn btn-sm btn-outline" style="color:var(--success);border-color:var(--success)">Aktivlash</a>
                                    <?php endif; ?>
                                    <a href="?action=terminate&id=<?= $order['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Rostdan ham o\'chirmoqchimisiz?')">O'chirish</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
    <script src="../assets/script.js"></script>
</body>
</html>
