
<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

// Auth check
if (!isset($_SERVER['PHP_AUTH_USER'])) { header('Location: index.php'); exit; }

// Action: Delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $pdo->prepare("DELETE FROM users WHERE id = ?")->execute([$id]);
    redirect('users.php');
}

$users = $pdo->query("SELECT * FROM users ORDER BY id DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <title>Users - Admin</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <div class="dashboard-layout">
        <aside class="sidebar">
            <ul class="sidebar-menu">
                <li><a href="index.php">📊 Statistika</a></li>
                <li><a href="users.php" class="active">👥 Foydalanuvchilar</a></li>
            </ul>
        </aside>
        <main class="main-content">
            <h2>Foydalanuvchilar Boshqaruvi</h2>
            <div class="card mt-20">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Username</th>
                            <th>Balans</th>
                            <th>Status</th>
                            <th>Amallar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($users as $user): ?>
                        <tr>
                            <td><?= $user['id'] ?></td>
                            <td><?= clean($user['username']) ?></td>
                            <td><?= format_money($user['balance']) ?></td>
                            <td><span class="badge badge-<?= $user['status'] == 'active' ? 'success' : 'terminated' ?>"><?= $user['status'] ?></span></td>
                            <td>
                                <a href="?delete=<?= $user['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('O\'chirilsinmi?')">O'chirish</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</body>
</html>
