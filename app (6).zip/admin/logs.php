
<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

if (!isset($_SERVER['PHP_AUTH_USER'])) { header('Location: index.php'); exit; }

$stmt = $pdo->query("
    SELECT l.*, u.username 
    FROM logs l 
    LEFT JOIN users u ON l.user_id = u.id 
    ORDER BY l.created_at DESC 
    LIMIT 100
");
$logs = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <title>Loglar - Admin</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <div class="dashboard-layout">
        <aside class="sidebar">
            <ul class="sidebar-menu">
                <li><a href="index.php">📊 Statistika</a></li>
                <li><a href="logs.php" class="active">📜 Loglar</a></li>
            </ul>
        </aside>
        <main class="main-content">
            <h2>Tizim Loglari (Oxirgi 100 ta)</h2>
            <div class="card mt-20">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Foydalanuvchi</th>
                            <th>Harakat</th>
                            <th>Batafsil</th>
                            <th>IP Manzil</th>
                            <th>Vaqt</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($logs as $log): ?>
                        <tr>
                            <td>#<?= $log['id'] ?></td>
                            <td><?= $log['username'] ? clean($log['username']) : '<span style="color:var(--text-muted)">Mehmon</span>' ?></td>
                            <td><?= clean($log['action']) ?></td>
                            <td><small><?= clean($log['details']) ?></small></td>
                            <td><?= $log['ip_address'] ?></td>
                            <td><?= $log['created_at'] ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</body>
</html>
