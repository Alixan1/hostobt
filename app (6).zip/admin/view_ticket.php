
<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

if (!isset($_SERVER['PHP_AUTH_USER'])) { header('Location: index.php'); exit; }
$admin_id = 1;
$ticket_id = (int)$_GET['id'];

$stmt = $pdo->prepare("SELECT t.*, u.username FROM tickets t JOIN users u ON t.user_id = u.id WHERE t.id = ?");
$stmt->execute([$ticket_id]);
$ticket = $stmt->fetch();

if (!$ticket) redirect('tickets.php');

// Reply
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['reply'])) {
        $msg = clean($_POST['message']);
        $pdo->prepare("INSERT INTO ticket_replies (ticket_id, admin_id, message) VALUES (?, ?, ?)")->execute([$ticket_id, $admin_id, $msg]);
        $pdo->prepare("UPDATE tickets SET status = 'answered' WHERE id = ?")->execute([$ticket_id]);
        redirect("view_ticket.php?id=$ticket_id");
    } elseif (isset($_POST['close'])) {
        $pdo->prepare("UPDATE tickets SET status = 'closed' WHERE id = ?")->execute([$ticket_id]);
        redirect("view_ticket.php?id=$ticket_id");
    }
}

$msgs = $pdo->prepare("SELECT * FROM ticket_replies WHERE ticket_id = ? ORDER BY created_at ASC");
$msgs->execute([$ticket_id]);
$messages = $msgs->fetchAll();
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <title>Tiket #<?= $ticket_id ?> - Admin</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <div class="dashboard-layout">
        <aside class="sidebar">
            <ul class="sidebar-menu">
                <li><a href="tickets.php">🎫 Tiketlar</a></li>
            </ul>
        </aside>
        <main class="main-content">
             <div class="mb-20"><a href="tickets.php">&larr; Orqaga</a></div>
             
             <div class="card">
                <div class="card-header d-flex justify-between">
                    <span>Tiket #<?= $ticket_id ?> (User: <?= $ticket['username'] ?>)</span>
                    <form method="POST" style="display:inline">
                        <button type="submit" name="close" class="btn btn-sm btn-danger" onclick="return confirm('Yopilsinmi?')">Yopish</button>
                    </form>
                </div>

                <div class="chat-box" style="margin-bottom:20px; border:1px solid var(--border); padding:10px; border-radius:6px;">
                    <?php foreach($messages as $m): 
                        $is_admin = !empty($m['admin_id']);
                        $class = $is_admin ? 'user' : 'admin'; // Admin styleni user (o'ng) tomonga o'zgartiramiz admin panelda
                        $name = $is_admin ? 'Admin (Siz)' : $ticket['username'];
                    ?>
                    <div class="message <?= $class ?>" style="<?= $is_admin ? 'background:var(--accent)' : 'background:var(--bg-dark)' ?>">
                        <div style="font-weight:bold"><?= $name ?></div>
                        <?= nl2br(clean($m['message'])) ?>
                    </div>
                    <?php endforeach; ?>
                </div>

                <form method="POST">
                    <div class="form-group">
                        <textarea name="message" class="form-control" placeholder="Javob yozing..." required></textarea>
                    </div>
                    <button type="submit" name="reply" class="btn btn-primary">Javob berish</button>
                </form>
             </div>
        </main>
    </div>
</body>
</html>
