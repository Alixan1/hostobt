
<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

if (!isset($_SERVER['PHP_AUTH_USER'])) { header('Location: index.php'); exit; }

$tickets = $pdo->query("
    SELECT t.*, u.username 
    FROM tickets t 
    JOIN users u ON t.user_id = u.id 
    ORDER BY CASE WHEN t.status = 'open' THEN 1 ELSE 2 END, t.created_at DESC
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <title>Tiketlar - Admin</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <div class="dashboard-layout">
        <aside class="sidebar">
            <ul class="sidebar-menu">
                <li><a href="index.php">📊 Statistika</a></li>
                <li><a href="users.php">👥 Foydalanuvchilar</a></li>
                <li><a href="tickets.php" class="active">🎫 Tiketlar</a></li>
                <li><a href="settings.php">⚙️ Sozlamalar</a></li>
            </ul>
        </aside>
        <main class="main-content">
            <h2>Murojaatlar (Tiketlar)</h2>
            <div class="card mt-20">
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>User</th>
                            <th>Mavzu</th>
                            <th>Status</th>
                            <th>Sana</th>
                            <th>Amallar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($tickets as $t): ?>
                        <tr style="<?= $t['status'] == 'open' ? 'background:rgba(56,139,253,0.05)' : '' ?>">
                            <td>#<?= $t['id'] ?></td>
                            <td><?= clean($t['username']) ?></td>
                            <td><?= clean($t['subject']) ?></td>
                            <td><span class="badge badge-<?= $t['status'] == 'open' ? 'active' : ($t['status'] == 'answered' ? 'success' : 'closed') ?>"><?= ucfirst($t['status']) ?></span></td>
                            <td><?= date('d.m H:i', strtotime($t['created_at'])) ?></td>
                            <td>
                                <a href="view_ticket.php?id=<?= $t['id'] ?>" class="btn btn-sm btn-primary">Ochish</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</body>
</html>
