
<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

// Admin Auth Check (Mock)
if (!isset($_SERVER['PHP_AUTH_USER']) || $_SERVER['PHP_AUTH_USER'] !== 'admin' || $_SERVER['PHP_AUTH_PW'] !== 'Admin2026!') {
    header('WWW-Authenticate: Basic realm="Admin Area"');
    header('HTTP/1.0 401 Unauthorized');
    echo 'Admin huquqi talab qilinadi';
    exit;
}
$_SESSION['admin_id'] = 1;

// Stats
$users_count = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$orders_count = $pdo->query("SELECT COUNT(*) FROM hosting_orders")->fetchColumn();
$tickets_count = $pdo->query("SELECT COUNT(*) FROM tickets WHERE status='open'")->fetchColumn();
$income = $pdo->query("SELECT SUM(amount) FROM payments WHERE status='completed'")->fetchColumn() ?: 0;
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="../assets/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>body { background: #010409; }</style>
</head>
<body>
    <nav class="navbar">
        <div class="container d-flex justify-between">
            <a href="#" class="logo">Admin<span>Panel</span></a>
            <a href="../index.php" class="btn btn-outline btn-sm">Saytga qaytish</a>
        </div>
    </nav>

    <div class="dashboard-layout">
        <aside class="sidebar">
            <ul class="sidebar-menu">
                <li><a href="index.php" class="active">📊 Statistika</a></li>
                <li><a href="users.php">👥 Foydalanuvchilar</a></li>
                <li><a href="orders.php">📦 Buyurtmalar</a></li>
                <li><a href="tickets.php">🎫 Tiketlar <span class="badge badge-active" style="float:right"><?= $tickets_count ?></span></a></li>
                <li><a href="payments.php">💰 To'lovlar</a></li>
                <li><a href="settings.php">⚙️ Sozlamalar</a></li>
            </ul>
        </aside>
        <main class="main-content">
            <h2>Admin Dashboard</h2>
            <div class="stats-grid mt-20">
                <div class="stat-card">
                    <div class="stat-title">Jami Foydalanuvchilar</div>
                    <div class="stat-value"><?= $users_count ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-title">Aktiv Xizmatlar</div>
                    <div class="stat-value"><?= $orders_count ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-title">Ochiq Tiketlar</div>
                    <div class="stat-value" style="color:var(--warning)"><?= $tickets_count ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-title">Umumiy Tushum</div>
                    <div class="stat-value text-success"><?= format_money($income) ?></div>
                </div>
            </div>

            <div class="d-flex" style="gap:20px; align-items:start">
                <div class="card" style="flex:2">
                    <div class="card-header">Tushumlar Statistikasi</div>
                    <canvas id="incomeChart"></canvas>
                </div>
                <div class="card" style="flex:1">
                    <div class="card-header">Oxirgi Foydalanuvchilar</div>
                    <table class="table">
                        <tbody>
                            <?php
                            $latest = $pdo->query("SELECT * FROM users ORDER BY id DESC LIMIT 5")->fetchAll();
                            foreach($latest as $u): ?>
                            <tr>
                                <td><?= clean($u['username']) ?></td>
                                <td><?= $u['created_at'] ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
    <script>
        const ctx = document.getElementById('incomeChart');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Yan', 'Fev', 'Mar', 'Apr', 'May', 'Iyun'],
                datasets: [{
                    label: 'Tushum (UZS)',
                    data: [120000, 190000, 300000, 500000, 200000, <?= $income ?>],
                    borderColor: '#58a6ff',
                    backgroundColor: 'rgba(88, 166, 255, 0.1)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { labels: { color: '#c9d1d9' } } },
                scales: {
                    y: { grid: { color: '#30363d' }, ticks: { color: '#8b949e' } },
                    x: { grid: { color: '#30363d' }, ticks: { color: '#8b949e' } }
                }
            }
        });
    </script>
</body>
</html>
