
<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';

if (isset($_SESSION['user_id'])) redirect('dashboard.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $login = clean($_POST['login']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$login, $login]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        if ($user['status'] === 'banned') {
            set_flash('error', 'Sizning profilingiz bloklangan.');
        } else {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            log_action($pdo, $user['id'], 'login');
            redirect('dashboard.php');
        }
    } else {
        set_flash('error', 'Login yoki parol noto\'g\'ri.');
    }
}
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <title>Kirish - ProHost Uz</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <?php display_flash(); ?>
    <div class="auth-wrapper">
        <div class="card auth-card">
            <h2 class="text-center mb-20">Tizimga kirish</h2>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= generate_csrf() ?>">
                <div class="form-group">
                    <label class="form-label">Login yoki Email</label>
                    <input type="text" name="login" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Parol</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary w-100">Kirish</button>
            </form>
            <p class="text-center mt-20">
                Hisobingiz yo'qmi? <a href="register.php">Ro'yxatdan o'tish</a>
            </p>
            <p class="text-center"><a href="index.php" style="color:var(--text-muted)">Bosh sahifa</a></p>
        </div>
    </div>
    <script src="assets/script.js"></script>
</body>
</html>
