
document.addEventListener('DOMContentLoaded', function() {
    // Toast Notification System
    const toastContainer = document.createElement('div');
    toastContainer.className = 'toast-container';
    document.body.appendChild(toastContainer);

    window.showToast = function(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `<span>${message}</span> <span style="cursor:pointer;margin-left:10px" onclick="this.parentElement.remove()">×</span>`;
        toastContainer.appendChild(toast);
        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => toast.remove(), 300);
        }, 5000);
    };

    // Check for PHP flash messages
    const flashEl = document.getElementById('flash-data');
    if (flashEl) {
        showToast(flashEl.dataset.message, flashEl.dataset.type);
    }

    // Copy to Clipboard
    document.querySelectorAll('.copy-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const target = document.querySelector(btn.dataset.target);
            navigator.clipboard.writeText(target.innerText || target.value)
                .then(() => showToast('Nusxalandi!', 'success'))
                .catch(() => showToast('Xatolik yuz berdi', 'error'));
        });
    });

    // Simple Form Validation
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', function(e) {
            let valid = true;
            form.querySelectorAll('[required]').forEach(input => {
                if (!input.value.trim()) {
                    valid = false;
                    input.style.borderColor = 'var(--danger)';
                } else {
                    input.style.borderColor = 'var(--border)';
                }
            });
            if (!valid) {
                e.preventDefault();
                showToast("Barcha majburiy maydonlarni to'ldiring", "error");
            }
        });
    });
});
