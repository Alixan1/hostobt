
<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';
check_auth();

$user_id = $_SESSION['user_id'];

// Handle Manual Payment Request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['manual_pay'])) {
    check_csrf();
    $amount = (float)$_POST['amount'];
    // Chek rasm yuklash logikasi (soddalashtirilgan)
    $check_name = 'check_' . time() . '.jpg'; 
    // real upload logic would go here: move_uploaded_file(...)
    
    $stmt = $pdo->prepare("INSERT INTO payments (user_id, amount, type, status, check_image) VALUES (?, ?, 'manual', 'pending', ?)");
    $stmt->execute([$user_id, $amount, $check_name]);
    set_flash('success', 'To\'lov so\'rovi yuborildi. Admin tasdiqlashini kuting.');
    redirect('payment.php');
}

// Xspin API Logic (Mock implementation based on requirements)
// In a real scenario, this would be a separate endpoint file (api/webhook.php)
// But for this simulation, we'll put the form generator here.
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <title>Balansni to'ldirish</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <?php display_flash(); ?>
    <div class="dashboard-layout">
        <aside class="sidebar">
            <ul class="sidebar-menu">
                <li><a href="dashboard.php">🏠 Asosiy oyna</a></li>
                <li><a href="buy_hosting.php">🛍️ Hosting sotib olish</a></li>
                <li><a href="payment.php" class="active">💳 Balansni to'ldirish</a></li>
            </ul>
        </aside>
        <main class="main-content">
            <h2>Balansni to'ldirish</h2>
            
            <div class="card">
                <div class="card-header">Avtomatik to'lov (Xspin/Click/Payme)</div>
                <form action="https://xspin.uz/api/payment" method="GET" target="_blank">
                    <!-- Bu yerda API ma'lumotlari bo'lishi kerak -->
                    <div class="form-group">
                        <label class="form-label">Summa (UZS)</label>
                        <input type="number" name="amount" class="form-control" min="1000" value="10000">
                    </div>
                    <button type="button" class="btn btn-primary" onclick="showToast('API kaliti ulanmagan (Demo rejim)', 'error')">To'lash (Xspin)</button>
                </form>
            </div>

            <div class="card">
                <div class="card-header">Manual To'lov (Chek orqali)</div>
                <form method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token" value="<?= generate_csrf() ?>">
                    <input type="hidden" name="manual_pay" value="1">
                    <div class="form-group">
                        <label class="form-label">Summa (UZS)</label>
                        <input type="number" name="amount" class="form-control" required min="1000">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Chek Rasmi</label>
                        <input type="file" name="check_file" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Yuborish</button>
                </form>
            </div>

            <h3>To'lovlar tarixi</h3>
            <div class="table-responsive">
                <table class="table">
                    <thead><tr><th>ID</th><th>Summa</th><th>Turi</th><th>Holat</th><th>Sana</th></tr></thead>
                    <tbody>
                        <?php
                        $pays = $pdo->prepare("SELECT * FROM payments WHERE user_id = ? ORDER BY created_at DESC");
                        $pays->execute([$user_id]);
                        foreach($pays->fetchAll() as $pay): ?>
                        <tr>
                            <td><?= $pay['id'] ?></td>
                            <td><?= format_money($pay['amount']) ?></td>
                            <td><?= ucfirst($pay['type']) ?></td>
                            <td><span class="badge badge-<?= $pay['status'] === 'completed' ? 'success' : 'suspended' ?>"><?= $pay['status'] ?></span></td>
                            <td><?= $pay['created_at'] ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
    <script src="assets/script.js"></script>
</body>
</html>
