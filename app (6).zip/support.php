
<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';
check_auth();

$user_id = $_SESSION['user_id'];

// Create Ticket
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $subject = clean($_POST['subject']);
    $message = clean($_POST['message']);
    
    if (!empty($subject) && !empty($message)) {
        $pdo->beginTransaction();
        try {
            // Create ticket
            $stmt = $pdo->prepare("INSERT INTO tickets (user_id, subject, status) VALUES (?, ?, 'open')");
            $stmt->execute([$user_id, $subject]);
            $ticket_id = $pdo->lastInsertId();
            
            // Add first message
            $stmt = $pdo->prepare("INSERT INTO ticket_replies (ticket_id, user_id, message) VALUES (?, ?, ?)");
            $stmt->execute([$ticket_id, $user_id, $message]);
            
            $pdo->commit();
            set_flash('success', 'Tiket muvaffaqiyatli ochildi');
            redirect('ticket_view.php?id=' . $ticket_id);
        } catch (Exception $e) {
            $pdo->rollBack();
            set_flash('error', 'Xatolik yuz berdi');
        }
    }
}

$tickets = $pdo->prepare("SELECT * FROM tickets WHERE user_id = ? ORDER BY created_at DESC");
$tickets->execute([$user_id]);
$ticket_list = $tickets->fetchAll();
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <title>Qo'llab-quvvatlash - ProHost Uz</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <?php display_flash(); ?>
    <div class="dashboard-layout">
        <aside class="sidebar">
            <ul class="sidebar-menu">
                <li><a href="dashboard.php">🏠 Asosiy oyna</a></li>
                <li><a href="buy_hosting.php">🛍️ Hosting sotib olish</a></li>
                <li><a href="payment.php">💳 Balansni to'ldirish</a></li>
                <li><a href="support.php" class="active">🎫 Qo'llab-quvvatlash</a></li>
                <li><a href="profile.php">👤 Sozlamalar</a></li>
            </ul>
        </aside>

        <main class="main-content">
            <div class="d-flex justify-between mb-20">
                <h2>Qo'llab-quvvatlash markazi</h2>
                <button onclick="document.getElementById('newTicketForm').style.display='block'" class="btn btn-primary">+ Yangi Tiket</button>
            </div>

            <!-- New Ticket Form -->
            <div id="newTicketForm" class="card" style="display:none; border: 1px solid var(--primary);">
                <div class="card-header">Yangi murojaat yaratish</div>
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?= generate_csrf() ?>">
                    <div class="form-group">
                        <label class="form-label">Mavzu</label>
                        <input type="text" name="subject" class="form-control" required placeholder="Masalan: Hosting ishlamayapti">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Xabar matni</label>
                        <textarea name="message" class="form-control" required placeholder="Muammoni batafsil tushuntiring..."></textarea>
                    </div>
                    <div class="d-flex justify-end" style="gap:10px">
                        <button type="button" class="btn btn-outline" onclick="document.getElementById('newTicketForm').style.display='none'">Bekor qilish</button>
                        <button type="submit" class="btn btn-primary">Yuborish</button>
                    </div>
                </form>
            </div>

            <div class="card">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Mavzu</th>
                                <th>Status</th>
                                <th>Sana</th>
                                <th>Amal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(empty($ticket_list)): ?>
                                <tr><td colspan="5" class="text-center">Murojaatlar mavjud emas</td></tr>
                            <?php else: foreach($ticket_list as $ticket): ?>
                                <tr>
                                    <td>#<?= $ticket['id'] ?></td>
                                    <td><?= clean($ticket['subject']) ?></td>
                                    <td><span class="badge badge-<?= $ticket['status'] ?>"><?= ucfirst($ticket['status']) ?></span></td>
                                    <td><?= date('d.m.Y H:i', strtotime($ticket['created_at'])) ?></td>
                                    <td><a href="ticket_view.php?id=<?= $ticket['id'] ?>" class="btn btn-sm btn-outline">Ochish</a></td>
                                </tr>
                            <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
    <script src="assets/script.js"></script>
</body>
</html>
