
<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';

if (isset($_SESSION['user_id'])) redirect('dashboard.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $username = clean($_POST['username']);
    $email = clean($_POST['email']);
    $password = $_POST['password'];

    if (strlen($password) < 6) {
        set_flash('error', 'Parol kamida 6 ta belgidan iborat bo\'lishi kerak.');
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);
        if ($stmt->rowCount() > 0) {
            set_flash('error', 'Bu foydalanuvchi yoki email allaqachon band.');
        } else {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
            if ($stmt->execute([$username, $email, $hash])) {
                set_flash('success', 'Muvaffaqiyatli ro\'yxatdan o\'tdingiz. Endi kirishingiz mumkin.');
                redirect('login.php');
            } else {
                set_flash('error', 'Tizim xatoligi.');
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <title>Ro'yxatdan o'tish - ProHost Uz</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <?php display_flash(); ?>
    <div class="auth-wrapper">
        <div class="card auth-card">
            <h2 class="text-center mb-20">Ro'yxatdan o'tish</h2>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= generate_csrf() ?>">
                <div class="form-group">
                    <label class="form-label">Foydalanuvchi nomi</label>
                    <input type="text" name="username" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Parol</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary w-100">Ro'yxatdan o'tish</button>
            </form>
            <p class="text-center mt-20">
                Profilingiz bormi? <a href="login.php">Kirish</a>
            </p>
        </div>
    </div>
    <script src="assets/script.js"></script>
</body>
</html>
