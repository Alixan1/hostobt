
<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';
check_auth();

$user_id = $_SESSION['user_id'];
$plan_id = isset($_GET['plan_id']) ? (int)$_GET['plan_id'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $plan_id = (int)$_POST['plan_id'];

    // Get Plan
    $stmt = $pdo->prepare("SELECT * FROM hosting_plans WHERE id = ?");
    $stmt->execute([$plan_id]);
    $plan = $stmt->fetch();

    // Get User
    $stmt = $pdo->prepare("SELECT balance FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user_balance = $stmt->fetchColumn();

    if (!$plan) {
        set_flash('error', 'Tarif topilmadi.');
    } elseif ($user_balance < $plan['price_uzs']) {
        set_flash('error', 'Balans yetarli emas. Iltimos, hisobni to\'ldiring.');
        redirect('payment.php');
    } else {
        // Generate Credentials
        $hosting_user = 'ihost' . rand(1000, 9999);
        $hosting_pass = substr(str_shuffle('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, 16);
        $expires_at = date('Y-m-d H:i:s', strtotime('+30 days'));

        $pdo->beginTransaction();
        try {
            // Deduct Balance
            $new_balance = $user_balance - $plan['price_uzs'];
            $pdo->prepare("UPDATE users SET balance = ? WHERE id = ?")->execute([$new_balance, $user_id]);

            // Create Order
            $stmt = $pdo->prepare("INSERT INTO hosting_orders (user_id, plan_id, hosting_username, hosting_password, price_at_purchase, expires_at) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$user_id, $plan['id'], $hosting_user, $hosting_pass, $plan['price_uzs'], $expires_at]);

            log_action($pdo, $user_id, 'buy_hosting', "Tarif: {$plan['name']}, Narx: {$plan['price_uzs']}");
            
            $pdo->commit();
            set_flash('success', 'Hosting muvaffaqiyatli sotib olindi!');
            redirect('dashboard.php');
        } catch (Exception $e) {
            $pdo->rollBack();
            set_flash('error', 'Xatolik yuz berdi: ' . $e->getMessage());
        }
    }
}

// Fetch all plans for selection
$plans = $pdo->query("SELECT * FROM hosting_plans ORDER BY price_uzs ASC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <title>Hosting Sotib Olish</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <?php display_flash(); ?>
    <div class="dashboard-layout">
        <aside class="sidebar">
            <ul class="sidebar-menu">
                <li><a href="dashboard.php">🏠 Asosiy oyna</a></li>
                <li><a href="buy_hosting.php" class="active">🛍️ Hosting sotib olish</a></li>
                <li><a href="payment.php">💳 Balansni to'ldirish</a></li>
            </ul>
        </aside>
        <main class="main-content">
            <h2>Hosting Tarifini Tanlang</h2>
            <div class="pricing-grid">
                <?php foreach($plans as $plan): ?>
                <div class="card price-card" style="<?= ($plan_id == $plan['id']) ? 'border-color:var(--primary)' : '' ?>">
                    <h3><?= clean($plan['name']) ?></h3>
                    <div class="price-amount"><?= format_money($plan['price_uzs']) ?></div>
                    <ul class="price-features">
                        <li><?= $plan['disk_gb'] ?> GB Disk</li>
                        <li><?= $plan['cpu_percent'] ?>% CPU</li>
                        <li><?= $plan['ram_mb'] ?> MB RAM</li>
                    </ul>
                    <form method="POST" style="margin-top:15px">
                        <input type="hidden" name="csrf_token" value="<?= generate_csrf() ?>">
                        <input type="hidden" name="plan_id" value="<?= $plan['id'] ?>">
                        <button type="submit" class="btn btn-primary w-100" onclick="return confirm('Sotib olishni tasdiqlaysizmi?')">Sotib Olish</button>
                    </form>
                </div>
                <?php endforeach; ?>
            </div>
        </main>
    </div>
    <script src="assets/script.js"></script>
</body>
</html>
