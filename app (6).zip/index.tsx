
import React from 'react';
import { createRoot } from 'react-dom/client';

const App = () => {
  return (
    <div style={{
      backgroundColor: '#0d1117',
      color: '#c9d1d9',
      height: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'sans-serif',
      padding: '20px',
      textAlign: 'center'
    }}>
      <h1 style={{ color: '#58a6ff' }}>ProHost Uz - PHP Tizimi Tayyor</h1>
      <p>Ushbu loyiha <strong>PHP + MySQL</strong> da yozilgan.</p>
      <p>Brauzerda to'g'ridan-to'g'ri ishlash uchun fayllarni (index.php, dashboard.php va h.k.) lokal serverga (XAMPP/OpenServer) joylashtiring.</p>
      <p>Barcha kod fayllari generatsiya qilindi.</p>
      <div style={{ marginTop: '20px', textAlign: 'left', background: '#161b22', padding: '20px', borderRadius: '8px', border: '1px solid #30363d' }}>
        <h3 style={{ borderBottom: '1px solid #30363d', paddingBottom: '10px' }}>O'rnatish bo'yicha qo'llanma:</h3>
        <ol style={{ lineHeight: '1.8' }}>
          <li><strong>setup.sql</strong> faylini MySQL ma'lumotlar bazasiga import qiling.</li>
          <li><strong>includes/db.php</strong> faylida baza sozlamalarini to'g'rilang.</li>
          <li>Admin login: <strong>admin</strong> / Parol: <strong>Admin2026!</strong></li>
        </ol>
      </div>
    </div>
  );
};

const container = document.getElementById('root');
const root = createRoot(container!);
root.render(<App />);
