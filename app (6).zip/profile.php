
<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';
check_auth();

$user_id = $_SESSION['user_id'];

// Change Password
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $current = $_POST['current_password'];
    $new = $_POST['new_password'];
    
    $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $hash = $stmt->fetchColumn();
    
    if (password_verify($current, $hash)) {
        if (strlen($new) >= 6) {
            $new_hash = password_hash($new, PASSWORD_BCRYPT);
            $pdo->prepare("UPDATE users SET password = ? WHERE id = ?")->execute([$new_hash, $user_id]);
            set_flash('success', 'Parol o\'zgartirildi');
        } else {
            set_flash('error', 'Yangi parol kamida 6 belgili bo\'lishi kerak');
        }
    } else {
        set_flash('error', 'Joriy parol noto\'g\'ri');
    }
    redirect('profile.php');
}

// Get Logs
$stmt = $pdo->prepare("SELECT * FROM logs WHERE user_id = ? ORDER BY created_at DESC LIMIT 20");
$stmt->execute([$user_id]);
$logs = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <title>Sozlamalar - ProHost Uz</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <?php display_flash(); ?>
    <div class="dashboard-layout">
        <aside class="sidebar">
            <ul class="sidebar-menu">
                <li><a href="dashboard.php">🏠 Asosiy oyna</a></li>
                <li><a href="buy_hosting.php">🛍️ Hosting sotib olish</a></li>
                <li><a href="payment.php">💳 Balansni to'ldirish</a></li>
                <li><a href="support.php">🎫 Qo'llab-quvvatlash</a></li>
                <li><a href="profile.php" class="active">👤 Sozlamalar</a></li>
            </ul>
        </aside>

        <main class="main-content">
            <h2>Profil Sozlamalari</h2>
            
            <div class="d-flex" style="gap:20px; align-items:start; flex-wrap:wrap">
                <div class="card" style="flex:1; min-width:300px">
                    <div class="card-header">Xavfsizlik</div>
                    <form method="POST">
                        <input type="hidden" name="csrf_token" value="<?= generate_csrf() ?>">
                        <div class="form-group">
                            <label class="form-label">Joriy parol</label>
                            <input type="password" name="current_password" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Yangi parol</label>
                            <input type="password" name="new_password" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Parolni yangilash</button>
                    </form>
                </div>

                <div class="card" style="flex:1; min-width:300px">
                    <div class="card-header">Kirish tarixi (Loglar)</div>
                    <div class="table-responsive">
                        <table class="table">
                            <thead><tr><th>Vaqt</th><th>Harakat</th><th>IP</th></tr></thead>
                            <tbody>
                                <?php foreach($logs as $log): ?>
                                <tr>
                                    <td><?= date('d.m H:i', strtotime($log['created_at'])) ?></td>
                                    <td><?= clean($log['action']) ?></td>
                                    <td><?= $log['ip_address'] ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
    <script src="assets/script.js"></script>
</body>
</html>
