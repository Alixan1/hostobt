"""
VPS Manager Bot — Telegram orqali serverni boshqarish
Funksiyalar:
  📁 Fayl yuklash / yuklab olish / ko'rish / o'chirish
  💻 Terminal — buyruqlarni bajarish
"""

import os
import sys
import asyncio
import subprocess
import logging
import html
import signal
from datetime import datetime
from pathlib import Path

from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup,
    InputFile, BotCommand
)
from telegram.ext import (
    Application, CommandHandler, MessageHandler,
    CallbackQueryHandler, filters, ContextTypes
)
from telegram.constants import ParseMode, ChatAction

# ═══════════════════════════════════════════════════════
#  CONFIGURATION
# ═══════════════════════════════════════════════════════
BOT_TOKEN = "8470439773:AAFoPukzg1-o3zvEtSMhE6XGaQvmnxX9tLw"
ADMIN_IDS = [6489892269]

# Limits
MAX_FILE_SIZE = 50 * 1024 * 1024       # 50 MB (Telegram limit)
MAX_OUTPUT_LENGTH = 4000                # Max terminal output chars
COMMAND_TIMEOUT = 60                    # Command timeout seconds
DEFAULT_DIR = os.path.expanduser("~")   # Starting directory

# ═══════════════════════════════════════════════════════
#  LOGGING
# ═══════════════════════════════════════════════════════
logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════
#  STATE
# ═══════════════════════════════════════════════════════
user_state = {}  # {user_id: {"mode": ..., "cwd": ..., "history": [...]}}


def get_state(user_id: int) -> dict:
    if user_id not in user_state:
        user_state[user_id] = {
            "mode": None,
            "cwd": DEFAULT_DIR,
            "history": [],
            "file_path": None,
        }
    return user_state[user_id]


# ═══════════════════════════════════════════════════════
#  AUTH
# ═══════════════════════════════════════════════════════
def is_admin(user_id: int) -> bool:
    if not ADMIN_IDS:
        return True  # Agar ADMIN_IDS bo'sh bo'lsa, hammaga ruxsat
    return user_id in ADMIN_IDS


def admin_only(func):
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
        user_id = update.effective_user.id
        if not is_admin(user_id):
            if update.callback_query:
                await update.callback_query.answer("⛔ Sizga ruxsat yo'q!", show_alert=True)
            else:
                await update.effective_message.reply_text("⛔ <b>Sizga ruxsat yo'q!</b>", parse_mode=ParseMode.HTML)
            return
        return await func(update, context)
    return wrapper


# ═══════════════════════════════════════════════════════
#  KEYBOARDS
# ═══════════════════════════════════════════════════════
def main_menu_kb():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📁 Fayl menejeri", callback_data="menu_files"),
            InlineKeyboardButton("💻 Terminal", callback_data="menu_terminal"),
        ],
        [
            InlineKeyboardButton("📊 Server info", callback_data="menu_sysinfo"),
            InlineKeyboardButton("❓ Yordam", callback_data="menu_help"),
        ],
    ])


def file_menu_kb():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📂 Papkalarni ko'rish", callback_data="file_browse"),
            InlineKeyboardButton("📤 Fayl yuklash", callback_data="file_upload"),
        ],
        [
            InlineKeyboardButton("📥 Fayl yuklab olish", callback_data="file_download"),
            InlineKeyboardButton("🗑 Fayl o'chirish", callback_data="file_delete"),
        ],
        [InlineKeyboardButton("🔙 Orqaga", callback_data="back_main")],
    ])


def terminal_menu_kb():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📜 Tarix", callback_data="term_history"),
            InlineKeyboardButton("📂 CWD o'zgartirish", callback_data="term_cd"),
        ],
        [InlineKeyboardButton("🔙 Orqaga", callback_data="back_main")],
    ])


def back_kb(cb_data="back_main"):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔙 Orqaga", callback_data=cb_data)],
    ])


# ═══════════════════════════════════════════════════════
#  /start
# ═══════════════════════════════════════════════════════
@admin_only
async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    state = get_state(user.id)
    state["mode"] = None
    text = (
        f"👋 <b>Salom, {html.escape(user.first_name)}!</b>\n\n"
        f"🖥 <b>VPS Manager Bot</b>\n"
        f"Bu bot orqali serveringizni to'liq boshqarishingiz mumkin.\n\n"
        f"⬇️ Quyidagi tugmalardan birini tanlang:"
    )
    if update.callback_query:
        await update.callback_query.edit_message_text(text, reply_markup=main_menu_kb(), parse_mode=ParseMode.HTML)
    else:
        await update.message.reply_text(text, reply_markup=main_menu_kb(), parse_mode=ParseMode.HTML)


# ═══════════════════════════════════════════════════════
#  CALLBACK ROUTER
# ═══════════════════════════════════════════════════════
@admin_only
async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data
    user_id = update.effective_user.id
    state = get_state(user_id)

    # ── Main menu ──
    if data == "back_main":
        state["mode"] = None
        return await cmd_start(update, context)

    # ── File menu ──
    elif data == "menu_files":
        state["mode"] = None
        text = (
            "📁 <b>Fayl menejeri</b>\n\n"
            f"📂 Joriy papka: <code>{html.escape(state['cwd'])}</code>\n\n"
            "Quyidagi funksiyalardan birini tanlang:"
        )
        await query.edit_message_text(text, reply_markup=file_menu_kb(), parse_mode=ParseMode.HTML)

    elif data == "file_browse":
        await browse_directory(query, state, state["cwd"])

    elif data.startswith("browse:"):
        path = data[7:]
        if os.path.isdir(path):
            state["cwd"] = path
            await browse_directory(query, state, path)
        elif os.path.isfile(path):
            await send_file(query, path)

    elif data == "file_upload":
        state["mode"] = "upload"
        text = (
            "📤 <b>Fayl yuklash</b>\n\n"
            f"📂 Yuklanadigan papka: <code>{html.escape(state['cwd'])}</code>\n\n"
            "📎 Faylni yuboring (document sifatida).\n"
            "Bekor qilish uchun /cancel yozing."
        )
        await query.edit_message_text(text, reply_markup=back_kb("menu_files"), parse_mode=ParseMode.HTML)

    elif data == "file_download":
        state["mode"] = "download"
        text = (
            "📥 <b>Fayl yuklab olish</b>\n\n"
            f"📂 Joriy papka: <code>{html.escape(state['cwd'])}</code>\n\n"
            "📝 Fayl yo'lini yozing (to'liq yoki nisbiy):\n"
            "<i>Masalan:</i> <code>config.py</code> yoki <code>/etc/hosts</code>\n\n"
            "Bekor qilish uchun /cancel yozing."
        )
        await query.edit_message_text(text, reply_markup=back_kb("menu_files"), parse_mode=ParseMode.HTML)

    elif data == "file_delete":
        state["mode"] = "delete"
        text = (
            "🗑 <b>Fayl o'chirish</b>\n\n"
            f"📂 Joriy papka: <code>{html.escape(state['cwd'])}</code>\n\n"
            "📝 O'chiriladigan fayl yo'lini yozing:\n"
            "<i>Masalan:</i> <code>old_file.txt</code>\n\n"
            "⚠️ <b>Ehtiyot bo'ling — bu qaytarib bo'lmaydi!</b>\n"
            "Bekor qilish uchun /cancel yozing."
        )
        await query.edit_message_text(text, reply_markup=back_kb("menu_files"), parse_mode=ParseMode.HTML)

    # ── Terminal menu ──
    elif data == "menu_terminal":
        state["mode"] = "terminal"
        text = (
            "💻 <b>Terminal</b>\n\n"
            f"📂 CWD: <code>{html.escape(state['cwd'])}</code>\n\n"
            "⌨️ Buyruq yozing va yuborning.\n"
            "<i>Masalan:</i> <code>ls -la</code>, <code>df -h</code>, <code>htop</code>\n\n"
            "Bekor qilish uchun /cancel yozing."
        )
        await query.edit_message_text(text, reply_markup=terminal_menu_kb(), parse_mode=ParseMode.HTML)

    elif data == "term_history":
        history = state.get("history", [])
        if not history:
            text = "📜 <b>Tarix bo'sh</b>\n\nHali hech qanday buyruq bajarilmagan."
        else:
            lines = []
            for i, item in enumerate(history[-15:], 1):
                cmd = html.escape(item["cmd"][:60])
                time_str = item["time"]
                status = "✅" if item["code"] == 0 else "❌"
                lines.append(f"{i}. {status} <code>{cmd}</code> — {time_str}")
            text = "📜 <b>Oxirgi buyruqlar:</b>\n\n" + "\n".join(lines)
        await query.edit_message_text(text, reply_markup=terminal_menu_kb(), parse_mode=ParseMode.HTML)

    elif data == "term_cd":
        state["mode"] = "cd"
        text = (
            "📂 <b>CWD o'zgartirish</b>\n\n"
            f"Hozirgi: <code>{html.escape(state['cwd'])}</code>\n\n"
            "Yangi papka yo'lini yozing:\n"
            "<i>Masalan:</i> <code>/home/user/project</code>"
        )
        await query.edit_message_text(text, reply_markup=terminal_menu_kb(), parse_mode=ParseMode.HTML)

    # ── System info ──
    elif data == "menu_sysinfo":
        await show_sysinfo(query)

    # ── Help ──
    elif data == "menu_help":
        text = (
            "❓ <b>Yordam</b>\n\n"
            "🔹 <b>/start</b> — Botni boshlash\n"
            "🔹 <b>/cancel</b> — Joriy amalni bekor qilish\n\n"
            "📁 <b>Fayl menejeri:</b>\n"
            "  • Papkalarni ko'rish va navigatsiya\n"
            "  • Fayllarni yuklash (50MB gacha)\n"
            "  • Fayllarni yuklab olish\n"
            "  • Fayllarni o'chirish\n\n"
            "💻 <b>Terminal:</b>\n"
            "  • Shell buyruqlarini bajarish\n"
            "  • Buyruq tarixini ko'rish\n"
            "  • Ishchi papkani o'zgartirish\n\n"
            "📊 <b>Server info:</b>\n"
            "  • CPU, RAM, Disk holati\n"
            "  • Uptime va OS ma'lumotlari"
        )
        await query.edit_message_text(text, reply_markup=back_kb(), parse_mode=ParseMode.HTML)


# ═══════════════════════════════════════════════════════
#  FILE BROWSER
# ═══════════════════════════════════════════════════════
async def browse_directory(query, state: dict, path: str):
    try:
        items = sorted(os.listdir(path))
    except PermissionError:
        await query.edit_message_text(
            f"⛔ <b>Ruxsat yo'q:</b> <code>{html.escape(path)}</code>",
            reply_markup=back_kb("menu_files"), parse_mode=ParseMode.HTML
        )
        return
    except FileNotFoundError:
        await query.edit_message_text(
            f"❌ <b>Topilmadi:</b> <code>{html.escape(path)}</code>",
            reply_markup=back_kb("menu_files"), parse_mode=ParseMode.HTML
        )
        return

    buttons = []

    # Parent directory
    parent = str(Path(path).parent)
    if parent != path:
        buttons.append([InlineKeyboardButton("📁 .. (orqaga)", callback_data=f"browse:{parent}")])

    # Items (max 30 to avoid Telegram limits)
    dirs_list = []
    files_list = []
    for item in items:
        if item.startswith("."):
            continue
        full = os.path.join(path, item)
        if os.path.isdir(full):
            dirs_list.append(item)
        else:
            files_list.append(item)

    for d in dirs_list[:15]:
        full = os.path.join(path, d)
        buttons.append([InlineKeyboardButton(f"📂 {d}", callback_data=f"browse:{full}")])

    for f in files_list[:15]:
        full = os.path.join(path, f)
        size = format_size(os.path.getsize(full))
        buttons.append([InlineKeyboardButton(f"📄 {f} ({size})", callback_data=f"browse:{full}")])

    buttons.append([InlineKeyboardButton("🔙 Fayl menyu", callback_data="menu_files")])

    total = len(dirs_list) + len(files_list)
    text = (
        f"📂 <b>{html.escape(path)}</b>\n\n"
        f"📁 {len(dirs_list)} papka  |  📄 {len(files_list)} fayl\n"
    )
    if total > 30:
        text += f"<i>(Faqat birinchi 30 tasi ko'rsatilmoqda)</i>"

    await query.edit_message_text(
        text, reply_markup=InlineKeyboardMarkup(buttons), parse_mode=ParseMode.HTML
    )


async def send_file(query, file_path: str):
    try:
        size = os.path.getsize(file_path)
        if size > MAX_FILE_SIZE:
            await query.edit_message_text(
                f"❌ <b>Fayl juda katta!</b>\n"
                f"📄 {html.escape(file_path)}\n"
                f"📊 Hajmi: {format_size(size)} (max: {format_size(MAX_FILE_SIZE)})",
                reply_markup=back_kb("menu_files"), parse_mode=ParseMode.HTML
            )
            return

        await query.message.chat.send_action(ChatAction.UPLOAD_DOCUMENT)
        with open(file_path, "rb") as f:
            await query.message.chat.send_document(
                document=InputFile(f, filename=os.path.basename(file_path)),
                caption=f"📄 <code>{html.escape(file_path)}</code>\n📊 {format_size(size)}",
                parse_mode=ParseMode.HTML
            )
        await query.edit_message_text(
            f"✅ <b>Fayl yuborildi!</b>\n📄 <code>{html.escape(file_path)}</code>",
            reply_markup=back_kb("menu_files"), parse_mode=ParseMode.HTML
        )
    except Exception as e:
        await query.edit_message_text(
            f"❌ <b>Xatolik:</b> <code>{html.escape(str(e))}</code>",
            reply_markup=back_kb("menu_files"), parse_mode=ParseMode.HTML
        )


# ═══════════════════════════════════════════════════════
#  MESSAGE HANDLER (terminal, upload, download, delete)
# ═══════════════════════════════════════════════════════
@admin_only
async def message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    state = get_state(user_id)
    mode = state.get("mode")
    msg = update.message

    if not mode:
        return

    # ── Terminal mode ──
    if mode == "terminal":
        command = msg.text.strip()
        if not command:
            return

        await msg.chat.send_action(ChatAction.TYPING)
        result = await run_command(command, state["cwd"])

        state["history"].append({
            "cmd": command,
            "code": result["code"],
            "time": datetime.now().strftime("%H:%M:%S"),
        })

        # Keep history limited
        if len(state["history"]) > 50:
            state["history"] = state["history"][-50:]

        output = result["output"].strip()
        if not output:
            output = "(bo'sh javob)"

        # Truncate if too long
        if len(output) > MAX_OUTPUT_LENGTH:
            output = output[:MAX_OUTPUT_LENGTH] + "\n\n... (qisqartirildi)"

        status = "✅" if result["code"] == 0 else f"❌ (kod: {result['code']})"

        text = (
            f"💻 <b>Buyruq:</b> <code>{html.escape(command[:100])}</code>\n"
            f"📂 <b>CWD:</b> <code>{html.escape(state['cwd'])}</code>\n"
            f"📊 <b>Status:</b> {status}\n"
            f"⏱ <b>Vaqt:</b> {result['elapsed']:.1f}s\n\n"
            f"<pre>{html.escape(output)}</pre>"
        )
        await msg.reply_text(text, reply_markup=terminal_menu_kb(), parse_mode=ParseMode.HTML)

    # ── CD mode ──
    elif mode == "cd":
        new_dir = msg.text.strip()
        if not os.path.isabs(new_dir):
            new_dir = os.path.join(state["cwd"], new_dir)
        new_dir = os.path.abspath(new_dir)

        if os.path.isdir(new_dir):
            state["cwd"] = new_dir
            state["mode"] = "terminal"
            text = (
                f"✅ <b>CWD o'zgartirildi!</b>\n"
                f"📂 <code>{html.escape(new_dir)}</code>\n\n"
                "⌨️ Buyruq yozing..."
            )
        else:
            text = f"❌ <b>Papka topilmadi:</b> <code>{html.escape(new_dir)}</code>\n\nQaytadan yozing:"
        await msg.reply_text(text, reply_markup=terminal_menu_kb(), parse_mode=ParseMode.HTML)

    # ── Download mode ──
    elif mode == "download":
        file_path = msg.text.strip()
        if not os.path.isabs(file_path):
            file_path = os.path.join(state["cwd"], file_path)
        file_path = os.path.abspath(file_path)

        if not os.path.isfile(file_path):
            await msg.reply_text(
                f"❌ <b>Fayl topilmadi:</b> <code>{html.escape(file_path)}</code>",
                reply_markup=back_kb("menu_files"), parse_mode=ParseMode.HTML
            )
            return

        size = os.path.getsize(file_path)
        if size > MAX_FILE_SIZE:
            await msg.reply_text(
                f"❌ <b>Fayl juda katta!</b> ({format_size(size)})",
                reply_markup=back_kb("menu_files"), parse_mode=ParseMode.HTML
            )
            return

        await msg.chat.send_action(ChatAction.UPLOAD_DOCUMENT)
        try:
            with open(file_path, "rb") as f:
                await msg.reply_document(
                    document=InputFile(f, filename=os.path.basename(file_path)),
                    caption=f"📄 <code>{html.escape(file_path)}</code>\n📊 {format_size(size)}",
                    parse_mode=ParseMode.HTML
                )
            state["mode"] = None
        except Exception as e:
            await msg.reply_text(
                f"❌ <b>Xatolik:</b> <code>{html.escape(str(e))}</code>",
                reply_markup=back_kb("menu_files"), parse_mode=ParseMode.HTML
            )

    # ── Delete mode ──
    elif mode == "delete":
        file_path = msg.text.strip()
        if not os.path.isabs(file_path):
            file_path = os.path.join(state["cwd"], file_path)
        file_path = os.path.abspath(file_path)

        if not os.path.exists(file_path):
            await msg.reply_text(
                f"❌ <b>Topilmadi:</b> <code>{html.escape(file_path)}</code>",
                reply_markup=back_kb("menu_files"), parse_mode=ParseMode.HTML
            )
            return

        try:
            if os.path.isdir(file_path):
                import shutil
                shutil.rmtree(file_path)
                emoji = "📂"
            else:
                os.remove(file_path)
                emoji = "📄"

            state["mode"] = None
            await msg.reply_text(
                f"✅ {emoji} <b>O'chirildi:</b> <code>{html.escape(file_path)}</code>",
                reply_markup=file_menu_kb(), parse_mode=ParseMode.HTML
            )
        except Exception as e:
            await msg.reply_text(
                f"❌ <b>Xatolik:</b> <code>{html.escape(str(e))}</code>",
                reply_markup=back_kb("menu_files"), parse_mode=ParseMode.HTML
            )


# ═══════════════════════════════════════════════════════
#  FILE UPLOAD HANDLER
# ═══════════════════════════════════════════════════════
@admin_only
async def document_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    state = get_state(user_id)
    msg = update.message
    doc = msg.document

    if state.get("mode") != "upload":
        # Auto-upload if document sent
        state["mode"] = "upload"

    if not doc:
        await msg.reply_text("❌ Iltimos, faylni <b>document</b> sifatida yuboring.", parse_mode=ParseMode.HTML)
        return

    if doc.file_size > MAX_FILE_SIZE:
        await msg.reply_text(
            f"❌ <b>Fayl juda katta!</b> ({format_size(doc.file_size)})\nMax: {format_size(MAX_FILE_SIZE)}",
            parse_mode=ParseMode.HTML
        )
        return

    save_dir = state["cwd"]
    save_path = os.path.join(save_dir, doc.file_name)

    await msg.chat.send_action(ChatAction.TYPING)
    status_msg = await msg.reply_text(
        f"⏳ <b>Yuklanmoqda...</b>\n📄 {html.escape(doc.file_name)}\n📊 {format_size(doc.file_size)}",
        parse_mode=ParseMode.HTML
    )

    try:
        os.makedirs(save_dir, exist_ok=True)
        file = await doc.get_file()
        await file.download_to_drive(save_path)

        state["mode"] = None
        await status_msg.edit_text(
            f"✅ <b>Fayl saqlandi!</b>\n\n"
            f"📄 <b>Nomi:</b> {html.escape(doc.file_name)}\n"
            f"📊 <b>Hajmi:</b> {format_size(doc.file_size)}\n"
            f"📂 <b>Yo'li:</b> <code>{html.escape(save_path)}</code>",
            reply_markup=file_menu_kb(), parse_mode=ParseMode.HTML
        )
        logger.info(f"File uploaded: {save_path} by user {user_id}")
    except Exception as e:
        await status_msg.edit_text(
            f"❌ <b>Saqlashda xatolik:</b>\n<code>{html.escape(str(e))}</code>",
            reply_markup=back_kb("menu_files"), parse_mode=ParseMode.HTML
        )


# ═══════════════════════════════════════════════════════
#  TERMINAL EXECUTOR
# ═══════════════════════════════════════════════════════
async def run_command(command: str, cwd: str) -> dict:
    import time
    start = time.time()
    try:
        proc = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
            cwd=cwd,
            env={**os.environ, "TERM": "dumb", "COLUMNS": "120"},
        )
        try:
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=COMMAND_TIMEOUT)
            output = stdout.decode("utf-8", errors="replace")
            code = proc.returncode
        except asyncio.TimeoutError:
            proc.kill()
            output = f"⏰ Buyruq {COMMAND_TIMEOUT} sekunddan oshdi va to'xtatildi!"
            code = -1
    except Exception as e:
        output = f"Xatolik: {str(e)}"
        code = -1

    elapsed = time.time() - start
    return {"output": output, "code": code, "elapsed": elapsed}


# ═══════════════════════════════════════════════════════
#  SYSTEM INFO
# ═══════════════════════════════════════════════════════
async def show_sysinfo(query):
    try:
        info_parts = []

        # OS
        result = await run_command("cat /etc/os-release 2>/dev/null | head -2 || echo 'N/A'", "/")
        os_info = result["output"].strip()
        for line in os_info.split("\n"):
            if line.startswith("PRETTY_NAME="):
                os_info = line.split("=", 1)[1].strip('"')
                break

        # Uptime
        result = await run_command("uptime -p 2>/dev/null || uptime", "/")
        uptime = result["output"].strip()

        # CPU
        result = await run_command("nproc 2>/dev/null || echo 'N/A'", "/")
        cpu_count = result["output"].strip()

        # RAM
        result = await run_command("free -h 2>/dev/null | grep Mem | awk '{print $3\"/\"$2}'", "/")
        ram = result["output"].strip() or "N/A"

        # Disk
        result = await run_command("df -h / | tail -1 | awk '{print $3\"/\"$2\" (\"$5\" used)\"}'", "/")
        disk = result["output"].strip() or "N/A"

        # Hostname
        result = await run_command("hostname", "/")
        hostname = result["output"].strip()

        text = (
            f"📊 <b>Server ma'lumotlari</b>\n\n"
            f"🖥 <b>Hostname:</b> <code>{html.escape(hostname)}</code>\n"
            f"🐧 <b>OS:</b> {html.escape(os_info)}\n"
            f"⏱ <b>Uptime:</b> {html.escape(uptime)}\n"
            f"🔧 <b>CPU:</b> {html.escape(cpu_count)} cores\n"
            f"💾 <b>RAM:</b> {html.escape(ram)}\n"
            f"💿 <b>Disk:</b> {html.escape(disk)}"
        )
    except Exception as e:
        text = f"❌ <b>Xatolik:</b> <code>{html.escape(str(e))}</code>"

    await query.edit_message_text(text, reply_markup=back_kb(), parse_mode=ParseMode.HTML)


# ═══════════════════════════════════════════════════════
#  /cancel
# ═══════════════════════════════════════════════════════
@admin_only
async def cmd_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    state = get_state(update.effective_user.id)
    state["mode"] = None
    await update.message.reply_text(
        "🚫 <b>Bekor qilindi.</b>",
        reply_markup=main_menu_kb(), parse_mode=ParseMode.HTML
    )


# ═══════════════════════════════════════════════════════
#  HELPERS
# ═══════════════════════════════════════════════════════
def format_size(size_bytes: int) -> str:
    for unit in ["B", "KB", "MB", "GB"]:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"


# ═══════════════════════════════════════════════════════
#  MAIN
# ═══════════════════════════════════════════════════════
def main():
    if BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        print("❌ BOT_TOKEN ni sozlang!")
        print("   export BOT_TOKEN='your_token_here'")
        print("   yoki kod ichida o'zgartiring.")
        sys.exit(1)

    app = Application.builder().token(BOT_TOKEN).build()

    # Commands
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("cancel", cmd_cancel))

    # Callbacks
    app.add_handler(CallbackQueryHandler(callback_handler))

    # Documents (file upload)
    app.add_handler(MessageHandler(filters.Document.ALL, document_handler))

    # Text messages (terminal, download, delete, cd)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, message_handler))

    logger.info("🚀 VPS Manager Bot ishga tushdi!")
    if ADMIN_IDS:
        logger.info(f"👤 Admin IDs: {ADMIN_IDS}")
    else:
        logger.info("⚠️  ADMIN_IDS sozlanmagan — barcha foydalanuvchilarga ruxsat berildi!")

    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
