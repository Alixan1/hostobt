import asyncio
import os
import shutil
import logging
from process_manager import process_manager

logger = logging.getLogger(__name__)

class Installer:
    def __init__(self):
        self.install_dir = "userbots_data"
        os.makedirs(self.install_dir, exist_ok=True)

    async def install_userbot(self, ub_name: str, port: int, bot_type: str = "hikka", session_data: dict = None) -> bool:
        logger.info(f"Starting local installation for {ub_name} ({bot_type})...")
        
        # 1. Prepare Paths
        user_dir = os.path.join(os.getcwd(), self.install_dir, ub_name)
        os.makedirs(user_dir, exist_ok=True)
        
        repo_url = "https://github.com/hikariatama/Hikka" if bot_type == "hikka" else "https://github.com/coddrago/Heroku"
        repo_dir_name = "Hikka" if bot_type == "hikka" else "Heroku"
        repo_path = os.path.join(user_dir, repo_dir_name)
        
        # 2. Clone Repository (if not exists)
        if not os.path.exists(repo_path):
            # Use depth 1 for faster clone
            cmd = f"git clone --depth 1 {repo_url} {repo_path}"
            logger.info(f"Cloning repo: {cmd}")
            proc = await asyncio.create_subprocess_shell(
                cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await proc.communicate()
            if proc.returncode != 0:
                logger.error(f"Git clone failed: {stderr.decode('utf-8', errors='replace')}")
                return False

        if session_data:
            try:
                if bot_type == "heroku":
                    env_content = (
                        f"API_ID={session_data.get('api_id')}\n"
                        f"API_HASH={session_data.get('api_hash')}\n"
                        f"STRING_SESSION={session_data.get('session_string')}\n"
                    )
                    with open(os.path.join(repo_path, "config.env"), "w") as f:
                        f.write(env_content)
                    logger.info("Created config.env for Heroku bot")
                
                elif bot_type == "hikka":
                    # Hikka uses config.json or via args?
                    # Trying to pre-fill config.json
                    import json
                    hikka_config = {
                        "api_id": int(session_data.get('api_id')), 
                        "api_hash": session_data.get('api_hash'),
                        # "session": session_data.get('session_string') # Hikka might not accept string session directly here
                    }
                    # Ensure data directory exists
                    # Hikka stores data in hikka_session.session usually
                    # We can't easily inject session without proper conversion.
                    # But we can save api_id/hash at least.
                    pass 
            except Exception as e:
                logger.error(f"Failed to write config: {e}")

        # 3. Create Virtual Environment
        python_exe = await process_manager.create_venv(ub_name)
        
        # 3.1 Upgrade pip and install critical wheels
        await process_manager.run_pip(python_exe, ["install", "--upgrade", "pip", "setuptools", "wheel"])
        await process_manager.run_pip(python_exe, ["install", "aiohttp", "cryptg", "--upgrade", "--prefer-binary"])
        
        # 4. Install Requirements
        req_file = os.path.join(repo_path, "requirements.txt")
        if os.path.exists(req_file):
            problematic_packages = ["heroku-tl-new", "hikka", "telethon"]
            manual_install = []
            
            # Sanitize requirements
            try:
                with open(req_file, 'r', encoding='utf-8', errors='ignore') as f:
                    lines = f.readlines()
                
                safe_lines = []
                for line in lines:
                    pkg = line.strip().lower()
                    if not pkg or pkg.startswith("#"):
                        safe_lines.append(line)
                        continue
                        
                    # Remove tgcrypto/uvloop/aiohttp/cryptg always (we pre-installed or use surrogates)
                    if "tgcrypto" in pkg or "uvloop" in pkg or "aiohttp" in pkg or "cryptg" in pkg:
                        continue
                        
                    # Check for problematic packages
                    is_problematic = False
                    for p in problematic_packages:
                        if p in pkg:
                            manual_install.append(line.strip()) # Keep original version string
                            is_problematic = True
                            break
                    
                    if not is_problematic:
                        safe_lines.append(line)
                
                # Write safe requirements
                with open(req_file, 'w', encoding='utf-8') as f:
                    f.writelines(safe_lines)
                    
            except Exception as e:
                logger.error(f"Error sanitizing requirements: {e}")

            # Install Safe Deps
            if not await process_manager.install_requirements(python_exe, req_file):
                logger.error("Failed to install base requirements")
                return False
                
            # Install Problematic Packages with --no-deps
            for pkg in manual_install:
                logger.info(f"Installing {pkg} with --no-deps...")
                if not await process_manager.run_pip(python_exe, ["install", pkg, "--no-deps"]):
                    logger.error(f"Failed to install {pkg}")
                    return False
                    
            # Install pyaes and rsa (fallback for tgcrypto and required by herokutl)
            await process_manager.run_pip(python_exe, ["install", "pyaes", "rsa"])
        
        # 5. Start Process
        cwd = repo_path
        if bot_type == "hikka":
            # Hikka needs to run as a module
            # cmd: python -m hikka --port {port}
            # Note: Hikka might need data directory argument to store session in user_dir
            # But normally it stores in cwd. existing user_dir structure is userbots_data/ub_name/Hikka
            args = ["-m", "hikka", "--port", str(port)]
            script = "" # We rely on -m module execution so script path is empty or we use -m logic in start_process?
            # My start_process expects script_path. Let's adjust it to support module execution easily 
            # or just pass "-m" as script_path? No, python_exe is arg 0.
            # Let's clean up start_process usage.
            # If I pass script_path as "-m", it works: python -m hikka
            success = await process_manager.start_process(ub_name, python_exe, "-m", ["hikka", "--port", str(port)], cwd=cwd)
            
        else: # Heroku
            # Heroku wrapper: python -m heroku https://...
            args = ["heroku", "https://github.com/hikariatama/hikka.git"]
            success = await process_manager.start_process(ub_name, python_exe, "-m", args, cwd=cwd)
            
        if success:
            logger.info(f"Process {ub_name} started.")
            return True
        else:
            return False

    async def delete_userbot(self, ub_name: str):
        logger.info(f"Deleting userbot {ub_name}...")
        
        # 1. Stop Process
        await process_manager.stop_process(ub_name)
        
        # 2. Delete Data Directory
        user_data_dir = os.path.join(os.getcwd(), self.install_dir, ub_name)
        if os.path.exists(user_data_dir):
            try:
                # Use robust removal for Windows
                # Sometimes files are locked.
                await asyncio.sleep(1) 
                shutil.rmtree(user_data_dir, ignore_errors=True)
                logger.info(f"Deleted data directory for {ub_name}")
            except Exception as e:
                logger.error(f"Error deleting dir: {e}")

installer = Installer()
