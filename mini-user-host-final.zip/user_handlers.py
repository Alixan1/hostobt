"""
ARCAI HOST — Professional User Handlers
Features: Server plans, Hikka/Heroku, API/QR login, auto payment, animated emoji
"""
from aiogram import Router, F, types
from aiogram.filters import Command, CommandStart, CommandObject
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, FSInputFile
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
import database as db
from config_manager import config
from locales import get_text, get_sticker, STICKERS
from bot_installer import installer
from process_manager import process_manager
from backup_manager import backup_manager
import asyncio
import os
import logging
from telethon import TelegramClient
from telethon.sessions import StringSession
from telethon.errors import SessionPasswordNeededError, PhoneCodeInvalidError, PhoneCodeExpiredError

logger = logging.getLogger(__name__)

router = Router()

FORCE_SUB_CHANNEL = config.FORCE_SUB_CHANNEL
BANNER_PATH = os.path.join(os.path.dirname(__file__), "images", "banner.png")


class UserStates(StatesGroup):
    choosing_plan = State()
    choosing_type = State()
    choosing_login = State()
    # API Login
    waiting_api_id = State()
    waiting_api_hash = State()
    waiting_phone = State()
    waiting_code = State()
    waiting_2fa = State()
    # QR Code
    waiting_qr_scan = State()
    # Delete
    waiting_delete_confirm = State()
    waiting_console_input = State()


# ============== MIDDLEWARE: BAN CHECK ==============

@router.message.middleware()
async def ban_check_middleware(handler, event: Message, data):
    if event.from_user:
        if await db.is_user_banned(event.from_user.id):
            return
    return await handler(event, data)


@router.callback_query.middleware()
async def ban_check_callback_middleware(handler, event: CallbackQuery, data):
    if event.from_user:
        if await db.is_user_banned(event.from_user.id):
            await event.answer("🚫 Siz bloklangansiz!", show_alert=True)
            return
    return await handler(event, data)


# ============== FORCE SUBSCRIPTION ==============

async def check_subscription(bot, user_id: int) -> bool:
    try:
        member = await bot.get_chat_member(f"@{FORCE_SUB_CHANNEL}", user_id)
        return member.status in ["creator", "administrator", "member"]
    except Exception:
        return True  # If check fails, allow access


async def show_subscription_required(message: Message, lang: str = "uz"):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"📢 @{FORCE_SUB_CHANNEL}", url=f"https://t.me/{FORCE_SUB_CHANNEL}")],
        [InlineKeyboardButton(text=get_text("btn_sub_check", lang), callback_data="check_sub")]
    ])
    await message.answer(get_text("sub_required", lang, channel=FORCE_SUB_CHANNEL), reply_markup=kb)


# ============== MAIN MENU ==============

def get_main_keyboard(lang: str = "uz") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text=get_text("btn_create", lang), callback_data="create_new"),
            InlineKeyboardButton(text=get_text("btn_my_bots", lang), callback_data="my_bots")
        ],
        [
            InlineKeyboardButton(text=get_text("btn_topup", lang), callback_data="topup"),
            InlineKeyboardButton(text=get_text("btn_stats", lang), callback_data="stats")
        ],
        [
            InlineKeyboardButton(text=get_text("btn_language", lang), callback_data="ask_lang"),
            InlineKeyboardButton(text=get_text("btn_manual", lang), callback_data="manual")
        ]
    ])


@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    await state.clear()
    user = message.from_user
    await db.add_user(user.id, user.username or "", user.full_name or "")
    lang = await db.get_user_language(user.id)

    # Check subscription
    if not await check_subscription(message.bot, user.id):
        await show_subscription_required(message, lang)
        return

    # Send animated welcome sticker
    try:
        sticker_id = get_sticker("welcome")
        if sticker_id:
            await message.answer_sticker(sticker_id)
    except Exception:
        pass  # Sticker might not exist yet

    # Send banner image with caption
    caption = get_text("start_caption", lang, name=user.full_name or user.first_name)
    kb = get_main_keyboard(lang)

    try:
        if os.path.exists(BANNER_PATH):
            photo = FSInputFile(BANNER_PATH)
            await message.answer_photo(photo=photo, caption=caption, reply_markup=kb)
        else:
            await message.answer(caption, reply_markup=kb)
    except Exception as e:
        logger.error(f"Error sending banner: {e}")
        await message.answer(caption, reply_markup=kb)


async def show_main_menu(call_or_msg, lang: str = "uz", name: str = ""):
    caption = get_text("start_caption", lang, name=name)
    kb = get_main_keyboard(lang)
    if isinstance(call_or_msg, CallbackQuery):
        try:
            await call_or_msg.message.edit_caption(caption=caption, reply_markup=kb)
        except:
            try:
                await call_or_msg.message.edit_text(caption, reply_markup=kb)
            except:
                await call_or_msg.message.answer(caption, reply_markup=kb)
    else:
        await call_or_msg.answer(caption, reply_markup=kb)


@router.callback_query(F.data == "check_sub")
async def cb_check_sub(call: CallbackQuery):
    lang = await db.get_user_language(call.from_user.id)
    if await check_subscription(call.bot, call.from_user.id):
        await call.answer("✅")
        await show_main_menu(call, lang, call.from_user.full_name)
    else:
        await call.answer(get_text("sub_not_found", lang), show_alert=True)


@router.callback_query(F.data == "main_menu")
async def cb_main_menu(call: CallbackQuery, state: FSMContext):
    await state.clear()
    lang = await db.get_user_language(call.from_user.id)
    await show_main_menu(call, lang, call.from_user.full_name)


# ============== LANGUAGE ==============

@router.callback_query(F.data == "ask_lang")
async def cb_ask_lang(call: CallbackQuery):
    lang = await db.get_user_language(call.from_user.id)
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🇺🇿 O'zbekcha", callback_data="set_lang_uz"),
            InlineKeyboardButton(text="🇷🇺 Русский", callback_data="set_lang_ru"),
        ],
        [InlineKeyboardButton(text="🇬🇧 English", callback_data="set_lang_en")],
        [InlineKeyboardButton(text=get_text("btn_back", lang), callback_data="main_menu")]
    ])
    try:
        await call.message.edit_caption(caption=get_text("choose_lang", lang), reply_markup=kb)
    except:
        await call.message.edit_text(get_text("choose_lang", lang), reply_markup=kb)


@router.callback_query(F.data.startswith("set_lang_"))
async def cb_set_lang(call: CallbackQuery):
    new_lang = call.data.split("_")[-1]
    await db.set_user_language(call.from_user.id, new_lang)
    await call.answer(get_text("lang_selected", new_lang))
    await show_main_menu(call, new_lang, call.from_user.full_name)


# ============== TOPUP / PAYMENT ==============

@router.callback_query(F.data == "topup")
async def cb_topup(call: CallbackQuery):
    lang = await db.get_user_language(call.from_user.id)
    balance = await db.get_user_balance(call.from_user.id)
    amount = config.GIFT_AMOUNT

    text = get_text("balance_text", lang, balance=balance) + "\n\n" + get_text("pay_instruction", lang, amount=amount)

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_text("btn_send_gift", lang, amount=amount), url=f"https://t.me/{config.GIFT_ACCOUNT}")],
        [InlineKeyboardButton(text=get_text("btn_back", lang), callback_data="main_menu")]
    ])
    try:
        await call.message.edit_caption(caption=text, reply_markup=kb)
    except:
        await call.message.edit_text(text, reply_markup=kb)


# ============== CREATE SERVER ==============

@router.callback_query(F.data == "create_new")
async def cb_create_new(call: CallbackQuery, state: FSMContext):
    lang = await db.get_user_language(call.from_user.id)

    # Show plan selection
    plans = config.SERVER_PLANS
    if not plans:
        await call.answer("⚠️ Planlar sozlanmagan!", show_alert=True)
        return

    buttons = []
    for i, plan in enumerate(plans):
        btn_text = get_text("btn_plan", lang, name=plan["name"], price=plan["price_stars"])
        buttons.append([InlineKeyboardButton(text=btn_text, callback_data=f"select_plan_{i}")])

    buttons.append([InlineKeyboardButton(text=get_text("btn_back", lang), callback_data="main_menu")])
    kb = InlineKeyboardMarkup(inline_keyboard=buttons)

    text = get_text("choose_plan", lang)
    # Show plan details
    for i, plan in enumerate(plans):
        user_count = await db.count_plan_users(i)
        
        text += "\n\n" + get_text("plan_card", lang,
                                   name=plan["name"], nvme=plan["nvme_gb"],
                                   ram=plan["ram_gb"], cpu=plan["cpu_count"],
                                   price=plan["price_stars"])
        text += f"\n👥 <b>Foydalanuvchilar:</b> {user_count} ta"

    try:
        await call.message.edit_caption(caption=text, reply_markup=kb)
    except:
        await call.message.edit_text(text, reply_markup=kb)

    await state.set_state(UserStates.choosing_plan)


@router.callback_query(F.data.startswith("select_plan_"))
async def cb_select_plan(call: CallbackQuery, state: FSMContext):
    lang = await db.get_user_language(call.from_user.id)
    plan_idx = int(call.data.split("_")[-1])
    plan = config.get_plan(plan_idx)

    if not plan:
        await call.answer("❌ Plan topilmadi!", show_alert=True)
        return

    # Admin gets free access for testing
    is_admin = call.from_user.id in config.ADMIN_IDS
    
    if not is_admin:
        # Check balance for non-admins
        balance = await db.get_user_balance(call.from_user.id)
        if balance < plan["price_stars"]:
            await call.answer(
                get_text("error_insufficient", lang, needed=plan["price_stars"], balance=balance),
                show_alert=True
            )
            return

    await state.update_data(plan_idx=plan_idx, plan=plan, is_admin=is_admin)
    await state.set_state(UserStates.choosing_type)

    # Show bot type selection
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_text("btn_hikka", lang), callback_data="type_hikka")],
        [InlineKeyboardButton(text=get_text("btn_heroku", lang), callback_data="type_heroku")],
        [InlineKeyboardButton(text=get_text("btn_back", lang), callback_data="create_new")]
    ])

    try:
        await call.message.edit_caption(caption=get_text("choose_type", lang), reply_markup=kb)
    except:
        await call.message.edit_text(get_text("choose_type", lang), reply_markup=kb)


@router.callback_query(F.data.startswith("type_"))
async def cb_select_type(call: CallbackQuery, state: FSMContext):
    lang = await db.get_user_language(call.from_user.id)
    bot_type = call.data.split("_")[-1]  # hikka or heroku
    await state.update_data(bot_type=bot_type)
    
    # Direct Installation (Console Login)
    data = await state.get_data()
    await start_installation(call.message, state, data, lang, is_callback=True)
    return
    await state.set_state(UserStates.choosing_login)

    # Show login method selection
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_text("btn_api_login", lang), callback_data="login_api")],
        [InlineKeyboardButton(text=get_text("btn_qr_login", lang), callback_data="login_qr")],
        [InlineKeyboardButton(text=get_text("btn_back", lang), callback_data="create_new")]
    ])

    try:
        await call.message.edit_caption(caption=get_text("choose_login", lang), reply_markup=kb)
    except:
        await call.message.edit_text(get_text("choose_login", lang), reply_markup=kb)


# ============== API LOGIN FLOW ==============

@router.callback_query(F.data == "login_api")
async def cb_login_api(call: CallbackQuery, state: FSMContext):
    lang = await db.get_user_language(call.from_user.id)
    await state.update_data(login_type="api")
    await state.set_state(UserStates.waiting_api_id)

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_text("btn_cancel", lang), callback_data="main_menu")]
    ])

    try:
        await call.message.edit_caption(caption=get_text("enter_api_id", lang), reply_markup=kb)
    except:
        await call.message.edit_text(get_text("enter_api_id", lang), reply_markup=kb)


@router.message(UserStates.waiting_api_id)
async def process_api_id(message: Message, state: FSMContext):
    lang = await db.get_user_language(message.from_user.id)
    try:
        api_id = int(message.text.strip())
        await state.update_data(user_api_id=api_id)
        await state.set_state(UserStates.waiting_api_hash)
        await message.answer(get_text("enter_api_hash", lang))
    except ValueError:
        await message.answer("❌ API ID faqat raqam bo'lishi kerak!")


@router.message(UserStates.waiting_api_hash)
async def process_api_hash(message: Message, state: FSMContext):
    lang = await db.get_user_language(message.from_user.id)
    api_hash = message.text.strip()
    if len(api_hash) < 10:
        await message.answer("❌ API Hash noto'g'ri!")
        return
    await state.update_data(user_api_hash=api_hash)
    await state.set_state(UserStates.waiting_phone)
    await message.answer(get_text("enter_phone", lang))


@router.message(UserStates.waiting_phone)
async def process_phone(message: Message, state: FSMContext):
    lang = await db.get_user_language(message.from_user.id)
    phone = message.text.strip().replace(" ", "")
    
    if not phone.startswith("+") or len(phone) < 10:
        await message.answer("❌ Telefon raqam noto'g'ri! (+998...)")
        return

    data = await state.get_data()
    api_id = data.get("user_api_id")
    api_hash = data.get("user_api_hash")

    status_msg = await message.answer("⏳ <b>Kod yuborilmoqda...</b>")

    try:
        # Create a new session for login
        client = TelegramClient(StringSession(), api_id, api_hash)
        await client.connect()
        
        if not await client.is_user_authorized():
            try:
                send_code = await client.send_code_request(phone)
            except Exception as e:
                await status_msg.edit_text(f"❌ Kod yuborishda xatolik: {e}")
                await client.disconnect()
                return
            
            # Save session state
            # vital: close client but keep session string if possible? No, StringSession holds it.
            # But we need to reuse the SAME session/client for sign_in.
            # Convert current session to string (it has auth key info likely empty but connection info)
            # wait, for send_code to sign_in we need the phone_code_hash which we get from send_code.
            # And we need to persistent session? 
            # StringSession saves auth key. 
            # We will save the string session now.
            
            session_str = StringSession.save(client.session)
            await client.disconnect()

            await state.update_data(
                phone=phone, 
                phone_code_hash=send_code.phone_code_hash,
                temp_session=session_str
            )
            await state.set_state(UserStates.waiting_code)
            
            await status_msg.edit_text(
                f"📨 <b>Kodni kiriting:</b>\n\n"
                f"Ushbu raqamga yuborilgan kodni yozing: {phone}"
            )
        else:
            await status_msg.edit_text("✅ Allaqachon tizimga kirgansiz!")
            await client.disconnect()

    except Exception as e:
        logger.error(f"Telethon error: {e}")
        await status_msg.edit_text(f"❌ Xatolik: {str(e)}")
        if 'client' in locals() and client.is_connected():
            await client.disconnect()


@router.message(UserStates.waiting_code)
async def process_code(message: Message, state: FSMContext):
    lang = await db.get_user_language(message.from_user.id)
    # Remove any non-digit characters (spaces, dots, etc.)
    raw_code = message.text.strip()
    code = "".join(filter(str.isdigit, raw_code))
    
    if not code:
        await message.answer("❌ Kod faqat raqamlardan iborat bo'lishi kerak!")
        return

    data = await state.get_data()
    api_id = data.get("user_api_id")
    api_hash = data.get("user_api_hash")
    phone = data.get("phone")
    phone_code_hash = data.get("phone_code_hash")
    session_str = data.get("temp_session")

    status_msg = await message.answer(f"⏳ <b>Kod tekshirilmoqda: {code}</b>...")

    client = None
    try:
        client = TelegramClient(StringSession(session_str), api_id, api_hash)
        await client.connect()
        
        try:
            # Force parameter to force code check if needed (rarely used in Telethon but ensure hash is correct)
            user = await client.sign_in(phone=phone, code=code, phone_code_hash=phone_code_hash)
            
            # Success!
            final_session = StringSession.save(client.session)
            await client.disconnect()
            
            await state.update_data(final_session=final_session)
            await status_msg.delete()
            
            # Ask for confirmation
            kb = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="🚀 O'rnatishni boshlash", callback_data="confirm_install")],
                [InlineKeyboardButton(text=get_text("btn_cancel", lang), callback_data="main_menu")]
            ])
            await message.answer("✅ <b>Muvaffaqiyatli kirildi!</b>\n\nUserbot o'rnatishga tayyor.", reply_markup=kb)

        except SessionPasswordNeededError:
            await status_msg.edit_text("🔒 <b>2FA Parolni kiriting:</b>")
            # Save updated session (it might verify the code but stop at password)
            temp_session = StringSession.save(client.session)
            await state.update_data(temp_session=temp_session)
            
            await state.set_state(UserStates.waiting_2fa)
            await client.disconnect()
            
        except PhoneCodeInvalidError:
            await status_msg.edit_text(f"❌ Kod noto'g'ri! ({code})")
            await client.disconnect()
            
        except PhoneCodeExpiredError:
            await status_msg.edit_text("❌ Kod eskirgan! Qaytadan urinib ko'ring.")
            await client.disconnect() # Maybe restart flow?

    except Exception as e:
        logger.error(f"Login error: {e}", exc_info=True)
        await status_msg.edit_text(f"❌ Xatolik: {str(e)}")
        if client and client.is_connected():
            await client.disconnect()


@router.message(UserStates.waiting_2fa)
async def process_2fa(message: Message, state: FSMContext):
    lang = await db.get_user_language(message.from_user.id)
    password = message.text.strip()
    
    data = await state.get_data()
    api_id = data.get("user_api_id")
    api_hash = data.get("user_api_hash")
    session_str = data.get("temp_session")

    status_msg = await message.answer("⏳ <b>Tekshirilmoqda...</b>")

    try:
        client = TelegramClient(StringSession(session_str), api_id, api_hash)
        await client.connect()
        
        await client.sign_in(password=password)
        
        # Success!
        final_session = StringSession.save(client.session)
        await client.disconnect()
        
        await state.update_data(final_session=final_session)
        await status_msg.delete()
        
        # Ask for confirmation
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🚀 O'rnatishni boshlash", callback_data="confirm_install")],
            [InlineKeyboardButton(text=get_text("btn_cancel", lang), callback_data="main_menu")]
        ])
        await message.answer("✅ <b>Muvaffaqiyatli kirildi!</b>\n\nUserbot o'rnatishga tayyor.", reply_markup=kb)

    except Exception as e:
        logger.error(f"2FA error: {e}")
        await status_msg.edit_text(f"❌ Xatolik: {str(e)}")
        if 'client' in locals() and client.is_connected():
            await client.disconnect()


# ============== QR CODE LOGIN ==============

@router.callback_query(F.data == "login_qr")
async def cb_login_qr(call: CallbackQuery, state: FSMContext):
    lang = await db.get_user_language(call.from_user.id)
    await state.update_data(login_type="qr")
    
    # Explain that QR login happens in Web UI
    text = (
        "📷 <b>QR Code orqali kirish</b>\n\n"
        "Userbot o'rnatilgandan so'ng, sizga <b>Web Panel</b> havolasi beriladi.\n"
        "O'sha yerdan QR kodni skanerlab kirishingiz mumkin.\n\n"
        "<i>Davom etish uchun 'O'rnatish' tugmasini bosing.</i>"
    )
    
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🚀 O'rnatishni boshlash", callback_data="confirm_install")],
        [InlineKeyboardButton(text=get_text("btn_back", lang), callback_data="create_new")]
    ])
    
    try:
        await call.message.edit_caption(caption=text, reply_markup=kb)
    except:
        await call.message.edit_text(text, reply_markup=kb)


@router.callback_query(F.data == "confirm_install")
async def cb_confirm_install(call: CallbackQuery, state: FSMContext):
    lang = await db.get_user_language(call.from_user.id)
    data = await state.get_data()
    await start_installation(call.message, state, data, lang, is_callback=True)


# ============== INSTALLATION ==============

async def start_installation(message: Message, state: FSMContext, data: dict, lang: str, is_callback: bool = False):
    """Start the actual userbot installation"""
    plan = data.get("plan", {})
    bot_type = data.get("bot_type", "hikka")
    login_type = data.get("login_type", "api")
    user_id = message.chat.id if is_callback else message.from_user.id

    # Deduct balance (admins get free access)
    price = plan.get("price_stars", 0)
    is_admin = data.get("is_admin", False)
    
    if not is_admin:
        balance = await db.get_user_balance(user_id)
        if balance < price:
            await message.answer(get_text("error_insufficient", lang, needed=price, balance=balance))
            await state.clear()
            return

    # Send animated loading sticker
    try:
        sticker_id = get_sticker("loading")
        if sticker_id:
            sticker_msg = await message.answer_sticker(sticker_id)
    except Exception:
        pass

    # Send progress message
    progress_msg = await message.answer(get_text("install_progress", lang))

    # Generate unique name and port
    import time
    ub_name = f"ub_{user_id}_{int(time.time()) % 10000}"
    port = await db.generate_random_port()

    try:
        # Deduct balance (skip for admins)
        if not is_admin:
            await db.update_balance(user_id, -price, "purchase",
                                    f"{bot_type.title()} server: {plan.get('name', 'Unknown')}")

        # Prepare session data if available (from API login)
        session_data = None
        if data.get("final_session"):
            try:
                session_data = {
                    "api_id": data.get("user_api_id"),
                    "api_hash": data.get("user_api_hash"),
                    "session_string": data.get("final_session")
                }
            except:
                pass

        # Install userbot with session data
        success = await installer.install_userbot(ub_name, port, bot_type, session_data)

        if success:
            # Record in database
            await db.add_userbot_record(
                tg_user_id=user_id,
                ub_username=ub_name,
                ub_type=bot_type,
                port=port,
                plan_id=data.get("plan_idx", 0),
                login_type=login_type,
                nvme_gb=plan.get("nvme_gb", 5),
                ram_gb=plan.get("ram_gb", 1),
                cpu_count=plan.get("cpu_count", 1)
            )
            await db.update_userbot_status(ub_name, "running")

            kb = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text=get_text("btn_my_bots", lang), callback_data="my_bots")],
                [InlineKeyboardButton(text=get_text("btn_back", lang), callback_data="main_menu")]
            ])

            success_text = get_text("install_success", lang,
                                     bot_type=bot_type.title(),
                                     plan=plan.get("name", ""),
                                     nvme=plan.get("nvme_gb", 5),
                                     ram=plan.get("ram_gb", 1),
                                     cpu=plan.get("cpu_count", 1))
            
            # Add Console instruction
            success_text += "\n\n🖥 <b>Server sozlash:</b>\n<i>Console tugmasini bosing va kerakli ma'lumotlarni (API ID, Phone) kiriting.</i>"
            
            # Send success sticker
            try:
                sticker_id = get_sticker("rocket")
                if sticker_id:
                    await message.answer_sticker(sticker_id)
            except Exception:
                pass
            
            await progress_msg.edit_text(success_text, reply_markup=kb)
        else:
            # Refund
            await db.update_balance(user_id, price, "refund", f"Failed: {bot_type}")
            await progress_msg.edit_text(get_text("install_fail", lang))

    except Exception as e:
        logger.error(f"Installation error: {e}")
        await db.update_balance(user_id, price, "refund", f"Error: {str(e)[:50]}")
        await progress_msg.edit_text(get_text("install_fail", lang))

    await state.clear()


# ============== MY BOTS ==============

@router.callback_query(F.data == "my_bots")
async def cb_my_bots(call: CallbackQuery):
    lang = await db.get_user_language(call.from_user.id)
    bots = await db.get_userbots_by_tg_id(call.from_user.id)

    if not bots:
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text=get_text("btn_create", lang), callback_data="create_new")],
            [InlineKeyboardButton(text=get_text("btn_back", lang), callback_data="main_menu")]
        ])
        try:
            await call.message.edit_caption(caption=get_text("no_bots", lang), reply_markup=kb)
        except:
            await call.message.edit_text(get_text("no_bots", lang), reply_markup=kb)
        return

    buttons = []
    for bot in bots:
        status_icon = "🟢" if bot.get("status") == "running" else "🔴"
        btn_text = f"{status_icon} {bot['ub_username']} ({bot['ub_type']})"
        buttons.append([InlineKeyboardButton(text=btn_text, callback_data=f"manage_{bot['ub_username']}")])

    buttons.append([InlineKeyboardButton(text=get_text("btn_back", lang), callback_data="main_menu")])
    kb = InlineKeyboardMarkup(inline_keyboard=buttons)

    try:
        await call.message.edit_caption(caption=get_text("my_bots_title", lang), reply_markup=kb)
    except:
        await call.message.edit_text(get_text("my_bots_title", lang), reply_markup=kb)


@router.callback_query(F.data.startswith("manage_"))
async def cb_manage_bot(call: CallbackQuery):
    lang = await db.get_user_language(call.from_user.id)
    ub_name = call.data[7:]  # Remove "manage_"
    bot_data = await db.get_userbot_data(ub_name)

    if not bot_data:
        await call.answer("❌ Server topilmadi!", show_alert=True)
        return

    # Check ownership
    if bot_data["tg_user_id"] != call.from_user.id:
        await call.answer("🚫 Bu sizning serveringiz emas!", show_alert=True)
        return

    status_text = "🟢 Ishlayapti" if bot_data.get("status") == "running" else "🔴 To'xtatilgan"
    login_text = "📱 API" if bot_data.get("login_type") == "api" else "📷 QR"

    text = get_text("bot_card", lang,
                     name=ub_name,
                     type=bot_data.get("ub_type", "hikka").title(),
                     nvme=bot_data.get("nvme_gb", 5),
                     ram=bot_data.get("ram_gb", 1),
                     cpu=bot_data.get("cpu_count", 1),
                     status=status_text,
                     login=login_text)

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text=get_text("btn_start", lang), callback_data=f"ctl_start_{ub_name}"),
            InlineKeyboardButton(text=get_text("btn_stop", lang), callback_data=f"ctl_stop_{ub_name}"),
        ],
        [
            InlineKeyboardButton(text=get_text("btn_restart", lang), callback_data=f"ctl_restart_{ub_name}"),
            InlineKeyboardButton(text=get_text("btn_logs", lang), callback_data=f"ctl_logs_{ub_name}"),
        ],
        [
            InlineKeyboardButton(text=get_text("btn_backup", lang), callback_data=f"ctl_backup_{ub_name}"),
            InlineKeyboardButton(text=get_text("btn_delete", lang), callback_data=f"ctl_delete_{ub_name}"),
            InlineKeyboardButton(text="💻 Console", callback_data=f"ctl_console_{ub_name}"),
        ],
        [InlineKeyboardButton(text=get_text("btn_back", lang), callback_data="my_bots")]
    ])

    try:
        await call.message.edit_caption(caption=text, reply_markup=kb)
    except:
        await call.message.edit_text(text, reply_markup=kb)


# ============== BOT CONTROLS ==============

@router.callback_query(F.data.startswith("ctl_start_"))
async def cb_control_start(call: CallbackQuery):
    ub_name = call.data[10:]
    try:
        success = await process_manager.start_process_from_saved(ub_name)
        if success:
            await db.update_userbot_status(ub_name, "running")
            await call.answer("▶️ Server ishga tushirildi!", show_alert=True)
        else:
            await call.answer("❌ Ishga tushirib bo'lmadi!", show_alert=True)
    except Exception as e:
        await call.answer(f"❌ Xato: {str(e)[:50]}", show_alert=True)


@router.callback_query(F.data.startswith("ctl_stop_"))
async def cb_control_stop(call: CallbackQuery):
    ub_name = call.data[9:]
    await process_manager.stop_process(ub_name)
    await db.update_userbot_status(ub_name, "stopped")
    await call.answer("⏹ Server to'xtatildi!", show_alert=True)


@router.callback_query(F.data.startswith("ctl_restart_"))
async def cb_control_restart(call: CallbackQuery):
    ub_name = call.data[12:]
    await process_manager.stop_process(ub_name)
    success = await process_manager.start_process_from_saved(ub_name)
    if success:
        await db.update_userbot_status(ub_name, "running")
        await call.answer("🔄 Server qayta ishga tushirildi!", show_alert=True)
    else:
        await call.answer("❌ Qayta ishga tushirib bo'lmadi!", show_alert=True)


@router.callback_query(F.data.startswith("ctl_logs_"))
async def cb_control_logs(call: CallbackQuery):
    ub_name = call.data[9:]
    lang = await db.get_user_language(call.from_user.id)

    logs = await process_manager.get_logs(ub_name, lines=50)
    if len(logs) > 3500:
        logs = logs[-3500:]

    text = f"📜 <b>Loglar — {ub_name}</b>\n\n<pre>{logs}</pre>"
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_text("btn_back", lang), callback_data=f"manage_{ub_name}")]
    ])

    try:
        await call.message.edit_text(text, reply_markup=kb)
    except Exception:
        # If text too long, send as file
        try:
            await call.message.answer(text[:4000], reply_markup=kb)
        except:
            await call.message.answer("📜 Loglar juda uzun. Qisqartirildi.", reply_markup=kb)


@router.callback_query(F.data.startswith("ctl_backup_"))
async def cb_backup(call: CallbackQuery):
    ub_name = call.data[11:]
    lang = await db.get_user_language(call.from_user.id)

    await call.answer("📦 Backup tayyorlanmoqda...", show_alert=True)
    try:
        backup_path = await backup_manager.create_backup(ub_name)
        if backup_path and os.path.exists(backup_path):
            doc = FSInputFile(backup_path, filename=f"{ub_name}_backup.zip")
            await call.message.answer_document(doc, caption=f"📦 <b>{ub_name}</b> backup tayyor!")
        else:
            await call.message.answer("❌ Backup yaratib bo'lmadi!")
    except Exception as e:
        await call.message.answer(f"❌ Xatolik: {str(e)[:100]}")


@router.callback_query(F.data.startswith("ctl_delete_"))
async def cb_delete_confirm(call: CallbackQuery):
    ub_name = call.data[11:]
    lang = await db.get_user_language(call.from_user.id)

    text = get_text("delete_confirm", lang, ub_name=ub_name)
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_text("btn_confirm_delete", lang), callback_data=f"confirm_del_{ub_name}")],
        [InlineKeyboardButton(text=get_text("btn_cancel", lang), callback_data=f"manage_{ub_name}")]
    ])

    try:
        await call.message.edit_caption(caption=text, reply_markup=kb)
    except:
        await call.message.edit_text(text, reply_markup=kb)


@router.callback_query(F.data.startswith("confirm_del_"))
async def cb_delete_userbot(call: CallbackQuery):
    ub_name = call.data[12:]
    lang = await db.get_user_language(call.from_user.id)
    bot_data = await db.get_userbot_data(ub_name)

    if not bot_data or bot_data["tg_user_id"] != call.from_user.id:
        await call.answer("🚫 Ruxsat yo'q!", show_alert=True)
        return

    # Delete
    await installer.delete_userbot(ub_name)
    await db.delete_userbot_record(ub_name)

    await call.answer(get_text("delete_success", lang, ub_name=ub_name), show_alert=True)

    # Return to bots list
    lang = await db.get_user_language(call.from_user.id)
    await show_main_menu(call, lang, call.from_user.full_name)


# ============== STATS ==============

@router.callback_query(F.data == "stats")
async def cb_stats(call: CallbackQuery):
    lang = await db.get_user_language(call.from_user.id)
    user = await db.get_user(call.from_user.id)
    bots = await db.get_userbots_by_tg_id(call.from_user.id)

    joined = user.get("created_at", "N/A")[:10] if user else "N/A"

    text = get_text("stats_text", lang,
                     balance=user.get("balance", 0) if user else 0,
                     bots=len(bots),
                     joined=joined)

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_text("btn_back", lang), callback_data="main_menu")]
    ])

    try:
        await call.message.edit_caption(caption=text, reply_markup=kb)
    except:
        await call.message.edit_text(text, reply_markup=kb)


# ============== MANUAL ==============

@router.callback_query(F.data == "manual")
async def cb_manual(call: CallbackQuery):
    lang = await db.get_user_language(call.from_user.id)
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_text("btn_back", lang), callback_data="main_menu")]
    ])
    try:
        await call.message.edit_caption(caption=get_text("manual_text", lang), reply_markup=kb)
    except:
        await call.message.edit_text(get_text("manual_text", lang), reply_markup=kb)


# ============== PROMO CODE ==============

@router.message(Command("promo"))
async def cmd_promo(message: Message, command: CommandObject):
    lang = await db.get_user_language(message.from_user.id)

    if not command.args:
        await message.answer("📝 Foydalanish: /promo <kod>")
        return

    code = command.args.strip()
    result = await db.redeem_promo_code(message.from_user.id, code)

    if result:
        await message.answer(get_text("promo_success", lang, amount=result))
    elif result is False:
        await message.answer(get_text("promo_used", lang))
    else:
        await message.answer(get_text("promo_invalid", lang))


# ============== CONSOLE ==============

@router.callback_query(F.data.startswith("ctl_console_"))
async def cb_control_console(call: CallbackQuery, state: FSMContext):
    ub_name = call.data[12:]
    logs = await process_manager.get_logs(ub_name, lines=15)
    
    text = f"💻 <b>Console: {ub_name}</b>\n\n<pre>{logs}</pre>\n\n✍️ <i>Buyruq yoki ma'lumot yozing (API ID, Code, etc):</i>"
    
    await state.update_data(console_ub=ub_name)
    await state.set_state(UserStates.waiting_console_input)
    
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔄 Yangilash", callback_data=f"ctl_console_{ub_name}")],
        [InlineKeyboardButton(text="◀️ Orqaga", callback_data=f"manage_{ub_name}")]
    ])
    
    try:
        await call.message.edit_text(text, reply_markup=kb) 
    except:
        await call.message.answer(text, reply_markup=kb)

@router.message(UserStates.waiting_console_input)
async def process_console_input(message: Message, state: FSMContext):
    data = await state.get_data()
    ub_name = data.get("console_ub")
    text = message.text
    
    if not ub_name:
        await message.answer("❌ Xatolik. Qaytadan urinib ko'ring.")
        await state.clear()
        return

    # Write to process stdin
    success = await process_manager.write_stdin(ub_name, text)
    
    status = "✅ Yuborildi" if success else "❌ Yuborib bo'lmadi (Jarayon o'chgan bo'lishi mumkin)"
    await message.answer(f"{status}: <code>{text}</code>")
    
    # Show console again with updated logs
    await asyncio.sleep(1) # Wait a bit for process to react
    logs = await process_manager.get_logs(ub_name, lines=15)
    
    resp = f"💻 <b>Console: {ub_name}</b>\n\n<pre>{logs}</pre>\n\n✍️ <i>Buyruq yoki ma'lumot yozing:</i>"
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔄 Yangilash", callback_data=f"ctl_console_{ub_name}")],
        [InlineKeyboardButton(text="◀️ Orqaga", callback_data=f"manage_{ub_name}")]
    ])
    await message.answer(resp, reply_markup=kb)
