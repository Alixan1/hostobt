import asyncio
import os
import sys
import subprocess
import signal
import json
import psutil
import logging
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

class ProcessManager:
    def __init__(self, data_dir: str = "userbots_data", state_file: str = "processes.json"):
        self.data_dir = data_dir
        self.state_file = state_file
        self.processes: Dict[str, psutil.Process] = {}
        self.process_info: Dict[str, Dict[str, Any]] = {} # name -> {python_exe, script, args, cwd}
        self._load_state()

    def _load_state(self):
        """Loads PID state from file and verifies if processes are still running."""
        if not os.path.exists(self.state_file):
            return

        try:
            with open(self.state_file, 'r') as f:
                saved_state = json.load(f)
            
            for name, data in saved_state.items():
                self.process_info[name] = data.get("info", {})
                pid = data.get("pid")
                if pid and psutil.pid_exists(pid):
                    try:
                        proc = psutil.Process(pid)
                        # Verify it's not a different process reusing the PID (basic check)
                        if proc.status() != psutil.STATUS_ZOMBIE:
                            self.processes[name] = proc
                            logger.info(f"Loaded existing process {name} (PID: {pid})")
                    except Exception:
                        pass
        except Exception as e:
            logger.error(f"Failed to load process state: {e}")

    def _save_state(self):
        """Saves current process PIDs to file."""
        state = {}
        for name, info in self.process_info.items():
            state[name] = {
                "info": info,
                "pid": self.processes[name].pid if name in self.processes and self.processes[name].is_running() else None
            }
        try:
            with open(self.state_file, 'w') as f:
                json.dump(state, f, indent=4)
        except Exception as e:
            logger.error(f"Failed to save process state: {e}")

    async def create_venv(self, environment_name: str) -> str:
        """Creates a virtual environment and returns the python executable path."""
        env_dir = os.path.join(self.data_dir, environment_name, "venv")
        if not os.path.exists(env_dir):
            logger.info(f"Creating venv for {environment_name}...")
            # Run venv creation in a separate thread/process to avoid blocking loop if slow
            await asyncio.to_thread(subprocess.check_call, [sys.executable, "-m", "venv", env_dir])
        
        # Determine python executable path
        if os.name == 'nt':
            python_exe = os.path.join(env_dir, "Scripts", "python.exe")
        else:
            python_exe = os.path.join(env_dir, "bin", "python")
            
        return os.path.abspath(python_exe)

    async def run_pip(self, python_exe: str, args: list) -> bool:
        cmd = [python_exe, "-m", "pip"] + args
        logger.info(f"Running pip: {' '.join(cmd)}")
        try:
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await process.communicate()
            if process.returncode != 0:
                logger.error(f"Pip command failed: {stderr.decode('utf-8', errors='replace')}")
                return False
            return True
        except Exception as e:
            logger.error(f"Pip exception: {e}")
            return False

    async def install_requirements(self, python_exe: str, requirements_path: str) -> bool:
        """Installs requirements using the specific python executable."""
        logger.info(f"Installing requirements from {requirements_path}...")
        try:
            cmd = [python_exe, "-m", "pip", "install", "--prefer-binary", "-r", requirements_path]
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await process.communicate()
            
            if process.returncode != 0:
                logger.error(f"Pip install failed: {stderr.decode('utf-8', errors='replace')}")
                return False
            return True
        except Exception as e:
            logger.error(f"Exception during pip install: {e}")
            return False

    async def start_process(self, name: str, python_exe: str, script_path: str, args: list = None, cwd: str = None) -> bool:
        """Starts a python script in a separate process."""
        if name in self.processes and self.processes[name].is_running():
            logger.warning(f"Process {name} is already running.")
            return True

        cmd = [python_exe, "-u", script_path] + (args or [])
        logger.info(f"Starting process {name}: {' '.join(cmd)}")
        
        log_file = os.path.join(cwd or ".", "process.log")
        
        try:
            # We use psutil.Popen to start and track
            # Open log file for redirecting stdout/stderr
            with open(log_file, "a") as f_log:
                # On Windows, creating a new console usage creationflags=subprocess.CREATE_NEW_CONSOLE
                creationflags = 0
                if os.name == 'nt':
                    creationflags = subprocess.CREATE_NEW_CONSOLE
                
                proc = psutil.Popen(
                    cmd,
                    cwd=cwd,
                    stdout=f_log,
                    stderr=f_log, 
                    stdin=subprocess.PIPE, # Enable stdin for interaction
                    creationflags=creationflags,
                    text=True if os.name != 'nt' else False # Buffering/Encoding issues on Windows? psutil Popen usually binary or uses os.
                    # Actually psutil.Popen wraps subprocess.Popen. 
                    # If we want text input, we should encoding... but binary is safer for cross-platform psutil wrapper sometimes.
                    # converting input to bytes is easy.
                )
                
            self.processes[name] = proc
            self.process_info[name] = {
                "python_exe": python_exe,
                "script": script_path,
                "args": args,
                "cwd": cwd
            }
            self._save_state()
            logger.info(f"Started {name} (PID: {proc.pid}) with stdin enabled")
            return True
        except Exception as e:
            logger.error(f"Failed to start process {name}: {e}")
            return False

    async def write_stdin(self, name: str, text: str) -> bool:
        """Writes text to the process stdin."""
        if name not in self.processes:
            return False
            
        proc = self.processes[name]
        if not proc.is_running():
            return False
            
        try:
            # Add newline if missing
            if not text.endswith("\n"):
                text += "\n"
                
            # Convert to bytes
            input_bytes = text.encode('utf-8')
            
            proc.stdin.write(input_bytes)
            proc.stdin.flush()
            logger.info(f"Wrote to stdin of {name}: {text.strip()}")
            return True
        except Exception as e:
            logger.error(f"Failed to write to stdin of {name}: {e}")
            return False


    async def start_process_from_saved(self, name: str) -> bool:
        if name not in self.process_info:
            logger.error(f"No saved info for {name}")
            return False
        
        info = self.process_info[name]
        return await self.start_process(
            name, 
            info["python_exe"], 
            info["script"], 
            info["args"], 
            info["cwd"]
        )

    async def stop_process(self, name: str) -> bool:
        if name not in self.processes:
            return False
            
        proc = self.processes[name]
        try:
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except psutil.TimeoutExpired:
                proc.kill()
            
            del self.processes[name]
            # We keep process_info for restart!
            self._save_state() # PID will be None
            logger.info(f"Stopped {name}")
            return True
        except Exception as e:
            logger.error(f"Error stopping {name}: {e}")
            return False

    def is_running(self, name: str) -> bool:
        """Check if a process is currently running."""
        if name not in self.processes:
            return False
        try:
            proc = self.processes[name]
            return proc.is_running() and proc.status() != psutil.STATUS_ZOMBIE
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return False

    async def get_logs(self, name: str, lines: int = 100) -> str:
        log_file = os.path.join(self.data_dir, name, "process.log")
        if not os.path.exists(log_file):
            return "No logs found."
            
        def _tail(path, n_lines):
            try:
                # Read last 16KB which should be enough for 100 lines
                block_size = 16384 
                with open(path, 'rb') as f:
                    try:
                        f.seek(-block_size, 2)
                    except OSError:
                        f.seek(0)
                    last_block = f.read()
                    
                text = last_block.decode('utf-8', errors='replace')
                return "\n".join(text.splitlines()[-n_lines:])
            except Exception as e:
                return f"Error reading logs: {e}"

        return await asyncio.to_thread(_tail, log_file, lines)

process_manager = ProcessManager()
