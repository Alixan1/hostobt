import os
import shutil
import asyncio
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

class BackupManager:
    def __init__(self):
        self.backup_dir = "backups"
        self.data_dir = "userbots_data"
        os.makedirs(self.backup_dir, exist_ok=True)

    async def create_backup(self, ub_name: str) -> str:
        """
        Creates a zip backup of the userbot's data directory.
        Returns the path to the zip file.
        """
        source_dir = os.path.join(self.data_dir, ub_name)
        if not os.path.exists(source_dir):
            return None

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_filename = f"{ub_name}_backup_{timestamp}"
        output_path = os.path.join(self.backup_dir, backup_filename)
        
        # Run synchronous shutil.make_archive in a separate thread to avoid blocking
        loop = asyncio.get_running_loop()
        zip_path = await loop.run_in_executor(
            None, 
            lambda: shutil.make_archive(output_path, 'zip', source_dir)
        )
        
        logger.info(f"Backup created for {ub_name}: {zip_path}")
        return zip_path

    async def restore_backup(self, ub_name: str, zip_path: str) -> bool:
        """
        Restores data from a zip file to the userbot's directory.
        WARNING: Overwrites existing data.
        """
        target_dir = os.path.join(self.data_dir, ub_name)
        
        # Verify zip
        if not os.path.exists(zip_path):
            return False
            
        # Clean target
        if os.path.exists(target_dir):
            shutil.rmtree(target_dir)
        os.makedirs(target_dir, exist_ok=True)
        
        # Unzip
        loop = asyncio.get_running_loop()
        try:
            await loop.run_in_executor(
                None,
                lambda: shutil.unpack_archive(zip_path, target_dir, 'zip')
            )
            logger.info(f"Restored backup for {ub_name} from {zip_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to restore backup: {e}")
            return False

backup_manager = BackupManager()
