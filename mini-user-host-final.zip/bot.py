import asyncio
import logging
import sys
from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties
from config_manager import config
import database as db
import user_handlers
import admin_handlers
from payment_checker import PaymentChecker
import payment_checker as pc_module
from process_manager import process_manager

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(name)s | %(levelname)s | %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("logs/bot.log", encoding="utf-8")
    ]
)
logger = logging.getLogger(__name__)


async def main():
    # Initialize Database
    await db.init_db()
    logger.info("✅ Database initialized")

    # Initialize Bot
    bot = Bot(token=config.BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()

    # Initialize Payment Checker
    checker = PaymentChecker(bot, config)
    pc_module.payment_checker = checker

    # Startup Notification
    if config.ADMIN_IDS:
        try:
            plans_info = ""
            for i, p in enumerate(config.SERVER_PLANS):
                plans_info += f"\n   📦 {p['name']}: {p['nvme_gb']}GB/{p['ram_gb']}GB/{p['cpu_count']}CPU — {p['price_stars']}⭐"

            await bot.send_message(
                config.ADMIN_IDS[0],
                f"⚡️ <b>ARCAI HOST ishga tushdi!</b>\n"
                f"━━━━━━━━━━━━━━━━\n\n"
                f"🤖 Bot: @{(await bot.get_me()).username}\n"
                f"📦 Planlar:{plans_info}\n"
                f"💰 Gift miqdori: {config.GIFT_AMOUNT}⭐\n"
                f"📢 Kanal: @{config.FORCE_SUB_CHANNEL}\n\n"
                f"✅ Barcha tizimlar tayyor!"
            )
        except Exception as e:
            logger.warning(f"Could not send startup message: {e}")

    # Include Routers
    dp.include_router(user_handlers.router)
    dp.include_router(admin_handlers.router)

    # Start Payment Checker as background task
    asyncio.create_task(checker.start_monitoring())
    # Start Auto-Stop Task
    asyncio.create_task(auto_stop_task())
    # Start Watchdog Task (auto-restart crashed userbots)
    asyncio.create_task(watchdog_task(bot))

    # Delete Webhook (if any) and start polling with retry
    await bot.delete_webhook(drop_pending_updates=True)
    logger.info("⚡️ ARCAI HOST started polling...")

    # ===== RETRY LOOP — prevents crash on ServerDisconnectedError =====
    while True:
        try:
            await dp.start_polling(bot)
        except Exception as e:
            logger.error(f"❌ Polling error: {e}, restarting in 5 seconds...")
            await asyncio.sleep(5)
            try:
                await bot.delete_webhook(drop_pending_updates=True)
            except:
                pass


async def auto_stop_task():
    """Background task to stop expired userbots"""
    while True:
        try:
            expired_bots = await db.get_expired_userbots()
            if expired_bots:
                logger.info(f"Checking expiry: Found {len(expired_bots)} expired bots")
                for bot_data in expired_bots:
                    ub_name = bot_data["ub_username"]
                    user_id = bot_data["tg_user_id"]
                    
                    logger.info(f"Stopping expired bot: {ub_name}")
                    await process_manager.stop_process(ub_name)
                    await db.update_userbot_status(ub_name, "expired")
        except Exception as e:
            logger.error(f"Auto-stop task error: {e}")
        
        # Check every hour
        await asyncio.sleep(3600)


async def watchdog_task(bot: Bot):
    """Background task — auto-restart crashed userbot processes"""
    await asyncio.sleep(30)  # Initial delay
    logger.info("🐕 Watchdog task started")
    
    while True:
        try:
            running_bots = await db.get_running_userbots()
            for bot_data in running_bots:
                ub_name = bot_data["ub_username"]
                user_id = bot_data["tg_user_id"]
                
                # Check if process is actually running
                if not process_manager.is_running(ub_name):
                    logger.warning(f"🐕 Watchdog: {ub_name} crashed! Restarting...")
                    success = await process_manager.start_process_from_saved(ub_name)
                    if success:
                        logger.info(f"🐕 Watchdog: {ub_name} restarted successfully")
                        # Notify user
                        try:
                            await bot.send_message(
                                user_id,
                                f"🔄 <b>Auto-restart:</b> <code>{ub_name}</code>\n"
                                f"⚡️ Server avtomatik qayta ishga tushirildi!"
                            )
                        except:
                            pass
                    else:
                        logger.error(f"🐕 Watchdog: Failed to restart {ub_name}")
                        await db.update_userbot_status(ub_name, "crashed")
        except Exception as e:
            logger.error(f"Watchdog error: {e}")
        
        # Check every 60 seconds
        await asyncio.sleep(60)


if __name__ == "__main__":
    # Ensure logs directory exists
    import os
    os.makedirs("logs", exist_ok=True)

    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logger.info("Bot stopped!")
