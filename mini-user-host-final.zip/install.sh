#!/bin/bash
# ============================================
# ARCAI HOST — VDS Deploy Script
# Tested on: Ubuntu 20.04+ / Debian 11+
# ============================================

set -e

echo "┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"
echo "  ⚡️ ARCAI HOST — VDS Installer"
echo "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"
echo ""

# 1. System Dependencies
echo "📦 Installing system dependencies..."
apt-get update -qq
apt-get install -y python3 python3-pip python3-venv git screen curl

# 2. Python Virtual Environment
echo "🐍 Setting up Python virtual environment..."
cd "$(dirname "$0")"
WORK_DIR=$(pwd)

if [ ! -d "venv" ]; then
    python3 -m venv venv
fi
source venv/bin/activate

# 3. Python Dependencies
echo "📥 Installing Python dependencies..."
pip install --upgrade pip setuptools wheel
pip install -r requirements.txt

# 4. Create logs directory
mkdir -p logs

# 5. Setup Systemd Service
echo "🔧 Setting up systemd service..."
SERVICE_FILE="/etc/systemd/system/minihost-bot.service"

cat > "$SERVICE_FILE" << EOF
[Unit]
Description=ARCAI HOST Telegram Bot
After=network.target

[Service]
User=root
WorkingDirectory=$WORK_DIR
ExecStart=$WORK_DIR/venv/bin/python3 bot.py
Restart=always
RestartSec=10
Environment=PYTHONUNBUFFERED=1

# Memory/Resource limits (optional)
# MemoryMax=512M
# CPUQuota=50%

[Install]
WantedBy=multi-user.target
EOF

# 6. Enable and Start Service
systemctl daemon-reload
systemctl enable minihost-bot
systemctl restart minihost-bot

echo ""
echo "┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"
echo "  ✅ ARCAI HOST — Tayyor!"
echo "┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"
echo ""
echo "📌 Useful commands:"
echo "  systemctl status minihost-bot    — Status"
echo "  systemctl restart minihost-bot   — Restart"
echo "  journalctl -u minihost-bot -f    — Live logs"
echo "  systemctl stop minihost-bot      — Stop"
echo ""
