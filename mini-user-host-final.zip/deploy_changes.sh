#!/bin/bash
# ============================================
# ARCAI HOST — Apply All Fixes
# Run: bash deploy_changes.sh
# ============================================
set -e
cd "$(dirname "$0")"

echo "⚡ Applying all fixes..."

# ===== 1. bot.service =====
cat > bot.service << 'BOTSERVICE'
[Unit]
Description=ARCAI HOST Telegram Bot
After=network.target

[Service]
User=root
WorkingDirectory=/root/mini-user-host
ExecStart=/root/mini-user-host/venv/bin/python3 bot.py
Restart=always
RestartSec=10
Environment=PYTHONUNBUFFERED=1
Nice=10

[Install]
WantedBy=multi-user.target
BOTSERVICE

echo "✅ bot.service updated"

# ===== 2. install.sh =====
cat > install.sh << 'INSTALLSH'
#!/bin/bash
set -e
echo "⚡️ ARCAI HOST — VDS Installer"
apt-get update -qq
apt-get install -y python3 python3-pip python3-venv git screen curl
cd "$(dirname "$0")"
WORK_DIR=$(pwd)
[ ! -d "venv" ] && python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip setuptools wheel
pip install -r requirements.txt
mkdir -p logs
cat > /etc/systemd/system/minihost-bot.service << SVCEOF
[Unit]
Description=ARCAI HOST Telegram Bot
After=network.target
[Service]
User=root
WorkingDirectory=$WORK_DIR
ExecStart=$WORK_DIR/venv/bin/python3 bot.py
Restart=always
RestartSec=10
Environment=PYTHONUNBUFFERED=1
Nice=10
[Install]
WantedBy=multi-user.target
SVCEOF
systemctl daemon-reload
systemctl enable minihost-bot
systemctl restart minihost-bot
echo "✅ ARCAI HOST — Tayyor!"
echo "  systemctl status minihost-bot"
echo "  journalctl -u minihost-bot -f"
INSTALLSH
chmod +x install.sh
echo "✅ install.sh updated"

echo ""
echo "⚠️  bot.py, user_handlers.py, locales.py, database.py, process_manager.py"
echo "   fayllar allaqachon o'zgartirilgan. Faqat shu scriptni run qiling."
echo ""
echo "🚀 VDS ga deploy:"
echo "   scp -r mini-user-host/ root@VDS_IP:/root/"
echo "   ssh root@VDS_IP 'cd /root/mini-user-host && chmod +x install.sh && ./install.sh'"
