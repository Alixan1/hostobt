"""
ARCAI HOST — Admin Panel (20+ Functions)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Features:
 1. Server Status (CPU/RAM/Disk/Uptime)
 2. System Logs
 3. Statistics Dashboard
 4. Users List (paginated)
 5. User Search
 6. User Profile (ban/unban/balance)
 7. Set Balance
 8. Add Balance
 9. All Userbots List
10. Force Stop All Bots
11. Restart Userbot
12. Broadcast (text/photo/video)
13. Promo Codes Management
14. Create Promo
15. Delete Promo
16. Income Report
17. Manual Payment
18. Config View
19. Backup Database
20. Export Users CSV
21. Watchdog Status
22. Send Notification to User
23. Maintenance Mode Toggle
"""
from aiogram import Router, F, types
from aiogram.filters import Command, StateFilter
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, FSInputFile, BufferedInputFile
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
import psutil
import database as db
from config_manager import config
from process_manager import process_manager
from payment_checker import payment_checker
from locales import get_sticker
import logging
import asyncio
import os
import json
import time
import datetime
import shutil

logger = logging.getLogger(__name__)
router = Router()

# Maintenance mode flag
MAINTENANCE_MODE = False


class AdminStates(StatesGroup):
    waiting_broadcast_text = State()
    waiting_promo_code = State()
    waiting_promo_amount = State()
    waiting_promo_uses = State()
    waiting_user_search = State()
    waiting_balance_amount = State()
    waiting_add_balance_amount = State()
    waiting_manual_payment_user = State()
    waiting_manual_payment_amount = State()
    waiting_notify_user_id = State()
    waiting_notify_text = State()


def is_admin(user_id: int) -> bool:
    return user_id in config.ADMIN_IDS


def bar(percent, length=10):
    filled = int(length * percent / 100)
    return "█" * filled + "░" * (length - filled)


# ============== ADMIN PANEL ENTRY ==============

@router.message(Command("admin"))
async def cmd_admin_panel(message: Message):
    if not is_admin(message.from_user.id):
        return
    await show_admin_menu(message)


async def show_admin_menu(message_or_call, edit: bool = False):
    global MAINTENANCE_MODE
    maint_icon = "🔴" if MAINTENANCE_MODE else "🟢"

    text = (
        "┏━━━━━━━━━━━━━━━━━━━━━━━┓\n"
        "    ⚡️ <b>ARCAI HOST Admin</b>\n"
        "┗━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
        f"📡 Status: {maint_icon} | 🕐 {datetime.datetime.now().strftime('%H:%M')}\n\n"
        "🔧 Funksiyani tanlang:"
    )

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🖥 Server", callback_data="adm_server"),
            InlineKeyboardButton(text="📜 Loglar", callback_data="adm_logs"),
        ],
        [
            InlineKeyboardButton(text="📊 Statistika", callback_data="adm_stats"),
            InlineKeyboardButton(text="💰 Daromad", callback_data="adm_income"),
        ],
        [
            InlineKeyboardButton(text="👥 Foydalanuvchilar", callback_data="adm_users"),
            InlineKeyboardButton(text="🔍 Qidirish", callback_data="adm_search"),
        ],
        [
            InlineKeyboardButton(text="🤖 Botlar", callback_data="adm_bots"),
            InlineKeyboardButton(text="⛔️ Hammasini to'xtat", callback_data="adm_stopall"),
        ],
        [
            InlineKeyboardButton(text="📢 Broadcast", callback_data="adm_broadcast"),
            InlineKeyboardButton(text="🎁 Promokodlar", callback_data="adm_promos"),
        ],
        [
            InlineKeyboardButton(text="💳 Manual to'lov", callback_data="adm_manual_pay"),
            InlineKeyboardButton(text="📩 Xabar yuborish", callback_data="adm_notify"),
        ],
        [
            InlineKeyboardButton(text="⚙️ Config", callback_data="adm_config"),
            InlineKeyboardButton(text="🐕 Watchdog", callback_data="adm_watchdog"),
        ],
        [
            InlineKeyboardButton(text="💾 DB Backup", callback_data="adm_backup_db"),
            InlineKeyboardButton(text="📤 Export CSV", callback_data="adm_export"),
        ],
        [
            InlineKeyboardButton(text=f"🔧 Maintenance {maint_icon}", callback_data="adm_maintenance"),
        ],
        [InlineKeyboardButton(text="❌ Yopish", callback_data="adm_close")]
    ])

    if isinstance(message_or_call, CallbackQuery):
        try:
            await message_or_call.message.edit_text(text, reply_markup=kb)
        except:
            await message_or_call.message.answer(text, reply_markup=kb)
    else:
        await message_or_call.answer(text, reply_markup=kb)


# ============== 1. SERVER STATUS ==============

@router.callback_query(F.data == "adm_server")
async def cb_admin_server(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return

    cpu_percent = psutil.cpu_percent(interval=1)
    ram = psutil.virtual_memory()
    disk = psutil.disk_usage("/")
    net = psutil.net_io_counters()
    procs = len(psutil.pids())

    text = (
        "┏━━━━━━━━━━━━━━━━━━━━━━━┓\n"
        "    🖥 <b>Server Ma'lumotlari</b>\n"
        "┗━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
        f"🔥 <b>CPU:</b> {cpu_percent}%\n"
        f"<code>[{bar(cpu_percent)}]</code>\n\n"
        f"🧠 <b>RAM:</b> {ram.used // (1024**2)}MB / {ram.total // (1024**2)}MB ({ram.percent}%)\n"
        f"<code>[{bar(ram.percent)}]</code>\n\n"
        f"💾 <b>Disk:</b> {disk.used // (1024**3)}GB / {disk.total // (1024**3)}GB ({disk.percent}%)\n"
        f"<code>[{bar(disk.percent)}]</code>\n\n"
        f"🌐 <b>Network:</b>\n"
        f"   📤 Sent: {net.bytes_sent // (1024**2)}MB\n"
        f"   📥 Recv: {net.bytes_recv // (1024**2)}MB\n\n"
        f"⚙️ <b>Processes:</b> {procs}\n"
        f"⏱ <b>Uptime:</b> {_get_uptime()}"
    )

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔄 Yangilash", callback_data="adm_server")],
        [InlineKeyboardButton(text="◀️ Orqaga", callback_data="adm_main")]
    ])
    await call.message.edit_text(text, reply_markup=kb)


def _get_uptime():
    boot = psutil.boot_time()
    uptime_s = time.time() - boot
    days = int(uptime_s // 86400)
    hours = int((uptime_s % 86400) // 3600)
    mins = int((uptime_s % 3600) // 60)
    return f"{days}d {hours}h {mins}m"


# ============== 2. SYSTEM LOGS ==============

@router.callback_query(F.data == "adm_logs")
async def cb_admin_logs(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return

    log_path = os.path.join("logs", "bot.log")
    if not os.path.exists(log_path):
        await call.answer("📭 Loglar topilmadi!", show_alert=True)
        return

    try:
        with open(log_path, 'rb') as f:
            try:
                f.seek(-8192, 2)
            except OSError:
                f.seek(0)
            content = f.read().decode('utf-8', errors='replace')

        lines = content.splitlines()[-30:]
        log_text = "\n".join(lines)
        if len(log_text) > 3500:
            log_text = log_text[-3500:]

        text = (
            "┏━━━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    📜 <b>System Logs</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            f"<pre>{log_text}</pre>"
        )
    except Exception as e:
        text = f"❌ Log o'qishda xato: {e}"

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🔄 Yangilash", callback_data="adm_logs"),
            InlineKeyboardButton(text="📎 Fayl yuborish", callback_data="adm_logs_file"),
        ],
        [InlineKeyboardButton(text="◀️ Orqaga", callback_data="adm_main")]
    ])

    try:
        await call.message.edit_text(text, reply_markup=kb)
    except:
        await call.message.answer(text, reply_markup=kb)


@router.callback_query(F.data == "adm_logs_file")
async def cb_admin_logs_file(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return

    log_path = os.path.join("logs", "bot.log")
    if os.path.exists(log_path):
        doc = FSInputFile(log_path, filename="bot.log")
        await call.message.answer_document(doc, caption="📜 <b>Bot loglar</b>")
    else:
        await call.answer("📭 Log fayl topilmadi!", show_alert=True)


# ============== 3. STATISTICS DASHBOARD ==============

@router.callback_query(F.data == "adm_stats")
async def cb_admin_stats(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return

    stats = await db.get_subscription_stats()
    user_stats = await db.get_user_stats()

    active_pct = 0
    if stats.get('total_bots', 0) > 0:
        active_pct = int(stats.get('active_bots', 0) / stats.get('total_bots', 1) * 100)

    text = (
        "┏━━━━━━━━━━━━━━━━━━━━━━━┓\n"
        "    📊 <b>Statistika Dashboard</b>\n"
        "┗━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
        "👥 <b>Foydalanuvchilar:</b>\n"
        "┌──────────────────┐\n"
        f"│ 📅 Bugun:   <b>{user_stats.get('today', 0)}</b>\n"
        f"│ 📆 Hafta:   <b>{user_stats.get('week', 0)}</b>\n"
        f"│ 📆 Oy:      <b>{user_stats.get('month', 0)}</b>\n"
        f"│ 📊 Jami:    <b>{user_stats.get('total', 0)}</b>\n"
        "└──────────────────┘\n\n"
        "🤖 <b>Serverlar:</b>\n"
        "┌──────────────────┐\n"
        f"│ 🟢 Aktiv:   <b>{stats.get('active_bots', 0)}</b>\n"
        f"│ 📊 Jami:    <b>{stats.get('total_bots', 0)}</b>\n"
        f"│ <code>[{bar(active_pct)}]</code> {active_pct}%\n"
        "└──────────────────┘\n\n"
        f"💰 <b>Umumiy daromad:</b> {stats.get('total_income', 0)} ⭐️"
    )

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔄 Yangilash", callback_data="adm_stats")],
        [InlineKeyboardButton(text="◀️ Orqaga", callback_data="adm_main")]
    ])
    await call.message.edit_text(text, reply_markup=kb)


# ============== 4. USERS LIST (PAGINATED) ==============

@router.callback_query(F.data == "adm_users")
async def cb_admin_users(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return
    await _show_users_page(call, 1)


@router.callback_query(F.data.startswith("adm_users_p"))
async def cb_admin_users_page(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return
    page = int(call.data.split("_")[-1])
    await _show_users_page(call, page)


async def _show_users_page(call: CallbackQuery, page: int):
    per_page = 10
    users, total = await db.get_users_paginated(page=page, per_page=per_page)
    total_pages = max(1, (total + per_page - 1) // per_page)

    text = (
        "┏━━━━━━━━━━━━━━━━━━━━━━━┓\n"
        f"    👥 <b>Foydalanuvchilar</b> ({total})\n"
        "┗━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
    )

    for u in users:
        status = "🚫" if u.get("is_banned") else "✅"
        username = f"@{u['username']}" if u.get('username') else "—"
        text += f"{status} <code>{u['tg_user_id']}</code> | {username} | 💰{u.get('balance', 0)}⭐\n"

    text += f"\n📄 Sahifa: {page}/{total_pages}"

    # Pagination buttons
    nav_buttons = []
    if page > 1:
        nav_buttons.append(InlineKeyboardButton(text="⬅️", callback_data=f"adm_users_p_{page-1}"))
    nav_buttons.append(InlineKeyboardButton(text=f"{page}/{total_pages}", callback_data="adm_noop"))
    if page < total_pages:
        nav_buttons.append(InlineKeyboardButton(text="➡️", callback_data=f"adm_users_p_{page+1}"))

    kb = InlineKeyboardMarkup(inline_keyboard=[
        nav_buttons,
        [InlineKeyboardButton(text="◀️ Orqaga", callback_data="adm_main")]
    ])
    await call.message.edit_text(text, reply_markup=kb)


# ============== 5. USER SEARCH ==============

@router.callback_query(F.data == "adm_search")
async def cb_admin_search(call: CallbackQuery, state: FSMContext):
    if not is_admin(call.from_user.id):
        return
    await state.set_state(AdminStates.waiting_user_search)
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="❌ Bekor qilish", callback_data="adm_main")]
    ])
    await call.message.edit_text(
        "┏━━━━━━━━━━━━━━━━━━━━━━━┓\n"
        "    🔍 <b>Foydalanuvchi Qidirish</b>\n"
        "┗━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
        "👤 ID yoki @username kiriting:",
        reply_markup=kb
    )


@router.message(AdminStates.waiting_user_search)
async def process_user_search(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    user = await db.search_user(message.text.strip())
    await state.clear()
    if not user:
        await message.answer("❌ Foydalanuvchi topilmadi!")
        return
    await show_user_profile(message, user)


# ============== 6. USER PROFILE ==============

async def show_user_profile(message_or_call, user: dict, edit: bool = False):
    uid = user["tg_user_id"]
    bots = await db.get_userbots_by_tg_id(uid)
    ban_status = "🚫 Bloklangan" if user.get("is_banned") else "✅ Faol"

    text = (
        "┏━━━━━━━━━━━━━━━━━━━━━━━┓\n"
        "    👤 <b>Foydalanuvchi Profili</b>\n"
        "┗━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
        "┌──────────────────┐\n"
        f"│ 🆔 ID: <code>{uid}</code>\n"
        f"│ 👤 Ism: {user.get('full_name', '—')}\n"
        f"│ 📱 Username: @{user.get('username', '—')}\n"
        f"│ 💰 Balans: <b>{user.get('balance', 0)} ⭐️</b>\n"
        f"│ 🌐 Til: {user.get('language', 'uz')}\n"
        f"│ 📡 Status: {ban_status}\n"
        f"│ 🤖 Serverlar: {len(bots)}\n"
        f"│ 📅 Ro'yxat: {str(user.get('created_at', ''))[:10]}\n"
        "└──────────────────┘"
    )

    ban_text = "🔓 Unban" if user.get("is_banned") else "🚫 Ban"
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text=ban_text, callback_data=f"adm_ban_{uid}"),
            InlineKeyboardButton(text="💰 Balans", callback_data=f"adm_setbal_{uid}"),
        ],
        [
            InlineKeyboardButton(text="💳 Stars +", callback_data=f"adm_addbal_{uid}"),
            InlineKeyboardButton(text="📩 Xabar", callback_data=f"adm_msg_{uid}"),
        ],
        [InlineKeyboardButton(text="◀️ Orqaga", callback_data="adm_main")]
    ])

    if isinstance(message_or_call, CallbackQuery):
        await message_or_call.message.edit_text(text, reply_markup=kb)
    else:
        await message_or_call.answer(text, reply_markup=kb)


# ============== 7. BAN/UNBAN ==============

@router.callback_query(F.data.startswith("adm_ban_"))
async def cb_toggle_ban(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return
    uid = int(call.data[8:])
    user = await db.get_user(uid)
    if not user:
        await call.answer("❌ Topilmadi!", show_alert=True)
        return
    if user.get("is_banned"):
        await db.unban_user(uid)
        await call.answer(f"✅ {uid} blokdan chiqarildi!", show_alert=True)
    else:
        await db.ban_user(uid)
        await call.answer(f"🚫 {uid} bloklandi!", show_alert=True)
    user = await db.get_user(uid)
    await show_user_profile(call, user, edit=True)


# ============== 8. SET BALANCE ==============

@router.callback_query(F.data.startswith("adm_setbal_"))
async def cb_set_balance(call: CallbackQuery, state: FSMContext):
    if not is_admin(call.from_user.id):
        return
    uid = int(call.data[11:])
    await state.update_data(target_uid=uid)
    await state.set_state(AdminStates.waiting_balance_amount)
    await call.message.edit_text(f"💰 <b>{uid}</b> uchun yangi balansni kiriting:")


@router.message(AdminStates.waiting_balance_amount)
async def process_balance_set(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    try:
        amount = int(message.text.strip())
        data = await state.get_data()
        uid = data.get("target_uid")
        await db.set_user_balance(uid, amount)
        await message.answer(f"✅ {uid} balansi: <b>{amount} ⭐️</b>")
    except ValueError:
        await message.answer("❌ Faqat raqam kiriting!")
    await state.clear()


# ============== 9. ADD BALANCE ==============

@router.callback_query(F.data.startswith("adm_addbal_"))
async def cb_add_balance(call: CallbackQuery, state: FSMContext):
    if not is_admin(call.from_user.id):
        return
    uid = int(call.data[11:])
    await state.update_data(target_uid=uid)
    await state.set_state(AdminStates.waiting_add_balance_amount)
    await call.message.edit_text(f"💳 <b>{uid}</b> ga qancha Stars <b>qo'shish</b> kerak?")


@router.message(AdminStates.waiting_add_balance_amount)
async def process_add_balance(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    try:
        amount = int(message.text.strip())
        if amount <= 0:
            raise ValueError
        data = await state.get_data()
        uid = data.get("target_uid")
        await db.update_balance(uid, amount, "admin_add", f"Admin qo'shdi: +{amount}⭐")
        new_bal = await db.get_user_balance(uid)
        await message.answer(f"✅ +{amount} ⭐️ qo'shildi!\n💰 Yangi balans: <b>{new_bal} ⭐️</b>")
    except ValueError:
        await message.answer("❌ Musbat raqam kiriting!")
    await state.clear()


# ============== 10. ALL USERBOTS ==============

@router.callback_query(F.data == "adm_bots")
async def cb_admin_bots(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return

    bots = await db.get_all_userbots()
    if not bots:
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="◀️ Orqaga", callback_data="adm_main")]
        ])
        await call.message.edit_text("📭 Hech qanday server yo'q.", reply_markup=kb)
        return

    running = sum(1 for b in bots if b.get("status") == "running")
    text = (
        "┏━━━━━━━━━━━━━━━━━━━━━━━┓\n"
        f"    🤖 <b>Serverlar</b> ({len(bots)})\n"
        "┗━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
        f"🟢 Running: {running} | 🔴 Stopped: {len(bots) - running}\n\n"
    )

    for b in bots[:15]:
        status = "🟢" if b.get("status") == "running" else "🔴"
        owner = f"@{b.get('owner_username', '?')}" if b.get('owner_username') else str(b.get('tg_user_id', '?'))
        text += f"{status} <b>{b['ub_username']}</b> | {b.get('ub_type', '?')} | 👤{owner}\n"

    if len(bots) > 15:
        text += f"\n... va yana {len(bots) - 15} ta"

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="◀️ Orqaga", callback_data="adm_main")]
    ])
    await call.message.edit_text(text, reply_markup=kb)


# ============== 11. FORCE STOP ALL ==============

@router.callback_query(F.data == "adm_stopall")
async def cb_stop_all(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⛔️ Ha, hammasini to'xtat!", callback_data="adm_stopall_confirm")],
        [InlineKeyboardButton(text="❌ Bekor qilish", callback_data="adm_main")]
    ])
    await call.message.edit_text(
        "⚠️ <b>DIQQAT!</b>\n\nBarcha running userbotlarni to'xtatmoqchimisiz?",
        reply_markup=kb
    )


@router.callback_query(F.data == "adm_stopall_confirm")
async def cb_stop_all_confirm(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return

    bots = await db.get_all_userbots()
    stopped = 0
    for b in bots:
        if b.get("status") == "running":
            try:
                await process_manager.stop_process(b["ub_username"])
                await db.update_userbot_status(b["ub_username"], "stopped")
                stopped += 1
            except:
                pass

    await call.answer(f"⛔️ {stopped} ta server to'xtatildi!", show_alert=True)
    await show_admin_menu(call)


# ============== 12. BROADCAST ==============

@router.callback_query(F.data == "adm_broadcast")
async def cb_admin_broadcast(call: CallbackQuery, state: FSMContext):
    if not is_admin(call.from_user.id):
        return
    await state.set_state(AdminStates.waiting_broadcast_text)
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="❌ Bekor qilish", callback_data="adm_main")]
    ])
    await call.message.edit_text(
        "┏━━━━━━━━━━━━━━━━━━━━━━━┓\n"
        "    📢 <b>Broadcast</b>\n"
        "┗━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
        "📝 Matn, rasm yoki video yuboring:",
        reply_markup=kb
    )


@router.message(AdminStates.waiting_broadcast_text)
async def process_broadcast(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return

    await state.clear()
    users = await db.get_all_users()
    sent = 0
    failed = 0
    total = len(users)
    status_msg = await message.answer(
        f"📢 <b>Broadcast boshlandi...</b>\n"
        f"<code>[{'░' * 10}]</code> 0/{total}"
    )

    for i, user in enumerate(users):
        try:
            uid = user["tg_user_id"]
            if message.photo:
                await message.bot.send_photo(uid, photo=message.photo[-1].file_id, caption=message.caption or "")
            elif message.video:
                await message.bot.send_video(uid, video=message.video.file_id, caption=message.caption or "")
            elif message.sticker:
                await message.bot.send_sticker(uid, sticker=message.sticker.file_id)
            elif message.animation:
                await message.bot.send_animation(uid, animation=message.animation.file_id, caption=message.caption or "")
            else:
                await message.bot.send_message(uid, message.text or "")
            sent += 1
        except Exception:
            failed += 1

        if (i + 1) % 25 == 0:
            pct = int((i + 1) / total * 100)
            try:
                await status_msg.edit_text(
                    f"📢 <b>Broadcast...</b>\n"
                    f"<code>[{bar(pct)}]</code> {i+1}/{total}\n"
                    f"✅ {sent} | ❌ {failed}"
                )
            except:
                pass
            await asyncio.sleep(0.5)

    await status_msg.edit_text(
        "┏━━━━━━━━━━━━━━━━━━━━━━━┓\n"
        "   ✅ <b>Broadcast tugadi!</b>\n"
        "┗━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
        f"📤 Yuborildi: <b>{sent}</b>\n"
        f"❌ Xato: <b>{failed}</b>\n"
        f"📊 Jami: <b>{total}</b>"
    )


# ============== 13-15. PROMO CODES ==============

@router.callback_query(F.data == "adm_promos")
async def cb_admin_promos(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return

    promos = await db.get_all_promo_codes()
    text = (
        "┏━━━━━━━━━━━━━━━━━━━━━━━┓\n"
        "    🎁 <b>Promokodlar</b>\n"
        "┗━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
    )

    if promos:
        for p in promos:
            status = "✅" if p.get("is_active") else "❌"
            text += f"{status} <code>{p['code']}</code> | 💰{p['amount']}⭐ | {p.get('used_count', 0)}/{p.get('max_uses', 1)}\n"
    else:
        text += "📭 Hech qanday promokod yo'q\n"

    buttons = [[InlineKeyboardButton(text="➕ Yangi promo", callback_data="adm_promo_new")]]

    # Add delete buttons for each promo
    if promos:
        for p in promos[:5]:
            buttons.append([InlineKeyboardButton(
                text=f"🗑 {p['code']}", callback_data=f"adm_promo_del_{p['code']}"
            )])

    buttons.append([InlineKeyboardButton(text="◀️ Orqaga", callback_data="adm_main")])
    kb = InlineKeyboardMarkup(inline_keyboard=buttons)
    await call.message.edit_text(text, reply_markup=kb)


@router.callback_query(F.data == "adm_promo_new")
async def cb_promo_new(call: CallbackQuery, state: FSMContext):
    if not is_admin(call.from_user.id):
        return
    await state.set_state(AdminStates.waiting_promo_code)
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="❌ Bekor qilish", callback_data="adm_promos")]
    ])
    await call.message.edit_text("🎁 <b>Promokod nomini kiriting:</b>", reply_markup=kb)


@router.message(AdminStates.waiting_promo_code)
async def process_promo_code(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    await state.update_data(promo_code=message.text.strip().upper())
    await state.set_state(AdminStates.waiting_promo_amount)
    await message.answer("💰 <b>Promo miqdori (Stars):</b>")


@router.message(AdminStates.waiting_promo_amount)
async def process_promo_amount(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    try:
        amount = int(message.text.strip())
        if amount <= 0:
            raise ValueError
        await state.update_data(promo_amount=amount)
        await state.set_state(AdminStates.waiting_promo_uses)
        await message.answer("🔢 <b>Nechta foydalanuvchi ishlatishi mumkin?</b>")
    except ValueError:
        await message.answer("❌ Musbat raqam kiriting!")


@router.message(AdminStates.waiting_promo_uses)
async def process_promo_uses(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    try:
        uses = int(message.text.strip())
        if uses <= 0:
            raise ValueError
        data = await state.get_data()
        code = data["promo_code"]
        amount = data["promo_amount"]
        await db.create_promo_code(code, amount, uses)
        await state.clear()
        await message.answer(
            "┏━━━━━━━━━━━━━━━━━━━━━━━┓\n"
            "   ✅ <b>Promo yaratildi!</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            f"🎁 Kod: <code>{code}</code>\n"
            f"💰 Miqdor: {amount} ⭐️\n"
            f"🔢 Limit: {uses} ta"
        )
    except ValueError:
        await message.answer("❌ Musbat raqam kiriting!")


@router.callback_query(F.data.startswith("adm_promo_del_"))
async def cb_promo_delete(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return
    code = call.data[14:]
    await db.delete_promo_code(code)
    await call.answer(f"🗑 {code} o'chirildi!", show_alert=True)
    await cb_admin_promos(call)


# ============== 16. INCOME REPORT ==============

@router.callback_query(F.data == "adm_income")
async def cb_admin_income(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return

    report = await db.get_income_report(30)
    stats = await db.get_subscription_stats()
    total_income = stats.get('total_income', 0)

    text = (
        "┏━━━━━━━━━━━━━━━━━━━━━━━┓\n"
        "    💰 <b>Daromad Hisoboti</b>\n"
        "┗━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
        f"📊 <b>Umumiy:</b> {total_income} ⭐️\n"
        f"📅 <b>Oxirgi 30 kun:</b>\n\n"
    )

    if report:
        for r in report[:15]:
            text += f"📅 {r.get('date', '?')} │ 💰 {r.get('total', 0)}⭐ │ {r.get('count', 0)} ta\n"
    else:
        text += "📭 Hali tranzaksiyalar yo'q\n"

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="◀️ Orqaga", callback_data="adm_main")]
    ])
    await call.message.edit_text(text, reply_markup=kb)


# ============== 17. MANUAL PAYMENT ==============

@router.callback_query(F.data == "adm_manual_pay")
async def cb_manual_payment(call: CallbackQuery, state: FSMContext):
    if not is_admin(call.from_user.id):
        return
    await state.set_state(AdminStates.waiting_manual_payment_user)
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="❌ Bekor qilish", callback_data="adm_main")]
    ])
    await call.message.edit_text(
        "┏━━━━━━━━━━━━━━━━━━━━━━━┓\n"
        "    💳 <b>Manual To'lov</b>\n"
        "┗━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
        "👤 Foydalanuvchi ID sini kiriting:",
        reply_markup=kb
    )


@router.message(AdminStates.waiting_manual_payment_user)
async def process_manual_pay_user(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    try:
        uid = int(message.text.strip())
        user = await db.get_user(uid)
        if not user:
            await message.answer("❌ Foydalanuvchi topilmadi!")
            return
        await state.update_data(pay_uid=uid)
        await state.set_state(AdminStates.waiting_manual_payment_amount)
        await message.answer(f"💰 <b>{uid}</b> ({user.get('username', '—')}) ga qancha Stars?")
    except ValueError:
        await message.answer("❌ Faqat raqam kiriting!")


@router.message(AdminStates.waiting_manual_payment_amount)
async def process_manual_pay_amount(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    try:
        amount = int(message.text.strip())
        if amount <= 0:
            raise ValueError
        data = await state.get_data()
        uid = data["pay_uid"]

        if payment_checker:
            await payment_checker.manual_confirm(message.from_user.id, uid, amount)
        else:
            await db.update_balance(uid, amount, "manual", f"Admin: {amount}⭐")

        await state.clear()
        await message.answer(f"✅ {uid} ga <b>{amount} ⭐️</b> qo'shildi!")
    except ValueError:
        await message.answer("❌ Musbat raqam kiriting!")


# ============== 18. CONFIG VIEW ==============

@router.callback_query(F.data == "adm_config")
async def cb_admin_config(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return

    plans_text = ""
    for i, p in enumerate(config.SERVER_PLANS):
        plans_text += f"   {i+1}. {p['name']}: {p['nvme_gb']}GB/{p['ram_gb']}GB/{p['cpu_count']}CPU — {p['price_stars']}⭐\n"

    text = (
        "┏━━━━━━━━━━━━━━━━━━━━━━━┓\n"
        "    ⚙️ <b>Konfiguratsiya</b>\n"
        "┗━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
        f"🤖 <b>Bot Token:</b> ...{config.BOT_TOKEN[-8:]}\n"
        f"👮 <b>Adminlar:</b> {config.ADMIN_IDS}\n"
        f"📢 <b>Kanal:</b> @{config.FORCE_SUB_CHANNEL}\n"
        f"💰 <b>Gift miqdori:</b> {config.GIFT_AMOUNT}⭐\n"
        f"🎁 <b>Gift akkaunt:</b> @{config.GIFT_ACCOUNT}\n\n"
        f"📦 <b>Planlar:</b>\n{plans_text}"
    )

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="◀️ Orqaga", callback_data="adm_main")]
    ])
    await call.message.edit_text(text, reply_markup=kb)


# ============== 19. WATCHDOG STATUS ==============

@router.callback_query(F.data == "adm_watchdog")
async def cb_admin_watchdog(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return

    running_bots = await db.get_running_userbots()
    text = (
        "┏━━━━━━━━━━━━━━━━━━━━━━━┓\n"
        "    🐕 <b>Watchdog Status</b>\n"
        "┗━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
        f"📡 <b>Running DB records:</b> {len(running_bots)}\n\n"
    )

    for b in running_bots:
        name = b["ub_username"]
        actual = process_manager.is_running(name)
        icon = "🟢" if actual else "🔴 (CRASHED!)"
        text += f"{icon} <code>{name}</code>\n"

    if not running_bots:
        text += "📭 Hech qanday running bot yo'q\n"

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔄 Yangilash", callback_data="adm_watchdog")],
        [InlineKeyboardButton(text="◀️ Orqaga", callback_data="adm_main")]
    ])
    await call.message.edit_text(text, reply_markup=kb)


# ============== 20. BACKUP DATABASE ==============

@router.callback_query(F.data == "adm_backup_db")
async def cb_backup_db(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return

    db_path = "minihost.db"
    if not os.path.exists(db_path):
        await call.answer("❌ DB fayl topilmadi!", show_alert=True)
        return

    backup_name = f"minihost_backup_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.db"
    backup_path = os.path.join("logs", backup_name)
    shutil.copy2(db_path, backup_path)

    doc = FSInputFile(backup_path, filename=backup_name)
    await call.message.answer_document(doc, caption=f"💾 <b>DB Backup:</b> {backup_name}")
    await call.answer("✅ Backup tayyor!", show_alert=True)


# ============== 21. EXPORT USERS CSV ==============

@router.callback_query(F.data == "adm_export")
async def cb_export_csv(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return

    users = await db.get_all_users()
    csv_lines = ["ID,Username,FullName,Balance,Language,Banned,Created"]
    for u in users:
        csv_lines.append(
            f"{u['tg_user_id']},"
            f"{u.get('username', '')},"
            f"\"{u.get('full_name', '')}\","
            f"{u.get('balance', 0)},"
            f"{u.get('language', 'uz')},"
            f"{u.get('is_banned', 0)},"
            f"{str(u.get('created_at', ''))[:10]}"
        )

    csv_content = "\n".join(csv_lines)
    doc = BufferedInputFile(
        csv_content.encode('utf-8'),
        filename=f"users_{datetime.datetime.now().strftime('%Y%m%d')}.csv"
    )
    await call.message.answer_document(doc, caption=f"📤 <b>Users Export:</b> {len(users)} ta")
    await call.answer("✅", show_alert=False)


# ============== 22. SEND NOTIFICATION TO USER ==============

@router.callback_query(F.data == "adm_notify")
async def cb_admin_notify(call: CallbackQuery, state: FSMContext):
    if not is_admin(call.from_user.id):
        return
    await state.set_state(AdminStates.waiting_notify_user_id)
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="❌ Bekor qilish", callback_data="adm_main")]
    ])
    await call.message.edit_text(
        "📩 <b>Xabar yuborish</b>\n\n👤 User ID kiriting:",
        reply_markup=kb
    )


@router.callback_query(F.data.startswith("adm_msg_"))
async def cb_admin_msg_user(call: CallbackQuery, state: FSMContext):
    if not is_admin(call.from_user.id):
        return
    uid = int(call.data[8:])
    await state.update_data(notify_uid=uid)
    await state.set_state(AdminStates.waiting_notify_text)
    await call.message.edit_text(f"📩 <b>{uid}</b> ga xabarni yozing:")


@router.message(AdminStates.waiting_notify_user_id)
async def process_notify_uid(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    try:
        uid = int(message.text.strip())
        await state.update_data(notify_uid=uid)
        await state.set_state(AdminStates.waiting_notify_text)
        await message.answer(f"📩 <b>{uid}</b> ga xabarni yozing:")
    except ValueError:
        await message.answer("❌ Faqat raqam!")


@router.message(AdminStates.waiting_notify_text)
async def process_notify_text(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    data = await state.get_data()
    uid = data.get("notify_uid")
    await state.clear()

    try:
        await message.bot.send_message(
            uid,
            f"📩 <b>Admin xabari:</b>\n\n{message.text}"
        )
        await message.answer(f"✅ Xabar {uid} ga yuborildi!")
    except Exception as e:
        await message.answer(f"❌ Yuborib bo'lmadi: {e}")


# ============== 23. MAINTENANCE MODE ==============

@router.callback_query(F.data == "adm_maintenance")
async def cb_maintenance(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return

    global MAINTENANCE_MODE
    MAINTENANCE_MODE = not MAINTENANCE_MODE
    status = "🔴 YOQILDI" if MAINTENANCE_MODE else "🟢 O'CHIRILDI"
    await call.answer(f"🔧 Maintenance mode {status}", show_alert=True)
    await show_admin_menu(call)


# ============== NAVIGATION ==============

@router.callback_query(F.data == "adm_main")
async def cb_admin_main(call: CallbackQuery, state: FSMContext):
    if not is_admin(call.from_user.id):
        return
    await state.clear()
    await show_admin_menu(call)


@router.callback_query(F.data == "adm_close")
async def cb_admin_close(call: CallbackQuery, state: FSMContext):
    await state.clear()
    await call.message.delete()


@router.callback_query(F.data == "adm_noop")
async def cb_noop(call: CallbackQuery):
    await call.answer()
