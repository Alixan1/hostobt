"""
Localization strings for ARCAI HOST
Supports: Uzbek (uz), Russian (ru), English (en)
Premium animated emojis + sticker IDs throughout
"""
from typing import Dict

# ===== ANIMATED STICKER IDs (from Telegram) =====
STICKERS = {
    "welcome": "CAACAgIAAxkBAAELZ6FnyhBvfWd2IUFnT8e5e2J8yqfn9wACRAADwDZPE86FiRWS4bEeNgQ",        # 👋 Waving hand
    "rocket": "CAACAgIAAxkBAAELZ6NnyhBxK2d0IUFnT8e5e2J8yqfn9wACUQADwDZPE_lLA0G2d9Y-NgQ",         # 🚀 Rocket launch
    "success": "CAACAgIAAxkBAAELZ6VnyhBzK2d0IUFnT8e5e2J8yqfn9wACWAADwDZPE2t3iaQp5ev1NgQ",        # ✅ Green check
    "money": "CAACAgIAAxkBAAELZ6dnyhB1K2d0IUFnT8e5e2J8yqfn9wACYAADwDZPE-gAAZPU0gbrHzYE",          # 💰 Money bag
    "warning": "CAACAgIAAxkBAAELZ6lnyhB3K2d0IUFnT8e5e2J8yqfn9wACagADwDZPEwJXcE6gg9CuNgQ",        # ⚠️ Warning
    "fire": "CAACAgIAAxkBAAELZ6tnyhB5K2d0IUFnT8e5e2J8yqfn9wACeQADwDZPE5I3K7rrJTqBNgQ",           # 🔥 Fire
    "server": "CAACAgIAAxkBAAELZ61nyhB7K2d0IUFnT8e5e2J8yqfn9wACgQADwDZPE4UvnGJc9G3pNgQ",         # 🖥️ Server
    "lightning": "CAACAgIAAxkBAAELZ69nyhB9K2d0IUFnT8e5e2J8yqfn9wACigADwDZPE7pBjglQFOoiNgQ",      # ⚡ Lightning
    "heart": "CAACAgIAAxkBAAELZ7FnyhB_K2d0IUFnT8e5e2J8yqfn9wACkQADwDZPE3VHlBXkfS_FNgQ",          # ❤️ Heart
    "loading": "CAACAgIAAxkBAAELZ7NnyhCBK2d0IUFnT8e5e2J8yqfn9wACmgADwDZPE3cYvvNvMJz1NgQ",        # ⏳ Loading
}

STRINGS = {
    "uz": {
        # Main Menu — Super Premium Design
        "start_caption": (
            "┏━━━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    ✨ <b>𝘼𝙍𝘾𝘼𝙄  𝙃𝙊𝙎𝙏</b> ✨\n"
            "┗━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "👋 Assalomu alaykum, <b>{name}</b>!\n\n"
            "🔥 <b>Premium Userbot Hosting</b>\n"
            "┌─────────────────────┐\n"
            "│  ⚡️ Hikka • Heroku       │\n"
            "│  💎 1 tugma = O'rnatish  │\n"
            "│  🛡 24/7 Himoya            │\n"
            "│  🚀 NVMe SSD Tezlik       │\n"
            "└─────────────────────┘\n\n"
            "💰 <i>Arzon narxlar • Tez server • Auto-restart</i>"
        ),
        "btn_create": "🚀 Yangi Server",
        "btn_my_bots": "🤖 Serverlarim",
        "btn_topup": "💳 Balans +",
        "btn_stats": "📊 Statistika",
        "btn_language": "🌐 Til",
        "btn_manual": "📖 Qo'llanma",
        "btn_back": "◀️ Orqaga",

        # Plans — Premium Cards
        "choose_plan": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    🎯 <b>Server Plan Tanlang</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "💎 Har bir plan o'z resurslariga ega\n"
            "⚡️ <i>NVMe disk | 🧠 RAM | 🖥 CPU</i>"
        ),
        "plan_card": (
            "┌──────────────────┐\n"
            "│ 📦 <b>{name}</b>\n"
            "│ 💾 {nvme}GB NVMe\n"
            "│ 🧠 {ram}GB RAM\n"
            "│ 🖥 {cpu} CPU\n"
            "│ 💰 <b>{price} ⭐️</b>\n"
            "└──────────────────┘"
        ),
        "btn_plan": "📦 {name} — {price}⭐️",

        # Bot Type
        "choose_type": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    🤖 <b>Userbot Turini Tanlang</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "🔥 <b>Hikka</b> — Professional userbot\n"
            "    ├ 📦 300+ modullar\n"
            "    ├ 🔒 Xavfsiz\n"
            "    └ ⚡️ Tez\n\n"
            "⚡️ <b>Heroku</b> — Kuchli va tez\n"
            "    ├ 🌐 Web panel\n"
            "    ├ 🔧 Oson sozlash\n"
            "    └ 💎 Premium"
        ),
        "btn_hikka": "🔥 Hikka",
        "btn_heroku": "⚡️ Heroku",

        # Login Method
        "choose_login": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    🔐 <b>Login Usulini Tanlang</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "📱 <b>API Login</b>\n"
            "    └ API ID + Hash + Telefon\n\n"
            "📷 <b>QR Code</b>\n"
            "    └ Kamera bilan skanerlash"
        ),
        "btn_api_login": "📱 API Login",
        "btn_qr_login": "📷 QR Code",

        # API Login Flow
        "enter_api_id": (
            "🔢 <b>API ID ni kiriting:</b>\n\n"
            "┌─────────────────────┐\n"
            "│ 🌐 my.telegram.org     │\n"
            "│ dan oling                │\n"
            "└─────────────────────┘"
        ),
        "enter_api_hash": "🔑 <b>API Hash ni kiriting:</b>",
        "enter_phone": (
            "📱 <b>Telefon raqamingizni kiriting:</b>\n\n"
            "💡 <i>Masalan: +998901234567</i>"
        ),
        "enter_code": "📨 <b>Telegram kodni kiriting:</b>\n\n<i>Telegramga kelgan tasdiqlash kodi</i>",
        "enter_2fa": "🔒 <b>2FA parolni kiriting:</b>",

        # QR Code
        "qr_scan": (
            "📷 <b>QR Kodni skanerlang:</b>\n\n"
            "1️⃣ Telegram → ⚙️ Sozlamalar → 📱 Qurilmalar\n"
            "2️⃣ «Qurilma qo'shish» tugmasini bosing\n"
            "3️⃣ Yuqoridagi QR kodni skanerlang\n\n"
            "⏳ <i>Kutilmoqda...</i>"
        ),

        # Installation — Animated Progress
        "install_progress": (
            "⏳ <b>O'rnatilmoqda...</b>\n\n"
            "┌─────────────────────┐\n"
            "│ ▓▓▓▓▓▓░░░░░░░░  40%  │\n"
            "│ 📥 Yuklab olinmoqda...  │\n"
            "│ 🔧 Sozlanmoqda...       │\n"
            "└─────────────────────┘\n\n"
            "⏱ <i>Bu 1-3 daqiqa vaqt olishi mumkin</i>"
        ),
        "install_success": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "   ✅ <b>MUVAFFAQIYATLI!</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "🚀 <b>{bot_type}</b> o'rnatildi!\n\n"
            "┌──────────────────┐\n"
            "│ 📦 Plan: <b>{plan}</b>\n"
            "│ 💾 {nvme}GB NVMe\n"
            "│ 🧠 {ram}GB RAM\n"
            "│ 🖥 {cpu} CPU\n"
            "│ 📡 Status: 🟢 Running\n"
            "└──────────────────┘"
        ),
        "install_fail": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "   ❌ <b>XATOLIK!</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "⚠️ O'rnatishda muammo yuz berdi\n"
            "💰 Mablag' qaytarildi"
        ),

        # Balance — Premium
        "balance_text": (
            "┌──────────────────┐\n"
            "│ 💰 Balans: <b>{balance} ⭐️</b>\n"
            "└──────────────────┘"
        ),
        "pay_instruction": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    💳 <b>Balansni To'ldirish</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "📌 <b>Qadamlar:</b>\n\n"
            "1️⃣ Pastdagi tugmani bosing\n"
            "2️⃣ @islomovh ga <b>{amount} ⭐️</b> yuboring\n"
            "3️⃣ Balans avtomatik tushadi!\n\n"
            "⚡️ <i>To'lov darhol tekshiriladi</i>"
        ),
        "btn_send_gift": "🎁 {amount}⭐ Gift Yuborish",
        "payment_received": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "   ✅ <b>TO'LOV QABUL QILINDI!</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "💰 +{amount} ⭐️ balansga tushdi"
        ),
        "payment_waiting": "⏳ <b>To'lov kutilmoqda...</b>\n🎁 {amount} ⭐️ Gift yuboring",

        # Bot Management — Premium Cards
        "my_bots_title": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    🤖 <b>Sizning Serverlaringiz</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛"
        ),
        "no_bots": (
            "📭 Sizda hali server yo'q\n\n"
            "🚀 <b>Birinchi serveringizni yarating!</b>\n"
            "⚡️ <i>1 daqiqada tayyor bo'ladi</i>"
        ),
        "bot_card": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    🤖 <b>{name}</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "┌──────────────────┐\n"
            "│ 📦 Tur: <b>{type}</b>\n"
            "│ 💾 {nvme}GB NVMe\n"
            "│ 🧠 {ram}GB RAM\n"
            "│ 🖥 {cpu} CPU\n"
            "│ 📡 Status: {status}\n"
            "│ 🔐 Login: {login}\n"
            "└──────────────────┘"
        ),
        "btn_start": "▶️ Start",
        "btn_stop": "⏹ Stop",
        "btn_restart": "🔄 Restart",
        "btn_logs": "📜 Logs",
        "btn_backup": "📦 Backup",
        "btn_delete": "🗑 O'chirish",

        # Deletion — Warning Design
        "delete_confirm": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "   ⚠️ <b>DIQQAT!</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "❌ <b>{ub_name}</b> ni o'chirmoqchimisiz?\n\n"
            "⛔️ <i>Bu amalni qaytarib bo'lmaydi!</i>"
        ),
        "btn_confirm_delete": "🗑 Ha, o'chirish",
        "btn_cancel": "❌ Bekor qilish",
        "delete_success": "✅ <b>{ub_name}</b> muvaffaqiyatli o'chirildi!",

        # Promo
        "promo_success": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "   🎉 <b>PROMOKOD FAOL!</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "💰 +{amount} ⭐️ qo'shildi"
        ),
        "promo_used": "❌ Siz bu kodni avval ishlatgansiz!",
        "promo_invalid": "❌ Kod yaroqsiz yoki muddati tugagan",

        # Force Subscribe
        "sub_required": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    📢 <b>Obuna Bo'ling!</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "⚠️ Botdan foydalanish uchun\n"
            "📢 <b>@{channel}</b> ga obuna bo'ling"
        ),
        "btn_sub_check": "✅ Tekshirish",
        "sub_not_found": "❌ Siz hali obuna bo'lmagansiz!",

        # Stats — Dashboard
        "stats_text": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    📊 <b>Sizning Dashboard</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "┌──────────────────┐\n"
            "│ 💰 Balans: <b>{balance} ⭐️</b>\n"
            "│ 🤖 Serverlar: <b>{bots}</b>\n"
            "│ 📅 Ro'yxat: <b>{joined}</b>\n"
            "└──────────────────┘"
        ),

        # Manual — Step by step
        "manual_text": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    📖 <b>ARCAI HOST Qo'llanma</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "📌 <b>Qadamlar:</b>\n\n"
            "1️⃣ Plan tanlang (5-20GB)\n"
            "2️⃣ Hikka yoki Heroku tanlang\n"
            "3️⃣ Serveringiz yaratiladi!\n"
            "4️⃣ Console orqali login qiling\n\n"
            "┌──────────────────┐\n"
            "│ 💳 <b>To'lov:</b>\n"
            "│ 🎁 Admin ga Star Gift\n"
            "│ ⚡️ Auto balans tushadi\n"
            "└──────────────────┘\n\n"
            "🆘 Yordam: @islomovh"
        ),

        # Errors
        "error_insufficient": (
            "❌ <b>Mablag' yetarli emas!</b>\n\n"
            "💰 Kerak: <b>{needed} ⭐️</b>\n"
            "💳 Balans: <b>{balance} ⭐️</b>"
        ),
        "error_generic": "❌ Xatolik yuz berdi",
        "error_max_bots": "❌ Siz maksimal server soniga yetdingiz!",

        # Language
        "lang_selected": "✅ Til o'zgartirildi!",
        "choose_lang": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    🌐 <b>Tilni Tanlang</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛"
        ),
    },

    "ru": {
        "start_caption": (
            "┏━━━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    ✨ <b>𝘼𝙍𝘾𝘼𝙄  𝙃𝙊𝙎𝙏</b> ✨\n"
            "┗━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "👋 Привет, <b>{name}</b>!\n\n"
            "🔥 <b>Премиум Хостинг Юзерботов</b>\n"
            "┌─────────────────────┐\n"
            "│  ⚡️ Hikka • Heroku       │\n"
            "│  💎 Установка в 1 клик   │\n"
            "│  🛡 Защита 24/7           │\n"
            "│  🚀 NVMe SSD скорость    │\n"
            "└─────────────────────┘\n\n"
            "💰 <i>Доступные цены • Быстрые серверы</i>"
        ),
        "btn_create": "🚀 Новый сервер",
        "btn_my_bots": "🤖 Мои серверы",
        "btn_topup": "💳 Пополнить",
        "btn_stats": "📊 Статистика",
        "btn_language": "🌐 Язык",
        "btn_manual": "📖 Инструкция",
        "btn_back": "◀️ Назад",

        "choose_plan": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    🎯 <b>Выберите План</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "💎 Каждый план — уникальные ресурсы\n"
            "⚡️ <i>NVMe | 🧠 RAM | 🖥 CPU</i>"
        ),
        "plan_card": (
            "┌──────────────────┐\n"
            "│ 📦 <b>{name}</b>\n"
            "│ 💾 {nvme}GB NVMe\n"
            "│ 🧠 {ram}GB RAM\n"
            "│ 🖥 {cpu} CPU\n"
            "│ 💰 <b>{price} ⭐️</b>\n"
            "└──────────────────┘"
        ),
        "btn_plan": "📦 {name} — {price}⭐️",

        "choose_type": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    🤖 <b>Тип Юзербота</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "🔥 <b>Hikka</b> — Профессиональный\n"
            "    ├ 📦 300+ модулей\n"
            "    ├ 🔒 Безопасный\n"
            "    └ ⚡️ Быстрый\n\n"
            "⚡️ <b>Heroku</b> — Мощный\n"
            "    ├ 🌐 Веб-панель\n"
            "    ├ 🔧 Легко настроить\n"
            "    └ 💎 Премиум"
        ),
        "btn_hikka": "🔥 Hikka",
        "btn_heroku": "⚡️ Heroku",

        "choose_login": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    🔐 <b>Способ Входа</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "📱 <b>API Login</b>\n"
            "    └ API ID + Hash + Телефон\n\n"
            "📷 <b>QR Code</b>\n"
            "    └ Сканируйте камерой"
        ),
        "btn_api_login": "📱 API Login",
        "btn_qr_login": "📷 QR Code",

        "enter_api_id": (
            "🔢 <b>Введите API ID:</b>\n\n"
            "┌─────────────────────┐\n"
            "│ 🌐 my.telegram.org     │\n"
            "└─────────────────────┘"
        ),
        "enter_api_hash": "🔑 <b>Введите API Hash:</b>",
        "enter_phone": "📱 <b>Введите номер:</b>\n\n💡 <i>+998901234567</i>",
        "enter_code": "📨 <b>Введите код из Telegram:</b>",
        "enter_2fa": "🔒 <b>Введите пароль 2FA:</b>",

        "qr_scan": (
            "📷 <b>Отсканируйте QR код:</b>\n\n"
            "1️⃣ Telegram → ⚙️ → 📱 Устройства\n"
            "2️⃣ «Подключить устройство»\n"
            "3️⃣ Отсканируйте QR\n\n"
            "⏳ <i>Ожидание...</i>"
        ),

        "install_progress": (
            "⏳ <b>Установка...</b>\n\n"
            "┌─────────────────────┐\n"
            "│ ▓▓▓▓▓▓░░░░░░░░  40%  │\n"
            "│ 📥 Загрузка...          │\n"
            "│ 🔧 Настройка...         │\n"
            "└─────────────────────┘\n\n"
            "⏱ <i>1-3 минуты</i>"
        ),
        "install_success": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "   ✅ <b>УСПЕШНО!</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "🚀 <b>{bot_type}</b> установлен!\n\n"
            "┌──────────────────┐\n"
            "│ 📦 План: <b>{plan}</b>\n"
            "│ 💾 {nvme}GB NVMe\n"
            "│ 🧠 {ram}GB RAM\n"
            "│ 🖥 {cpu} CPU\n"
            "│ 📡 Status: 🟢 Running\n"
            "└──────────────────┘"
        ),
        "install_fail": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "   ❌ <b>ОШИБКА!</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "⚠️ Ошибка при установке\n"
            "💰 Средства возвращены"
        ),

        "balance_text": (
            "┌──────────────────┐\n"
            "│ 💰 Баланс: <b>{balance} ⭐️</b>\n"
            "└──────────────────┘"
        ),
        "pay_instruction": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    💳 <b>Пополнение</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "📌 <b>Шаги:</b>\n\n"
            "1️⃣ Нажмите кнопку ниже\n"
            "2️⃣ Отправьте @islomovh <b>{amount} ⭐️</b>\n"
            "3️⃣ Баланс зачислится автоматически!\n\n"
            "⚡️ <i>Мгновенная проверка</i>"
        ),
        "btn_send_gift": "🎁 {amount}⭐ Отправить Gift",
        "payment_received": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "   ✅ <b>ОПЛАТА ПРИНЯТА!</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "💰 +{amount} ⭐️ зачислено"
        ),
        "payment_waiting": "⏳ <b>Ожидание оплаты...</b>\n🎁 Отправьте {amount} ⭐️",

        "my_bots_title": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    🤖 <b>Ваши Серверы</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛"
        ),
        "no_bots": (
            "📭 У вас пока нет серверов\n\n"
            "🚀 <b>Создайте первый!</b>\n"
            "⚡️ <i>Готов за 1 минуту</i>"
        ),
        "bot_card": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    🤖 <b>{name}</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "┌──────────────────┐\n"
            "│ 📦 Тип: <b>{type}</b>\n"
            "│ 💾 {nvme}GB NVMe\n"
            "│ 🧠 {ram}GB RAM\n"
            "│ 🖥 {cpu} CPU\n"
            "│ 📡 Статус: {status}\n"
            "│ 🔐 Вход: {login}\n"
            "└──────────────────┘"
        ),
        "btn_start": "▶️ Запустить",
        "btn_stop": "⏹ Остановить",
        "btn_restart": "🔄 Перезапуск",
        "btn_logs": "📜 Логи",
        "btn_backup": "📦 Бэкап",
        "btn_delete": "🗑 Удалить",

        "delete_confirm": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "   ⚠️ <b>ВНИМАНИЕ!</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "❌ Удалить <b>{ub_name}</b>?\n\n"
            "⛔️ <i>Это действие необратимо!</i>"
        ),
        "btn_confirm_delete": "🗑 Да, удалить",
        "btn_cancel": "❌ Отмена",
        "delete_success": "✅ <b>{ub_name}</b> успешно удалён!",

        "promo_success": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "   🎉 <b>ПРОМОКОД АКТИВИРОВАН!</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "💰 +{amount} ⭐️ добавлено"
        ),
        "promo_used": "❌ Вы уже использовали этот код!",
        "promo_invalid": "❌ Код недействителен",

        "sub_required": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    📢 <b>Подписка</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "⚠️ Подпишитесь на\n"
            "📢 <b>@{channel}</b>"
        ),
        "btn_sub_check": "✅ Проверить",
        "sub_not_found": "❌ Вы ещё не подписаны!",

        "stats_text": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    📊 <b>Ваш Dashboard</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "┌──────────────────┐\n"
            "│ 💰 Баланс: <b>{balance} ⭐️</b>\n"
            "│ 🤖 Серверов: <b>{bots}</b>\n"
            "│ 📅 Регистрация: <b>{joined}</b>\n"
            "└──────────────────┘"
        ),

        "manual_text": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    📖 <b>Инструкция</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "📌 <b>Шаги:</b>\n\n"
            "1️⃣ Выберите план\n"
            "2️⃣ Выберите Hikka/Heroku\n"
            "3️⃣ Сервер создаётся!\n"
            "4️⃣ Войдите через Console\n\n"
            "┌──────────────────┐\n"
            "│ 💳 <b>Оплата:</b>\n"
            "│ 🎁 Star Gift → Админ\n"
            "│ ⚡️ Авто-зачисление\n"
            "└──────────────────┘\n\n"
            "🆘 Поддержка: @islomovh"
        ),

        "error_insufficient": (
            "❌ <b>Недостаточно средств!</b>\n\n"
            "💰 Нужно: <b>{needed} ⭐️</b>\n"
            "💳 Баланс: <b>{balance} ⭐️</b>"
        ),
        "error_generic": "❌ Произошла ошибка",
        "error_max_bots": "❌ Достигнут лимит серверов!",

        "lang_selected": "✅ Язык изменён!",
        "choose_lang": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    🌐 <b>Выберите Язык</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛"
        ),
    },

    "en": {
        "start_caption": (
            "┏━━━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    ✨ <b>𝘼𝙍𝘾𝘼𝙄  𝙃𝙊𝙎𝙏</b> ✨\n"
            "┗━━━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "👋 Hello, <b>{name}</b>!\n\n"
            "🔥 <b>Premium Userbot Hosting</b>\n"
            "┌─────────────────────┐\n"
            "│  ⚡️ Hikka • Heroku       │\n"
            "│  💎 One-Click Deploy     │\n"
            "│  🛡 24/7 Protection       │\n"
            "│  🚀 NVMe SSD Speed       │\n"
            "└─────────────────────┘\n\n"
            "💰 <i>Affordable • Fast servers • Auto-restart</i>"
        ),
        "btn_create": "🚀 New Server",
        "btn_my_bots": "🤖 My Servers",
        "btn_topup": "💳 Top Up",
        "btn_stats": "📊 Statistics",
        "btn_language": "🌐 Language",
        "btn_manual": "📖 Manual",
        "btn_back": "◀️ Back",

        "choose_plan": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    🎯 <b>Choose Your Plan</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "💎 Each plan has unique resources\n"
            "⚡️ <i>NVMe | 🧠 RAM | 🖥 CPU</i>"
        ),
        "plan_card": (
            "┌──────────────────┐\n"
            "│ 📦 <b>{name}</b>\n"
            "│ 💾 {nvme}GB NVMe\n"
            "│ 🧠 {ram}GB RAM\n"
            "│ 🖥 {cpu} CPU\n"
            "│ 💰 <b>{price} ⭐️</b>\n"
            "└──────────────────┘"
        ),
        "btn_plan": "📦 {name} — {price}⭐️",

        "choose_type": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    🤖 <b>Choose Userbot Type</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "🔥 <b>Hikka</b> — Professional\n"
            "    ├ 📦 300+ modules\n"
            "    ├ 🔒 Secure\n"
            "    └ ⚡️ Fast\n\n"
            "⚡️ <b>Heroku</b> — Powerful\n"
            "    ├ 🌐 Web panel\n"
            "    ├ 🔧 Easy setup\n"
            "    └ 💎 Premium"
        ),
        "btn_hikka": "🔥 Hikka",
        "btn_heroku": "⚡️ Heroku",

        "choose_login": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    🔐 <b>Choose Login Method</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "📱 <b>API Login</b>\n"
            "    └ API ID + Hash + Phone\n\n"
            "📷 <b>QR Code</b>\n"
            "    └ Scan with camera"
        ),
        "btn_api_login": "📱 API Login",
        "btn_qr_login": "📷 QR Code",

        "enter_api_id": (
            "🔢 <b>Enter API ID:</b>\n\n"
            "┌─────────────────────┐\n"
            "│ 🌐 my.telegram.org     │\n"
            "└─────────────────────┘"
        ),
        "enter_api_hash": "🔑 <b>Enter API Hash:</b>",
        "enter_phone": "📱 <b>Enter phone number:</b>\n\n💡 <i>Example: +998901234567</i>",
        "enter_code": "📨 <b>Enter Telegram code:</b>",
        "enter_2fa": "🔒 <b>Enter 2FA password:</b>",

        "qr_scan": (
            "📷 <b>Scan QR Code:</b>\n\n"
            "1️⃣ Telegram → ⚙️ → 📱 Devices\n"
            "2️⃣ «Link Desktop Device»\n"
            "3️⃣ Scan QR above\n\n"
            "⏳ <i>Waiting...</i>"
        ),

        "install_progress": (
            "⏳ <b>Installing...</b>\n\n"
            "┌─────────────────────┐\n"
            "│ ▓▓▓▓▓▓░░░░░░░░  40%  │\n"
            "│ 📥 Downloading...       │\n"
            "│ 🔧 Configuring...       │\n"
            "└─────────────────────┘\n\n"
            "⏱ <i>This may take 1-3 minutes</i>"
        ),
        "install_success": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "   ✅ <b>SUCCESS!</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "🚀 <b>{bot_type}</b> installed!\n\n"
            "┌──────────────────┐\n"
            "│ 📦 Plan: <b>{plan}</b>\n"
            "│ 💾 {nvme}GB NVMe\n"
            "│ 🧠 {ram}GB RAM\n"
            "│ 🖥 {cpu} CPU\n"
            "│ 📡 Status: 🟢 Running\n"
            "└──────────────────┘"
        ),
        "install_fail": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "   ❌ <b>ERROR!</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "⚠️ Installation failed\n"
            "💰 Funds refunded"
        ),

        "balance_text": (
            "┌──────────────────┐\n"
            "│ 💰 Balance: <b>{balance} ⭐️</b>\n"
            "└──────────────────┘"
        ),
        "pay_instruction": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    💳 <b>Top Up Balance</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "📌 <b>Steps:</b>\n\n"
            "1️⃣ Tap the button below\n"
            "2️⃣ Send @islomovh <b>{amount} ⭐️</b>\n"
            "3️⃣ Balance added automatically!\n\n"
            "⚡️ <i>Instant verification</i>"
        ),
        "btn_send_gift": "🎁 {amount}⭐ Send Gift",
        "payment_received": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "   ✅ <b>PAYMENT RECEIVED!</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "💰 +{amount} ⭐️ added to balance"
        ),
        "payment_waiting": "⏳ <b>Waiting for payment...</b>\n🎁 Send {amount} ⭐️ Gift",

        "my_bots_title": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    🤖 <b>Your Servers</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛"
        ),
        "no_bots": (
            "📭 You don't have any servers yet\n\n"
            "🚀 <b>Create your first one!</b>\n"
            "⚡️ <i>Ready in 1 minute</i>"
        ),
        "bot_card": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    🤖 <b>{name}</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "┌──────────────────┐\n"
            "│ 📦 Type: <b>{type}</b>\n"
            "│ 💾 {nvme}GB NVMe\n"
            "│ 🧠 {ram}GB RAM\n"
            "│ 🖥 {cpu} CPU\n"
            "│ 📡 Status: {status}\n"
            "│ 🔐 Login: {login}\n"
            "└──────────────────┘"
        ),
        "btn_start": "▶️ Start",
        "btn_stop": "⏹ Stop",
        "btn_restart": "🔄 Restart",
        "btn_logs": "📜 Logs",
        "btn_backup": "📦 Backup",
        "btn_delete": "🗑 Delete",

        "delete_confirm": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "   ⚠️ <b>WARNING!</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "❌ Delete <b>{ub_name}</b>?\n\n"
            "⛔️ <i>This cannot be undone!</i>"
        ),
        "btn_confirm_delete": "🗑 Yes, delete",
        "btn_cancel": "❌ Cancel",
        "delete_success": "✅ <b>{ub_name}</b> deleted successfully!",

        "promo_success": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "   🎉 <b>PROMO ACTIVATED!</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "💰 +{amount} ⭐️ added"
        ),
        "promo_used": "❌ You already used this code!",
        "promo_invalid": "❌ Code is invalid or expired",

        "sub_required": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    📢 <b>Subscribe!</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "⚠️ Please subscribe to\n"
            "📢 <b>@{channel}</b>"
        ),
        "btn_sub_check": "✅ Check",
        "sub_not_found": "❌ You haven't subscribed yet!",

        "stats_text": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    📊 <b>Your Dashboard</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "┌──────────────────┐\n"
            "│ 💰 Balance: <b>{balance} ⭐️</b>\n"
            "│ 🤖 Servers: <b>{bots}</b>\n"
            "│ 📅 Joined: <b>{joined}</b>\n"
            "└──────────────────┘"
        ),

        "manual_text": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    📖 <b>ARCAI HOST Manual</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛\n\n"
            "📌 <b>Steps:</b>\n\n"
            "1️⃣ Choose a plan\n"
            "2️⃣ Select Hikka or Heroku\n"
            "3️⃣ Server is created!\n"
            "4️⃣ Login via Console\n\n"
            "┌──────────────────┐\n"
            "│ 💳 <b>Payment:</b>\n"
            "│ 🎁 Star Gift → Admin\n"
            "│ ⚡️ Auto balance\n"
            "└──────────────────┘\n\n"
            "🆘 Support: @islomovh"
        ),

        "error_insufficient": (
            "❌ <b>Insufficient balance!</b>\n\n"
            "💰 Required: <b>{needed} ⭐️</b>\n"
            "💳 Balance: <b>{balance} ⭐️</b>"
        ),
        "error_generic": "❌ An error occurred",
        "error_max_bots": "❌ Server limit reached!",

        "lang_selected": "✅ Language changed!",
        "choose_lang": (
            "┏━━━━━━━━━━━━━━━━━━━━━┓\n"
            "    🌐 <b>Choose Language</b>\n"
            "┗━━━━━━━━━━━━━━━━━━━━━┛"
        ),
    }
}


def get_text(key: str, lang: str = "uz", **kwargs) -> str:
    """Get localized text by key"""
    lang_dict = STRINGS.get(lang, STRINGS["uz"])
    text = lang_dict.get(key, STRINGS["uz"].get(key, f"[{key}]"))
    if kwargs:
        try:
            text = text.format(**kwargs)
        except (KeyError, IndexError):
            pass
    return text


def get_sticker(name: str) -> str:
    """Get animated sticker file_id by name"""
    return STICKERS.get(name, "")
