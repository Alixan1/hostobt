"""
ARCAI HOST — Payment Checker (Telegram Stars Gift Auto-Detection)
Runs as a background task inside the main bot process.
Monitors incoming gifts to admin account and auto-credits balance.
"""
import asyncio
import logging
import json
from typing import Optional

logger = logging.getLogger("payment_checker")


class PaymentChecker:
    """
    Payment checker that monitors Telegram Stars gifts.
    Integrates with the main bot to auto-detect and process payments.
    
    Usage:
        checker = PaymentChecker(bot, config)
        asyncio.create_task(checker.start_monitoring())
    """

    def __init__(self, bot, config):
        self.bot = bot
        self.config = config
        self.gift_amount = config.GIFT_AMOUNT
        self.admin_ids = config.ADMIN_IDS
        self._running = False

    async def start_monitoring(self):
        """Start the payment monitoring loop"""
        self._running = True
        logger.info(f"💰 Payment checker started (expecting {self.gift_amount}⭐ gifts)")

        # Note: Actual gift monitoring requires Pyrogram/Telethon userbot
        # running on admin's account. For now, we use manual webhook approach.
        # The admin userbot will call process_gift() when a gift is detected.

        while self._running:
            await asyncio.sleep(10)  # Heartbeat

    async def stop_monitoring(self):
        self._running = False
        logger.info("💰 Payment checker stopped")

    async def process_gift(self, sender_id: int, stars_amount: int) -> bool:
        """
        Process a detected gift payment.
        Called by the admin userbot when a Star Gift is received.
        
        Returns True if payment was processed successfully.
        """
        import database as db

        try:
            # Verify user exists
            user = await db.get_user(sender_id)
            if not user:
                logger.warning(f"Gift from unknown user {sender_id}")
                return False

            # Check for pending payment
            pending = await db.get_pending_payment_by_user(sender_id)

            # Add balance
            await db.update_balance(
                sender_id,
                stars_amount,
                "gift",
                f"Star Gift: {stars_amount}⭐"
            )

            # Complete pending payment if exists
            if pending:
                await db.complete_pending_payment(pending["id"])

            # Notify user
            try:
                from locales import get_text
                lang = await db.get_user_language(sender_id)
                await self.bot.send_message(
                    sender_id,
                    get_text("payment_received", lang, amount=stars_amount)
                )
            except Exception as e:
                logger.error(f"Could not notify user {sender_id}: {e}")

            # Notify admin
            for admin_id in self.admin_ids:
                try:
                    await self.bot.send_message(
                        admin_id,
                        f"💰 <b>To'lov qabul qilindi!</b>\n\n"
                        f"👤 User: {sender_id}\n"
                        f"⭐ Miqdor: {stars_amount} Stars\n"
                        f"💎 Yangi balans: {user['balance'] + stars_amount}"
                    )
                except:
                    pass

            logger.info(f"✅ Gift processed: {sender_id} -> {stars_amount}⭐")
            return True

        except Exception as e:
            logger.error(f"Error processing gift: {e}")
            return False

    async def manual_confirm(self, admin_id: int, user_id: int, amount: int) -> bool:
        """
        Manual payment confirmation by admin.
        Used when auto-detection doesn't work.
        """
        import database as db

        try:
            await db.update_balance(user_id, amount, "manual", f"Admin confirmed: {amount}⭐")

            # Notify user
            try:
                from locales import get_text
                lang = await db.get_user_language(user_id)
                await self.bot.send_message(
                    user_id,
                    get_text("payment_received", lang, amount=amount)
                )
            except:
                pass

            logger.info(f"✅ Manual payment: admin {admin_id} -> user {user_id}: {amount}⭐")
            return True
        except Exception as e:
            logger.error(f"Error in manual confirm: {e}")
            return False


# Global instance (initialized in bot.py)
payment_checker: Optional[PaymentChecker] = None
