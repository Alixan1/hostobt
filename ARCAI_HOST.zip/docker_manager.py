import asyncio
import aiofiles
import logging
from typing import Dict, Any, Optional, List
from config_manager import config

logger = logging.getLogger(__name__)

class DockerManager:
    def __init__(self):
        self.defaults = {
            "ram_limit": "512m",
            "cpu_limit": "1.0",
            "restart_policy": "unless-stopped"
        }
        self.docker_exe = self._Find_docker_executable()

    def _Find_docker_executable(self) -> str:
        """Tries to find docker executable in PATH or common locations."""
        import shutil
        import os
        
        # 1. Check PATH
        if shutil.which("docker"):
            return "docker"
            
        # 2. Check Common Windows Path
        common_path = r"C:\Program Files\Docker\Docker\resources\bin\docker.exe"
        if os.path.exists(common_path):
            logger.info(f"Docker found at: {common_path}")
            return f'"{common_path}"' # Quote it for shell execution
            
        return "docker" # Default fallback

    async def _run_cmd(self, cmd: str) -> Dict[str, Any]:
        """Runs a shell command asynchronously and returns output/error."""
        if config._config.get("dev_mode"):
            logger.info(f"[MOCK] Executing: {cmd}")
            return {"success": True, "output": "MOCK_OUTPUT", "error": "", "code": 0}

        # Replace 'docker ' with the actual executable if it starts with docker
        # But wait, cmd is full string.
        # We should construct cmd properly in methods, OR replace here.
        # Simple string replace might be dangerous if 'docker' appears elsewhere.
        # However, our commands always start with 'docker '.
        
        if cmd.startswith("docker "):
            cmd = f"{self.docker_exe} {cmd[7:]}"
            
        logger.debug(f"Executing: {cmd}")
        process = await asyncio.create_subprocess_shell(
            cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await process.communicate()
        
        return {
            "success": process.returncode == 0,
            "output": stdout.decode(errors='replace').strip(),
            "error": stderr.decode(errors='replace').strip(),
            "code": process.returncode
        }

    async def check_docker_availability(self) -> bool:
        if config._config.get("dev_mode"):
            logger.info("Running in DEV MODE (Mock Docker)")
            return True

        # Use self.docker_exe explicitly
        res = await self._run_cmd(f"docker --version")
        if not res['success']:
            # Double check with literal command if _run_cmd replace logic failed?
            # No, _run_cmd handles the replacement.
            logger.critical("Docker not found! Please install Docker.")
            return False
        return True

    async def create_custom_container(self, name: str, port: int, command: str) -> Dict[str, Any]:
        if config._config.get("dev_mode"):
            return {"success": True, "data": {"id": "mock_container_id"}}
            
        volume_path = f"$(pwd)/userbots/{name}"
        web_port_map = f"-p {port}:8080" # Map host port to 8080 internally
        
        # Using python:3.10-slim-buster as base
        # Note: We use 'docker' string here, relying on _run_cmd to replace it
        docker_cmd = (
            f"docker run -d --name {name} "
            f"--memory={self.defaults['ram_limit']} "
            f"--cpus={self.defaults['cpu_limit']} "
            f"--restart={self.defaults['restart_policy']} "
            f"-v {volume_path}:/data "
            f"{web_port_map} "
            f"python:3.10-slim-buster {command}"
        )
        
        logger.info(f"Creating container '{name}' with custom command")
        return await self._run_cmd(docker_cmd)

    async def get_container_stats(self, name: str) -> Dict[str, Any]:
        if config._config.get("dev_mode"):
            import random
            return {
                "cpu": f"{random.uniform(0.1, 5.0):.2f}%",
                "memory": f"{random.randint(50, 200)}MiB",
                "network": f"{random.randint(1, 10)}MB / {random.randint(1, 10)}MB",
                "status": "running (mock)"
            }

        cmd = 'docker stats --no-stream --format "{{.CPUPerc}}|{{.MemUsage}}|{{.NetIO}}" ' + name
        res = await self._run_cmd(cmd)
        
        if not res['success']:
            return {"error": res['error']}
            
        try:
            cpu, mem, net = res['output'].split('|')
            return {
                "cpu": cpu,
                "memory": mem,
                "network": net,
                "status": "running"
            }
        except ValueError:
            return {"status": "stopped", "error": "Could not parse stats"}

    async def manage_container(self, name: str, action: str) -> Dict[str, Any]:
        if config._config.get("dev_mode"):
            return {"success": True, "output": f"Mock action {action} on {name}"}

        valid_actions = ["stop", "start", "restart", "rm -f"]
        if action not in valid_actions and f"rm -f" not in action: 
             if action == "remove": action = "rm -f"
             else: return {"success": False, "error": "Invalid action"}
        
        cmd = f"docker {action} {name}"
        logger.info(f"Docker action '{action}' on '{name}'")
        return await self._run_cmd(cmd)

    async def get_logs(self, name: str, lines: int = 100) -> str:
        if config._config.get("dev_mode"):
            return f"[MOCK LOGS] Container {name} is running fine.\nUserbot started.\nConnected to Telegram."

        res = await self._run_cmd(f"docker logs --tail {lines} {name}")
        return res['output'] + "\n" + res['error']

docker_manager = DockerManager()
