"""
ARCAI HOST — Professional User Handlers
Features: Server plans, Hikka/Heroku, API/QR login, auto payment, animated emoji
"""
from aiogram import Router, F, types
from aiogram.filters import Command, CommandStart, CommandObject
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, FSInputFile
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
import database as db
from config_manager import config
from locales import get_text
from bot_installer import installer
from process_manager import process_manager
from backup_manager import backup_manager
import os
import logging

logger = logging.getLogger(__name__)

router = Router()

FORCE_SUB_CHANNEL = config.FORCE_SUB_CHANNEL
BANNER_PATH = os.path.join(os.path.dirname(__file__), "assets", "banner.jpg")


class UserStates(StatesGroup):
    choosing_plan = State()
    choosing_type = State()
    choosing_login = State()
    # API Login
    waiting_api_id = State()
    waiting_api_hash = State()
    waiting_phone = State()
    waiting_code = State()
    waiting_2fa = State()
    # QR Code
    waiting_qr_scan = State()
    # Delete
    waiting_delete_confirm = State()


# ============== MIDDLEWARE: BAN CHECK ==============

@router.message.middleware()
async def ban_check_middleware(handler, event: Message, data):
    if event.from_user:
        if await db.is_user_banned(event.from_user.id):
            return
    return await handler(event, data)


@router.callback_query.middleware()
async def ban_check_callback_middleware(handler, event: CallbackQuery, data):
    if event.from_user:
        if await db.is_user_banned(event.from_user.id):
            await event.answer("🚫 Siz bloklangansiz!", show_alert=True)
            return
    return await handler(event, data)


# ============== FORCE SUBSCRIPTION ==============

async def check_subscription(bot, user_id: int) -> bool:
    try:
        member = await bot.get_chat_member(f"@{FORCE_SUB_CHANNEL}", user_id)
        return member.status in ["creator", "administrator", "member"]
    except Exception:
        return True  # If check fails, allow access


async def show_subscription_required(message: Message, lang: str = "uz"):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"📢 @{FORCE_SUB_CHANNEL}", url=f"https://t.me/{FORCE_SUB_CHANNEL}")],
        [InlineKeyboardButton(text=get_text("btn_sub_check", lang), callback_data="check_sub")]
    ])
    await message.answer(get_text("sub_required", lang, channel=FORCE_SUB_CHANNEL), reply_markup=kb)


# ============== MAIN MENU ==============

def get_main_keyboard(lang: str = "uz") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_text("btn_create", lang), callback_data="create_new")],
        [InlineKeyboardButton(text=get_text("btn_my_bots", lang), callback_data="my_bots")],
        [
            InlineKeyboardButton(text=get_text("btn_topup", lang), callback_data="topup"),
            InlineKeyboardButton(text=get_text("btn_stats", lang), callback_data="stats")
        ],
        [
            InlineKeyboardButton(text=get_text("btn_language", lang), callback_data="ask_lang"),
            InlineKeyboardButton(text=get_text("btn_manual", lang), callback_data="manual")
        ]
    ])


@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext):
    await state.clear()
    user = message.from_user
    await db.add_user(user.id, user.username or "", user.full_name or "")
    lang = await db.get_user_language(user.id)

    # Check subscription
    if not await check_subscription(message.bot, user.id):
        await show_subscription_required(message, lang)
        return

    # Send banner image with caption
    caption = get_text("start_caption", lang, name=user.full_name or user.first_name)
    kb = get_main_keyboard(lang)

    try:
        if os.path.exists(BANNER_PATH):
            photo = FSInputFile(BANNER_PATH)
            await message.answer_photo(photo=photo, caption=caption, reply_markup=kb)
        else:
            await message.answer(caption, reply_markup=kb)
    except Exception as e:
        logger.error(f"Error sending banner: {e}")
        await message.answer(caption, reply_markup=kb)


async def show_main_menu(call_or_msg, lang: str = "uz", name: str = ""):
    caption = get_text("start_caption", lang, name=name)
    kb = get_main_keyboard(lang)
    if isinstance(call_or_msg, CallbackQuery):
        try:
            await call_or_msg.message.edit_caption(caption=caption, reply_markup=kb)
        except:
            try:
                await call_or_msg.message.edit_text(caption, reply_markup=kb)
            except:
                await call_or_msg.message.answer(caption, reply_markup=kb)
    else:
        await call_or_msg.answer(caption, reply_markup=kb)


@router.callback_query(F.data == "check_sub")
async def cb_check_sub(call: CallbackQuery):
    lang = await db.get_user_language(call.from_user.id)
    if await check_subscription(call.bot, call.from_user.id):
        await call.answer("✅")
        await show_main_menu(call, lang, call.from_user.full_name)
    else:
        await call.answer(get_text("sub_not_found", lang), show_alert=True)


@router.callback_query(F.data == "main_menu")
async def cb_main_menu(call: CallbackQuery, state: FSMContext):
    await state.clear()
    lang = await db.get_user_language(call.from_user.id)
    await show_main_menu(call, lang, call.from_user.full_name)


# ============== LANGUAGE ==============

@router.callback_query(F.data == "ask_lang")
async def cb_ask_lang(call: CallbackQuery):
    lang = await db.get_user_language(call.from_user.id)
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🇺🇿 O'zbekcha", callback_data="set_lang_uz"),
            InlineKeyboardButton(text="🇷🇺 Русский", callback_data="set_lang_ru"),
        ],
        [InlineKeyboardButton(text="🇬🇧 English", callback_data="set_lang_en")],
        [InlineKeyboardButton(text=get_text("btn_back", lang), callback_data="main_menu")]
    ])
    try:
        await call.message.edit_caption(caption=get_text("choose_lang", lang), reply_markup=kb)
    except:
        await call.message.edit_text(get_text("choose_lang", lang), reply_markup=kb)


@router.callback_query(F.data.startswith("set_lang_"))
async def cb_set_lang(call: CallbackQuery):
    new_lang = call.data.split("_")[-1]
    await db.set_user_language(call.from_user.id, new_lang)
    await call.answer(get_text("lang_selected", new_lang))
    await show_main_menu(call, new_lang, call.from_user.full_name)


# ============== TOPUP / PAYMENT ==============

@router.callback_query(F.data == "topup")
async def cb_topup(call: CallbackQuery):
    lang = await db.get_user_language(call.from_user.id)
    balance = await db.get_user_balance(call.from_user.id)
    amount = config.GIFT_AMOUNT

    text = get_text("balance_text", lang, balance=balance) + "\n\n" + get_text("pay_instruction", lang, amount=amount)

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_text("btn_send_gift", lang, amount=amount), url=f"https://t.me/{FORCE_SUB_CHANNEL}")],
        [InlineKeyboardButton(text=get_text("btn_back", lang), callback_data="main_menu")]
    ])
    try:
        await call.message.edit_caption(caption=text, reply_markup=kb)
    except:
        await call.message.edit_text(text, reply_markup=kb)


# ============== CREATE SERVER ==============

@router.callback_query(F.data == "create_new")
async def cb_create_new(call: CallbackQuery, state: FSMContext):
    lang = await db.get_user_language(call.from_user.id)

    # Show plan selection
    plans = config.SERVER_PLANS
    if not plans:
        await call.answer("⚠️ Planlar sozlanmagan!", show_alert=True)
        return

    buttons = []
    for i, plan in enumerate(plans):
        btn_text = get_text("btn_plan", lang, name=plan["name"], price=plan["price_stars"])
        buttons.append([InlineKeyboardButton(text=btn_text, callback_data=f"select_plan_{i}")])

    buttons.append([InlineKeyboardButton(text=get_text("btn_back", lang), callback_data="main_menu")])
    kb = InlineKeyboardMarkup(inline_keyboard=buttons)

    text = get_text("choose_plan", lang)
    # Show plan details
    for plan in plans:
        text += "\n\n" + get_text("plan_card", lang,
                                   name=plan["name"], nvme=plan["nvme_gb"],
                                   ram=plan["ram_gb"], cpu=plan["cpu_count"],
                                   price=plan["price_stars"])

    try:
        await call.message.edit_caption(caption=text, reply_markup=kb)
    except:
        await call.message.edit_text(text, reply_markup=kb)

    await state.set_state(UserStates.choosing_plan)


@router.callback_query(F.data.startswith("select_plan_"))
async def cb_select_plan(call: CallbackQuery, state: FSMContext):
    lang = await db.get_user_language(call.from_user.id)
    plan_idx = int(call.data.split("_")[-1])
    plan = config.get_plan(plan_idx)

    if not plan:
        await call.answer("❌ Plan topilmadi!", show_alert=True)
        return

    # Check balance
    balance = await db.get_user_balance(call.from_user.id)
    if balance < plan["price_stars"]:
        await call.answer(
            get_text("error_insufficient", lang, needed=plan["price_stars"], balance=balance),
            show_alert=True
        )
        return

    await state.update_data(plan_idx=plan_idx, plan=plan)
    await state.set_state(UserStates.choosing_type)

    # Show bot type selection
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_text("btn_hikka", lang), callback_data="type_hikka")],
        [InlineKeyboardButton(text=get_text("btn_heroku", lang), callback_data="type_heroku")],
        [InlineKeyboardButton(text=get_text("btn_back", lang), callback_data="create_new")]
    ])

    try:
        await call.message.edit_caption(caption=get_text("choose_type", lang), reply_markup=kb)
    except:
        await call.message.edit_text(get_text("choose_type", lang), reply_markup=kb)


@router.callback_query(F.data.startswith("type_"))
async def cb_select_type(call: CallbackQuery, state: FSMContext):
    lang = await db.get_user_language(call.from_user.id)
    bot_type = call.data.split("_")[-1]  # hikka or heroku
    await state.update_data(bot_type=bot_type)
    await state.set_state(UserStates.choosing_login)

    # Show login method selection
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_text("btn_api_login", lang), callback_data="login_api")],
        [InlineKeyboardButton(text=get_text("btn_qr_login", lang), callback_data="login_qr")],
        [InlineKeyboardButton(text=get_text("btn_back", lang), callback_data="create_new")]
    ])

    try:
        await call.message.edit_caption(caption=get_text("choose_login", lang), reply_markup=kb)
    except:
        await call.message.edit_text(get_text("choose_login", lang), reply_markup=kb)


# ============== API LOGIN FLOW ==============

@router.callback_query(F.data == "login_api")
async def cb_login_api(call: CallbackQuery, state: FSMContext):
    lang = await db.get_user_language(call.from_user.id)
    await state.update_data(login_type="api")
    await state.set_state(UserStates.waiting_api_id)

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_text("btn_cancel", lang), callback_data="main_menu")]
    ])

    try:
        await call.message.edit_caption(caption=get_text("enter_api_id", lang), reply_markup=kb)
    except:
        await call.message.edit_text(get_text("enter_api_id", lang), reply_markup=kb)


@router.message(UserStates.waiting_api_id)
async def process_api_id(message: Message, state: FSMContext):
    lang = await db.get_user_language(message.from_user.id)
    try:
        api_id = int(message.text.strip())
        await state.update_data(user_api_id=api_id)
        await state.set_state(UserStates.waiting_api_hash)
        await message.answer(get_text("enter_api_hash", lang))
    except ValueError:
        await message.answer("❌ API ID faqat raqam bo'lishi kerak!")


@router.message(UserStates.waiting_api_hash)
async def process_api_hash(message: Message, state: FSMContext):
    lang = await db.get_user_language(message.from_user.id)
    api_hash = message.text.strip()
    if len(api_hash) < 10:
        await message.answer("❌ API Hash noto'g'ri!")
        return
    await state.update_data(user_api_hash=api_hash)
    await state.set_state(UserStates.waiting_phone)
    await message.answer(get_text("enter_phone", lang))


@router.message(UserStates.waiting_phone)
async def process_phone(message: Message, state: FSMContext):
    lang = await db.get_user_language(message.from_user.id)
    phone = message.text.strip()
    if not phone.startswith("+") or len(phone) < 10:
        await message.answer("❌ Telefon raqam noto'g'ri! (+998...)")
        return

    await state.update_data(phone=phone)

    # Start installation with collected credentials
    data = await state.get_data()
    await start_installation(message, state, data, lang)


# ============== QR CODE LOGIN ==============

@router.callback_query(F.data == "login_qr")
async def cb_login_qr(call: CallbackQuery, state: FSMContext):
    lang = await db.get_user_language(call.from_user.id)
    await state.update_data(login_type="qr")

    # Start installation with QR code method
    data = await state.get_data()
    await start_installation(call.message, state, data, lang, is_callback=True)


# ============== INSTALLATION ==============

async def start_installation(message: Message, state: FSMContext, data: dict, lang: str, is_callback: bool = False):
    """Start the actual userbot installation"""
    plan = data.get("plan", {})
    bot_type = data.get("bot_type", "hikka")
    login_type = data.get("login_type", "api")
    user_id = message.chat.id if is_callback else message.from_user.id

    # Deduct balance
    price = plan.get("price_stars", 0)
    balance = await db.get_user_balance(user_id)
    if balance < price:
        await message.answer(get_text("error_insufficient", lang, needed=price, balance=balance))
        await state.clear()
        return

    # Send progress message
    progress_msg = await message.answer(get_text("install_progress", lang))

    # Generate unique name and port
    import time
    ub_name = f"ub_{user_id}_{int(time.time()) % 10000}"
    port = await db.generate_random_port()

    try:
        # Deduct balance
        await db.update_balance(user_id, -price, "purchase",
                                f"{bot_type.title()} server: {plan.get('name', 'Unknown')}")

        # Install userbot
        success = await installer.install_userbot(ub_name, port, bot_type)

        if success:
            # Record in database
            await db.add_userbot_record(
                tg_user_id=user_id,
                ub_username=ub_name,
                ub_type=bot_type,
                port=port,
                plan_id=data.get("plan_idx", 0),
                login_type=login_type,
                nvme_gb=plan.get("nvme_gb", 5),
                ram_gb=plan.get("ram_gb", 1),
                cpu_count=plan.get("cpu_count", 1)
            )
            await db.update_userbot_status(ub_name, "running")

            kb = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text=get_text("btn_my_bots", lang), callback_data="my_bots")],
                [InlineKeyboardButton(text=get_text("btn_back", lang), callback_data="main_menu")]
            ])

            await progress_msg.edit_text(
                get_text("install_success", lang,
                         bot_type=bot_type.title(),
                         plan=plan.get("name", ""),
                         nvme=plan.get("nvme_gb", 5),
                         ram=plan.get("ram_gb", 1),
                         cpu=plan.get("cpu_count", 1)),
                reply_markup=kb
            )
        else:
            # Refund
            await db.update_balance(user_id, price, "refund", f"Failed: {bot_type}")
            await progress_msg.edit_text(get_text("install_fail", lang))

    except Exception as e:
        logger.error(f"Installation error: {e}")
        await db.update_balance(user_id, price, "refund", f"Error: {str(e)[:50]}")
        await progress_msg.edit_text(get_text("install_fail", lang))

    await state.clear()


# ============== MY BOTS ==============

@router.callback_query(F.data == "my_bots")
async def cb_my_bots(call: CallbackQuery):
    lang = await db.get_user_language(call.from_user.id)
    bots = await db.get_userbots_by_tg_id(call.from_user.id)

    if not bots:
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text=get_text("btn_create", lang), callback_data="create_new")],
            [InlineKeyboardButton(text=get_text("btn_back", lang), callback_data="main_menu")]
        ])
        try:
            await call.message.edit_caption(caption=get_text("no_bots", lang), reply_markup=kb)
        except:
            await call.message.edit_text(get_text("no_bots", lang), reply_markup=kb)
        return

    buttons = []
    for bot in bots:
        status_icon = "🟢" if bot.get("status") == "running" else "🔴"
        btn_text = f"{status_icon} {bot['ub_username']} ({bot['ub_type']})"
        buttons.append([InlineKeyboardButton(text=btn_text, callback_data=f"manage_{bot['ub_username']}")])

    buttons.append([InlineKeyboardButton(text=get_text("btn_back", lang), callback_data="main_menu")])
    kb = InlineKeyboardMarkup(inline_keyboard=buttons)

    try:
        await call.message.edit_caption(caption=get_text("my_bots_title", lang), reply_markup=kb)
    except:
        await call.message.edit_text(get_text("my_bots_title", lang), reply_markup=kb)


@router.callback_query(F.data.startswith("manage_"))
async def cb_manage_bot(call: CallbackQuery):
    lang = await db.get_user_language(call.from_user.id)
    ub_name = call.data[7:]  # Remove "manage_"
    bot_data = await db.get_userbot_data(ub_name)

    if not bot_data:
        await call.answer("❌ Server topilmadi!", show_alert=True)
        return

    # Check ownership
    if bot_data["tg_user_id"] != call.from_user.id:
        await call.answer("🚫 Bu sizning serveringiz emas!", show_alert=True)
        return

    status_text = "🟢 Ishlayapti" if bot_data.get("status") == "running" else "🔴 To'xtatilgan"
    login_text = "📱 API" if bot_data.get("login_type") == "api" else "📷 QR"

    text = get_text("bot_card", lang,
                     name=ub_name,
                     type=bot_data.get("ub_type", "hikka").title(),
                     nvme=bot_data.get("nvme_gb", 5),
                     ram=bot_data.get("ram_gb", 1),
                     cpu=bot_data.get("cpu_count", 1),
                     status=status_text,
                     login=login_text)

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text=get_text("btn_start", lang), callback_data=f"ctl_start_{ub_name}"),
            InlineKeyboardButton(text=get_text("btn_stop", lang), callback_data=f"ctl_stop_{ub_name}"),
        ],
        [
            InlineKeyboardButton(text=get_text("btn_restart", lang), callback_data=f"ctl_restart_{ub_name}"),
            InlineKeyboardButton(text=get_text("btn_logs", lang), callback_data=f"ctl_logs_{ub_name}"),
        ],
        [
            InlineKeyboardButton(text=get_text("btn_backup", lang), callback_data=f"ctl_backup_{ub_name}"),
            InlineKeyboardButton(text=get_text("btn_delete", lang), callback_data=f"ctl_delete_{ub_name}"),
        ],
        [InlineKeyboardButton(text=get_text("btn_back", lang), callback_data="my_bots")]
    ])

    try:
        await call.message.edit_caption(caption=text, reply_markup=kb)
    except:
        await call.message.edit_text(text, reply_markup=kb)


# ============== BOT CONTROLS ==============

@router.callback_query(F.data.startswith("ctl_start_"))
async def cb_control_start(call: CallbackQuery):
    ub_name = call.data[10:]
    try:
        success = await process_manager.start_process_from_saved(ub_name)
        if success:
            await db.update_userbot_status(ub_name, "running")
            await call.answer("▶️ Server ishga tushirildi!", show_alert=True)
        else:
            await call.answer("❌ Ishga tushirib bo'lmadi!", show_alert=True)
    except Exception as e:
        await call.answer(f"❌ Xato: {str(e)[:50]}", show_alert=True)


@router.callback_query(F.data.startswith("ctl_stop_"))
async def cb_control_stop(call: CallbackQuery):
    ub_name = call.data[9:]
    await process_manager.stop_process(ub_name)
    await db.update_userbot_status(ub_name, "stopped")
    await call.answer("⏹ Server to'xtatildi!", show_alert=True)


@router.callback_query(F.data.startswith("ctl_restart_"))
async def cb_control_restart(call: CallbackQuery):
    ub_name = call.data[12:]
    await process_manager.stop_process(ub_name)
    success = await process_manager.start_process_from_saved(ub_name)
    if success:
        await db.update_userbot_status(ub_name, "running")
        await call.answer("🔄 Server qayta ishga tushirildi!", show_alert=True)
    else:
        await call.answer("❌ Qayta ishga tushirib bo'lmadi!", show_alert=True)


@router.callback_query(F.data.startswith("ctl_logs_"))
async def cb_control_logs(call: CallbackQuery):
    ub_name = call.data[9:]
    lang = await db.get_user_language(call.from_user.id)

    logs = await process_manager.get_logs(ub_name, lines=50)
    if len(logs) > 3500:
        logs = logs[-3500:]

    text = f"📜 <b>Loglar — {ub_name}</b>\n\n<pre>{logs}</pre>"
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_text("btn_back", lang), callback_data=f"manage_{ub_name}")]
    ])

    try:
        await call.message.edit_text(text, reply_markup=kb)
    except Exception:
        # If text too long, send as file
        try:
            await call.message.answer(text[:4000], reply_markup=kb)
        except:
            await call.message.answer("📜 Loglar juda uzun. Qisqartirildi.", reply_markup=kb)


@router.callback_query(F.data.startswith("ctl_backup_"))
async def cb_backup(call: CallbackQuery):
    ub_name = call.data[11:]
    lang = await db.get_user_language(call.from_user.id)

    await call.answer("📦 Backup tayyorlanmoqda...", show_alert=True)
    try:
        backup_path = await backup_manager.create_backup(ub_name)
        if backup_path and os.path.exists(backup_path):
            doc = FSInputFile(backup_path, filename=f"{ub_name}_backup.zip")
            await call.message.answer_document(doc, caption=f"📦 <b>{ub_name}</b> backup tayyor!")
        else:
            await call.message.answer("❌ Backup yaratib bo'lmadi!")
    except Exception as e:
        await call.message.answer(f"❌ Xatolik: {str(e)[:100]}")


@router.callback_query(F.data.startswith("ctl_delete_"))
async def cb_delete_confirm(call: CallbackQuery):
    ub_name = call.data[11:]
    lang = await db.get_user_language(call.from_user.id)

    text = get_text("delete_confirm", lang, ub_name=ub_name)
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_text("btn_confirm_delete", lang), callback_data=f"confirm_del_{ub_name}")],
        [InlineKeyboardButton(text=get_text("btn_cancel", lang), callback_data=f"manage_{ub_name}")]
    ])

    try:
        await call.message.edit_caption(caption=text, reply_markup=kb)
    except:
        await call.message.edit_text(text, reply_markup=kb)


@router.callback_query(F.data.startswith("confirm_del_"))
async def cb_delete_userbot(call: CallbackQuery):
    ub_name = call.data[12:]
    lang = await db.get_user_language(call.from_user.id)
    bot_data = await db.get_userbot_data(ub_name)

    if not bot_data or bot_data["tg_user_id"] != call.from_user.id:
        await call.answer("🚫 Ruxsat yo'q!", show_alert=True)
        return

    # Delete
    await installer.delete_userbot(ub_name)
    await db.delete_userbot_record(ub_name)

    await call.answer(get_text("delete_success", lang, ub_name=ub_name), show_alert=True)

    # Return to bots list
    lang = await db.get_user_language(call.from_user.id)
    await show_main_menu(call, lang, call.from_user.full_name)


# ============== STATS ==============

@router.callback_query(F.data == "stats")
async def cb_stats(call: CallbackQuery):
    lang = await db.get_user_language(call.from_user.id)
    user = await db.get_user(call.from_user.id)
    bots = await db.get_userbots_by_tg_id(call.from_user.id)

    joined = user.get("created_at", "N/A")[:10] if user else "N/A"

    text = get_text("stats_text", lang,
                     balance=user.get("balance", 0) if user else 0,
                     bots=len(bots),
                     joined=joined)

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_text("btn_back", lang), callback_data="main_menu")]
    ])

    try:
        await call.message.edit_caption(caption=text, reply_markup=kb)
    except:
        await call.message.edit_text(text, reply_markup=kb)


# ============== MANUAL ==============

@router.callback_query(F.data == "manual")
async def cb_manual(call: CallbackQuery):
    lang = await db.get_user_language(call.from_user.id)
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=get_text("btn_back", lang), callback_data="main_menu")]
    ])
    try:
        await call.message.edit_caption(caption=get_text("manual_text", lang), reply_markup=kb)
    except:
        await call.message.edit_text(get_text("manual_text", lang), reply_markup=kb)


# ============== PROMO CODE ==============

@router.message(Command("promo"))
async def cmd_promo(message: Message, command: CommandObject):
    lang = await db.get_user_language(message.from_user.id)

    if not command.args:
        await message.answer("📝 Foydalanish: /promo <kod>")
        return

    code = command.args.strip()
    result = await db.redeem_promo_code(message.from_user.id, code)

    if result > 0:
        await message.answer(get_text("promo_success", lang, amount=result))
    elif result == -1:
        await message.answer(get_text("promo_used", lang))
    else:
        await message.answer(get_text("promo_invalid", lang))
