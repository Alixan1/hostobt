import aiosqlite
import asyncio
import logging
from typing import Dict, Any, List, Optional
import datetime
import os

logger = logging.getLogger(__name__)

DB_NAME = "minihost.db"


async def init_db():
    """Initialize database with all tables"""
    async with aiosqlite.connect(DB_NAME) as db:
        # Users table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                tg_user_id INTEGER PRIMARY KEY,
                username TEXT,
                full_name TEXT,
                balance INTEGER DEFAULT 0,
                language TEXT DEFAULT 'uz',
                is_banned INTEGER DEFAULT 0,
                selected_plan_id INTEGER DEFAULT -1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Userbots table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS userbots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tg_user_id INTEGER,
                ub_username TEXT UNIQUE,
                ub_type TEXT DEFAULT 'hikka',
                port INTEGER,
                status TEXT DEFAULT 'stopped',
                plan_id INTEGER DEFAULT 0,
                login_type TEXT DEFAULT 'api',
                nvme_gb INTEGER DEFAULT 5,
                ram_gb INTEGER DEFAULT 1,
                cpu_count INTEGER DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (tg_user_id) REFERENCES users(tg_user_id)
            )
        """)

        # Transactions table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tg_user_id INTEGER,
                amount INTEGER,
                type TEXT,
                description TEXT,
                charge_id TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (tg_user_id) REFERENCES users(tg_user_id)
            )
        """)

        # Promo codes table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS promo_codes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                code TEXT UNIQUE,
                amount INTEGER,
                max_uses INTEGER DEFAULT 1,
                used_count INTEGER DEFAULT 0,
                is_active INTEGER DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Promo usage tracking
        await db.execute("""
            CREATE TABLE IF NOT EXISTS promo_usage (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                code TEXT,
                used_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Pending payments table (for gift tracking)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS pending_payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tg_user_id INTEGER,
                amount INTEGER,
                purpose TEXT DEFAULT 'topup',
                plan_id INTEGER DEFAULT -1,
                status TEXT DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                completed_at TIMESTAMP
            )
        """)

        # Migration: add new columns if they don't exist
        try:
            await db.execute("ALTER TABLE userbots ADD COLUMN plan_id INTEGER DEFAULT 0")
        except:
            pass
        try:
            await db.execute("ALTER TABLE userbots ADD COLUMN login_type TEXT DEFAULT 'api'")
        except:
            pass
        try:
            await db.execute("ALTER TABLE userbots ADD COLUMN nvme_gb INTEGER DEFAULT 5")
        except:
            pass
        try:
            await db.execute("ALTER TABLE userbots ADD COLUMN ram_gb INTEGER DEFAULT 1")
        except:
            pass
        try:
            await db.execute("ALTER TABLE userbots ADD COLUMN cpu_count INTEGER DEFAULT 1")
        except:
            pass
        try:
            await db.execute("ALTER TABLE users ADD COLUMN selected_plan_id INTEGER DEFAULT -1")
        except:
            pass

        await db.commit()
        logger.info("✅ Database initialized successfully")


# ============== USER FUNCTIONS ==============

async def add_user(tg_user_id: int, username: str, full_name: str):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("""
            INSERT OR IGNORE INTO users (tg_user_id, username, full_name)
            VALUES (?, ?, ?)
        """, (tg_user_id, username, full_name))
        await db.execute("""
            UPDATE users SET username = ?, full_name = ?, last_active = CURRENT_TIMESTAMP
            WHERE tg_user_id = ?
        """, (username, full_name, tg_user_id))
        await db.commit()


async def get_user(tg_user_id: int) -> Optional[dict]:
    async with aiosqlite.connect(DB_NAME) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM users WHERE tg_user_id = ?", (tg_user_id,)) as cursor:
            row = await cursor.fetchone()
            return dict(row) if row else None


async def set_user_language(user_id: int, lang: str):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("UPDATE users SET language = ? WHERE tg_user_id = ?", (lang, user_id))
        await db.commit()


async def get_user_language(user_id: int) -> str:
    async with aiosqlite.connect(DB_NAME) as db:
        async with db.execute("SELECT language FROM users WHERE tg_user_id = ?", (user_id,)) as c:
            row = await c.fetchone()
            return row[0] if row else "uz"


async def get_user_balance(tg_user_id: int) -> int:
    user = await get_user(tg_user_id)
    return user["balance"] if user else 0


async def update_balance(tg_user_id: int, amount: int, transaction_type: str, description: str, charge_id: str = None):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("UPDATE users SET balance = balance + ? WHERE tg_user_id = ?", (amount, tg_user_id))
        await db.execute("""
            INSERT INTO transactions (tg_user_id, amount, type, description, charge_id)
            VALUES (?, ?, ?, ?, ?)
        """, (tg_user_id, amount, transaction_type, description, charge_id))
        await db.commit()


# ============== USERBOT FUNCTIONS ==============

async def add_userbot_record(tg_user_id: int, ub_username: str, ub_type: str, port: int,
                              plan_id: int = 0, login_type: str = "api",
                              nvme_gb: int = 5, ram_gb: int = 1, cpu_count: int = 1):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("""
            INSERT INTO userbots (tg_user_id, ub_username, ub_type, port, plan_id, login_type, nvme_gb, ram_gb, cpu_count)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (tg_user_id, ub_username, ub_type, port, plan_id, login_type, nvme_gb, ram_gb, cpu_count))
        await db.commit()


async def get_userbots_by_tg_id(tg_user_id: int) -> list:
    async with aiosqlite.connect(DB_NAME) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM userbots WHERE tg_user_id = ?", (tg_user_id,)) as cursor:
            rows = await cursor.fetchall()
            return [dict(r) for r in rows]


async def get_userbot_data(ub_username: str) -> Optional[dict]:
    async with aiosqlite.connect(DB_NAME) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM userbots WHERE ub_username = ?", (ub_username,)) as cursor:
            row = await cursor.fetchone()
            return dict(row) if row else None


async def update_userbot_status(ub_username: str, status: str):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("UPDATE userbots SET status = ? WHERE ub_username = ?", (status, ub_username))
        await db.commit()


async def delete_userbot_record(ub_username: str):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("DELETE FROM userbots WHERE ub_username = ?", (ub_username,))
        await db.commit()


async def generate_random_port() -> int:
    import random
    async with aiosqlite.connect(DB_NAME) as db:
        while True:
            port = random.randint(10000, 60000)
            async with db.execute("SELECT port FROM userbots WHERE port = ?", (port,)) as c:
                if not await c.fetchone():
                    return port


# ============== PAYMENT FUNCTIONS ==============

async def create_pending_payment(tg_user_id: int, amount: int, purpose: str = "topup", plan_id: int = -1) -> int:
    async with aiosqlite.connect(DB_NAME) as db:
        cursor = await db.execute("""
            INSERT INTO pending_payments (tg_user_id, amount, purpose, plan_id)
            VALUES (?, ?, ?, ?)
        """, (tg_user_id, amount, purpose, plan_id))
        await db.commit()
        return cursor.lastrowid


async def get_pending_payment_by_user(tg_user_id: int) -> Optional[dict]:
    async with aiosqlite.connect(DB_NAME) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT * FROM pending_payments 
            WHERE tg_user_id = ? AND status = 'pending' 
            ORDER BY created_at DESC LIMIT 1
        """, (tg_user_id,)) as cursor:
            row = await cursor.fetchone()
            return dict(row) if row else None


async def complete_pending_payment(payment_id: int):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("""
            UPDATE pending_payments SET status = 'completed', completed_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """, (payment_id,))
        await db.commit()


# ============== ADMIN FUNCTIONS ==============

async def get_all_users() -> list:
    async with aiosqlite.connect(DB_NAME) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM users ORDER BY created_at DESC") as cursor:
            return [dict(r) for r in await cursor.fetchall()]


async def ban_user(user_id: int):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("UPDATE users SET is_banned = 1 WHERE tg_user_id = ?", (user_id,))
        await db.commit()


async def unban_user(user_id: int):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("UPDATE users SET is_banned = 0 WHERE tg_user_id = ?", (user_id,))
        await db.commit()


async def is_user_banned(user_id: int) -> bool:
    async with aiosqlite.connect(DB_NAME) as db:
        async with db.execute("SELECT is_banned FROM users WHERE tg_user_id = ?", (user_id,)) as c:
            row = await c.fetchone()
            return bool(row[0]) if row else False


async def set_user_balance(user_id: int, new_balance: int):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("UPDATE users SET balance = ? WHERE tg_user_id = ?", (new_balance, user_id))
        await db.commit()


async def get_users_paginated(page: int = 1, per_page: int = 10):
    async with aiosqlite.connect(DB_NAME) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT COUNT(*) FROM users") as c:
            total = (await c.fetchone())[0]
        offset = (page - 1) * per_page
        async with db.execute("SELECT * FROM users ORDER BY created_at DESC LIMIT ? OFFSET ?", (per_page, offset)) as c:
            users = [dict(r) for r in await c.fetchall()]
        return users, total


async def get_all_userbots() -> list:
    async with aiosqlite.connect(DB_NAME) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT ub.*, u.username as owner_username, u.full_name as owner_name
            FROM userbots ub LEFT JOIN users u ON ub.tg_user_id = u.tg_user_id
            ORDER BY ub.created_at DESC
        """) as cursor:
            return [dict(r) for r in await cursor.fetchall()]


# ============== PROMO FUNCTIONS ==============

async def create_promo_code(code: str, amount: int, activations: int):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("""
            INSERT INTO promo_codes (code, amount, max_uses, used_count, is_active)
            VALUES (?, ?, ?, 0, 1)
        """, (code, amount, activations))
        await db.commit()


async def redeem_promo_code(user_id: int, code: str) -> int:
    async with aiosqlite.connect(DB_NAME) as db:
        db.row_factory = aiosqlite.Row
        # Check promo exists
        async with db.execute("SELECT * FROM promo_codes WHERE code = ? AND is_active = 1", (code,)) as c:
            promo = await c.fetchone()
            if not promo:
                return 0

        promo = dict(promo)
        # Check usage limit
        if promo["used_count"] >= promo["max_uses"]:
            return 0

        # Check if user already used
        async with db.execute("SELECT id FROM promo_usage WHERE user_id = ? AND code = ?", (user_id, code)) as c:
            if await c.fetchone():
                return -1  # Already used

        # Redeem
        amount = promo["amount"]
        await db.execute("UPDATE promo_codes SET used_count = used_count + 1 WHERE code = ?", (code,))
        await db.execute("INSERT INTO promo_usage (user_id, code) VALUES (?, ?)", (user_id, code))
        await db.execute("UPDATE users SET balance = balance + ? WHERE tg_user_id = ?", (amount, user_id))
        await db.execute("""
            INSERT INTO transactions (tg_user_id, amount, type, description)
            VALUES (?, ?, 'promo', ?)
        """, (user_id, amount, f"Promo: {code}"))
        await db.commit()
        return amount


async def get_all_promo_codes() -> list:
    async with aiosqlite.connect(DB_NAME) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM promo_codes ORDER BY created_at DESC") as c:
            return [dict(r) for r in await c.fetchall()]


async def delete_promo_code(code: str):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("DELETE FROM promo_codes WHERE code = ?", (code,))
        await db.commit()


# ============== STATISTICS FUNCTIONS ==============

async def get_subscription_stats() -> dict:
    async with aiosqlite.connect(DB_NAME) as db:
        stats = {}
        async with db.execute("SELECT COUNT(*) FROM users") as c:
            stats["total_users"] = (await c.fetchone())[0]
        async with db.execute("SELECT COUNT(*) FROM userbots") as c:
            stats["total_bots"] = (await c.fetchone())[0]
        async with db.execute("SELECT COUNT(*) FROM userbots WHERE status = 'running'") as c:
            stats["active_bots"] = (await c.fetchone())[0]
        async with db.execute("SELECT COALESCE(SUM(amount), 0) FROM transactions WHERE type = 'deposit'") as c:
            stats["total_income"] = (await c.fetchone())[0]
        return stats


async def get_income_report(days: int = 30) -> list:
    async with aiosqlite.connect(DB_NAME) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("""
            SELECT DATE(created_at) as date, SUM(amount) as total, COUNT(*) as count
            FROM transactions WHERE type IN ('deposit', 'gift')
            AND created_at >= datetime('now', ?)
            GROUP BY DATE(created_at) ORDER BY date DESC
        """, (f"-{days} days",)) as c:
            return [dict(r) for r in await c.fetchall()]


async def get_user_stats() -> dict:
    async with aiosqlite.connect(DB_NAME) as db:
        stats = {}
        now = datetime.datetime.now()
        today = now.strftime("%Y-%m-%d")
        week_ago = (now - datetime.timedelta(days=7)).strftime("%Y-%m-%d")
        month_ago = (now - datetime.timedelta(days=30)).strftime("%Y-%m-%d")

        async with db.execute("SELECT COUNT(*) FROM users WHERE DATE(created_at) = ?", (today,)) as c:
            stats["today"] = (await c.fetchone())[0]
        async with db.execute("SELECT COUNT(*) FROM users WHERE DATE(created_at) >= ?", (week_ago,)) as c:
            stats["week"] = (await c.fetchone())[0]
        async with db.execute("SELECT COUNT(*) FROM users WHERE DATE(created_at) >= ?", (month_ago,)) as c:
            stats["month"] = (await c.fetchone())[0]
        async with db.execute("SELECT COUNT(*) FROM users") as c:
            stats["total"] = (await c.fetchone())[0]
        return stats


async def search_user(query: str) -> Optional[dict]:
    async with aiosqlite.connect(DB_NAME) as db:
        db.row_factory = aiosqlite.Row
        # Try ID
        try:
            uid = int(query)
            async with db.execute("SELECT * FROM users WHERE tg_user_id = ?", (uid,)) as c:
                row = await c.fetchone()
                if row:
                    return dict(row)
        except ValueError:
            pass
        # Try username
        clean = query.lstrip("@")
        async with db.execute("SELECT * FROM users WHERE username LIKE ?", (f"%{clean}%",)) as c:
            row = await c.fetchone()
            return dict(row) if row else None
