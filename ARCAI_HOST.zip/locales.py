"""
Localization strings for ARCAI HOST
Supports: Uzbek (uz), Russian (ru), English (en)
Premium animated emojis throughout
"""
from typing import Dict

STRINGS = {
    "uz": {
        # Main Menu
        "start_caption": (
            "⚡️ <b>Assalomu alaykum, {name}!</b>\n"
            "━━━━━━━━━━━━━━━━━━\n\n"
            "🔥 Xush kelibsiz <b>ARCAI HOST</b> ga!\n"
            "💎 Premium Telegram Userbot Hosting\n\n"
            "✨ <i>Tez, ishonchli va arzon narxlarda!</i>\n"
            "🚀 Hikka | Heroku — bir tugma bilan!"
        ),
        "btn_create": "➕ Yangi Server",
        "btn_my_bots": "🤖 Serverlarim",
        "btn_topup": "💳 Balans to'ldirish",
        "btn_stats": "📊 Statistika",
        "btn_language": "🌐 Til",
        "btn_manual": "📖 Qo'llanma",
        "btn_back": "◀️ Orqaga",

        # Plans
        "choose_plan": (
            "🎯 <b>Server planini tanlang:</b>\n\n"
            "💎 Har bir plan o'z resurslariga ega\n"
            "⚡️ NVMe disk | 🧠 RAM | 🖥 CPU"
        ),
        "plan_card": "📦 {name}\n💾 {nvme}GB NVMe | 🧠 {ram}GB RAM | 🖥 {cpu} CPU\n💰 {price} ⭐️",
        "btn_plan": "📦 {name} — {price}⭐️",

        # Bot Type
        "choose_type": (
            "🤖 <b>Userbot turini tanlang:</b>\n\n"
            "🔥 <b>Hikka</b> — Professional userbot\n"
            "⚡️ <b>Heroku</b> — Kuchli va tez"
        ),
        "btn_hikka": "🔥 Hikka",
        "btn_heroku": "⚡️ Heroku",

        # Login Method
        "choose_login": (
            "🔐 <b>Login usulini tanlang:</b>\n\n"
            "📱 <b>API Login</b> — API ID + Hash + Telefon\n"
            "📷 <b>QR Code</b> — Kamera bilan skanerlash"
        ),
        "btn_api_login": "📱 API Login",
        "btn_qr_login": "📷 QR Code",

        # API Login Flow
        "enter_api_id": "🔢 <b>API ID ni kiriting:</b>\n\n<i>my.telegram.org dan oling</i>",
        "enter_api_hash": "🔑 <b>API Hash ni kiriting:</b>",
        "enter_phone": "📱 <b>Telefon raqamingizni kiriting:</b>\n\n<i>Masalan: +998901234567</i>",
        "enter_code": "📨 <b>Telegram kodni kiriting:</b>\n\n<i>Telegramga kelgan tasdiqlash kodi</i>",
        "enter_2fa": "🔒 <b>2FA parolni kiriting:</b>",

        # QR Code
        "qr_scan": (
            "📷 <b>QR Kodni skanerlang:</b>\n\n"
            "1️⃣ Telegram → Sozlamalar → Qurilmalar\n"
            "2️⃣ «Qurilma qo'shish» tugmasini bosing\n"
            "3️⃣ Yuqoridagi QR kodni skanerlang\n\n"
            "⏳ <i>Kutilmoqda...</i>"
        ),

        # Installation
        "install_progress": "⏳ <b>O'rnatilmoqda...</b>\n<i>Bu 1-3 daqiqa vaqt olishi mumkin.</i>",
        "install_success": "✅ <b>{bot_type} muvaffaqiyatli o'rnatildi!</b>\n\n📦 Plan: {plan}\n💾 {nvme}GB NVMe | 🧠 {ram}GB RAM | 🖥 {cpu} CPU",
        "install_fail": "❌ <b>Xatolik yuz berdi!</b>\nMablag' qaytarildi.",

        # Balance
        "balance_text": "💰 <b>Balans: {balance} ⭐️</b>",
        "pay_instruction": (
            "💳 <b>Balansni to'ldirish</b>\n\n"
            "🎁 Admin akkauntga <b>{amount} ⭐️</b> Star Gift yuboring\n\n"
            "📱 To'lovdan so'ng avtomatik tekshiriladi!\n"
            "⚡️ Balans darhol tushadi"
        ),
        "btn_send_gift": "🎁 {amount}⭐ Gift Yuborish",
        "payment_received": "✅ <b>To'lov qabul qilindi!</b>\n💰 +{amount} ⭐️ balansga tushdi",
        "payment_waiting": "⏳ <b>To'lov kutilmoqda...</b>\n🎁 {amount} ⭐️ Gift yuboring",

        # Bot Management
        "my_bots_title": "🤖 <b>Sizning serverlaringiz:</b>",
        "no_bots": "📭 Sizda hali server yo'q.\n➕ Yangi server yarating!",
        "bot_card": (
            "🤖 <b>{name}</b>\n"
            "━━━━━━━━━━━━━━━━\n"
            "📦 Tur: {type}\n"
            "💾 {nvme}GB NVMe | 🧠 {ram}GB RAM | 🖥 {cpu} CPU\n"
            "📡 Status: {status}\n"
            "🔐 Login: {login}"
        ),
        "btn_start": "▶️ Ishga tushirish",
        "btn_stop": "⏹ To'xtatish",
        "btn_restart": "🔄 Qayta ishga tushirish",
        "btn_logs": "📜 Loglar",
        "btn_backup": "📦 Backup",
        "btn_delete": "🗑 O'chirish",

        # Deletion
        "delete_confirm": (
            "⚠️ <b>DIQQAT!</b>\n\n"
            "Siz <b>{ub_name}</b> ni o'chirmoqchimisiz?\n\n"
            "❌ Bu amalni qaytarib bo'lmaydi!"
        ),
        "btn_confirm_delete": "🗑 Ha, o'chirish",
        "btn_cancel": "❌ Bekor qilish",
        "delete_success": "✅ <b>{ub_name}</b> muvaffaqiyatli o'chirildi!",

        # Promo
        "promo_success": "✅ <b>Promokod faollashtirildi!</b>\n💰 +{amount} ⭐️ qo'shildi",
        "promo_used": "❌ Siz bu kodni avval ishlatgansiz!",
        "promo_invalid": "❌ Kod yaroqsiz yoki muddati tugagan.",

        # Force Subscribe
        "sub_required": (
            "⚠️ <b>Botdan foydalanish uchun kanalga obuna bo'ling!</b>\n\n"
            "📢 @{channel}"
        ),
        "btn_sub_check": "✅ Tekshirish",
        "sub_not_found": "❌ Siz hali obuna bo'lmagansiz!",

        # Stats
        "stats_text": (
            "📊 <b>Sizning statistikangiz:</b>\n"
            "━━━━━━━━━━━━━━━━\n"
            "💰 Balans: {balance} ⭐️\n"
            "🤖 Serverlar: {bots}\n"
            "📅 Ro'yxatdan o'tgan: {joined}"
        ),

        # Manual
        "manual_text": (
            "📖 <b>ARCAI HOST Qo'llanma</b>\n"
            "━━━━━━━━━━━━━━━━━━\n\n"
            "1️⃣ Plan tanlang (5-20GB)\n"
            "2️⃣ Hikka yoki Heroku ni tanlang\n"
            "3️⃣ API yoki QR code bilan login qiling\n"
            "4️⃣ Avtomatik o'rnatiladi!\n\n"
            "💳 <b>To'lov:</b>\n"
            "🎁 Admin akkauntga Star Gift yuboring\n"
            "⚡️ Balans avtomatik tushadi\n\n"
            "🆘 Yordam: @islomovh"
        ),

        # Errors
        "error_insufficient": "❌ <b>Mablag' yetarli emas!</b>\n💰 Kerak: {needed} ⭐️ | Balans: {balance} ⭐️",
        "error_generic": "❌ Xatolik yuz berdi.",
        "error_max_bots": "❌ Siz maksimal server soniga yetdingiz!",

        # Language
        "lang_selected": "✅ Til o'zgartirildi!",
        "choose_lang": "🌐 <b>Tilni tanlang:</b>",
    },

    "ru": {
        "start_caption": (
            "⚡️ <b>Добрый день, {name}!</b>\n"
            "━━━━━━━━━━━━━━━━━━\n\n"
            "🔥 Добро пожаловать в <b>ARCAI HOST</b>!\n"
            "💎 Премиум хостинг Telegram юзерботов\n\n"
            "✨ <i>Быстро, надёжно и доступно!</i>\n"
            "🚀 Hikka | Heroku — одной кнопкой!"
        ),
        "btn_create": "➕ Новый сервер",
        "btn_my_bots": "🤖 Мои серверы",
        "btn_topup": "💳 Пополнить",
        "btn_stats": "📊 Статистика",
        "btn_language": "🌐 Язык",
        "btn_manual": "📖 Инструкция",
        "btn_back": "◀️ Назад",

        "choose_plan": (
            "🎯 <b>Выберите план сервера:</b>\n\n"
            "💎 Каждый план с уникальными ресурсами\n"
            "⚡️ NVMe диск | 🧠 RAM | 🖥 CPU"
        ),
        "plan_card": "📦 {name}\n💾 {nvme}GB NVMe | 🧠 {ram}GB RAM | 🖥 {cpu} CPU\n💰 {price} ⭐️",
        "btn_plan": "📦 {name} — {price}⭐️",

        "choose_type": (
            "🤖 <b>Выберите тип юзербота:</b>\n\n"
            "🔥 <b>Hikka</b> — Профессиональный юзербот\n"
            "⚡️ <b>Heroku</b> — Мощный и быстрый"
        ),
        "btn_hikka": "🔥 Hikka",
        "btn_heroku": "⚡️ Heroku",

        "choose_login": (
            "🔐 <b>Выберите способ входа:</b>\n\n"
            "📱 <b>API Login</b> — API ID + Hash + Телефон\n"
            "📷 <b>QR Code</b> — Сканируйте камерой"
        ),
        "btn_api_login": "📱 API Login",
        "btn_qr_login": "📷 QR Code",

        "enter_api_id": "🔢 <b>Введите API ID:</b>\n\n<i>Получите на my.telegram.org</i>",
        "enter_api_hash": "🔑 <b>Введите API Hash:</b>",
        "enter_phone": "📱 <b>Введите номер телефона:</b>\n\n<i>Например: +998901234567</i>",
        "enter_code": "📨 <b>Введите код из Telegram:</b>",
        "enter_2fa": "🔒 <b>Введите пароль 2FA:</b>",

        "qr_scan": (
            "📷 <b>Отсканируйте QR код:</b>\n\n"
            "1️⃣ Telegram → Настройки → Устройства\n"
            "2️⃣ Нажмите «Подключить устройство»\n"
            "3️⃣ Отсканируйте QR код выше\n\n"
            "⏳ <i>Ожидание...</i>"
        ),

        "install_progress": "⏳ <b>Установка...</b>\n<i>Это может занять 1-3 минуты.</i>",
        "install_success": "✅ <b>{bot_type} успешно установлен!</b>\n\n📦 План: {plan}\n💾 {nvme}GB NVMe | 🧠 {ram}GB RAM | 🖥 {cpu} CPU",
        "install_fail": "❌ <b>Произошла ошибка!</b>\nСредства возвращены.",

        "balance_text": "💰 <b>Баланс: {balance} ⭐️</b>",
        "pay_instruction": (
            "💳 <b>Пополнение баланса</b>\n\n"
            "🎁 Отправьте <b>{amount} ⭐️</b> Star Gift на аккаунт админа\n\n"
            "📱 Оплата проверяется автоматически!\n"
            "⚡️ Баланс зачисляется мгновенно"
        ),
        "btn_send_gift": "🎁 {amount}⭐ Отправить Gift",
        "payment_received": "✅ <b>Оплата принята!</b>\n💰 +{amount} ⭐️ зачислено",
        "payment_waiting": "⏳ <b>Ожидание оплаты...</b>\n🎁 Отправьте {amount} ⭐️ Gift",

        "my_bots_title": "🤖 <b>Ваши серверы:</b>",
        "no_bots": "📭 У вас пока нет серверов.\n➕ Создайте новый!",
        "bot_card": (
            "🤖 <b>{name}</b>\n"
            "━━━━━━━━━━━━━━━━\n"
            "📦 Тип: {type}\n"
            "💾 {nvme}GB NVMe | 🧠 {ram}GB RAM | 🖥 {cpu} CPU\n"
            "📡 Статус: {status}\n"
            "🔐 Вход: {login}"
        ),
        "btn_start": "▶️ Запустить",
        "btn_stop": "⏹ Остановить",
        "btn_restart": "🔄 Перезапустить",
        "btn_logs": "📜 Логи",
        "btn_backup": "📦 Бэкап",
        "btn_delete": "🗑 Удалить",

        "delete_confirm": (
            "⚠️ <b>ВНИМАНИЕ!</b>\n\n"
            "Вы уверены что хотите удалить <b>{ub_name}</b>?\n\n"
            "❌ Это действие необратимо!"
        ),
        "btn_confirm_delete": "🗑 Да, удалить",
        "btn_cancel": "❌ Отмена",
        "delete_success": "✅ <b>{ub_name}</b> успешно удалён!",

        "promo_success": "✅ <b>Промокод активирован!</b>\n💰 +{amount} ⭐️ добавлено",
        "promo_used": "❌ Вы уже использовали этот код!",
        "promo_invalid": "❌ Код недействителен или истёк.",

        "sub_required": (
            "⚠️ <b>Подпишитесь на канал для использования бота!</b>\n\n"
            "📢 @{channel}"
        ),
        "btn_sub_check": "✅ Проверить",
        "sub_not_found": "❌ Вы ещё не подписаны!",

        "stats_text": (
            "📊 <b>Ваша статистика:</b>\n"
            "━━━━━━━━━━━━━━━━\n"
            "💰 Баланс: {balance} ⭐️\n"
            "🤖 Серверов: {bots}\n"
            "📅 Регистрация: {joined}"
        ),

        "manual_text": (
            "📖 <b>Инструкция ARCAI HOST</b>\n"
            "━━━━━━━━━━━━━━━━━━\n\n"
            "1️⃣ Выберите план (5-20GB)\n"
            "2️⃣ Выберите Hikka или Heroku\n"
            "3️⃣ Войдите через API или QR код\n"
            "4️⃣ Автоматическая установка!\n\n"
            "💳 <b>Оплата:</b>\n"
            "🎁 Отправьте Star Gift на аккаунт админа\n"
            "⚡️ Баланс зачисляется автоматически\n\n"
            "🆘 Поддержка: @islomovh"
        ),

        "error_insufficient": "❌ <b>Недостаточно средств!</b>\n💰 Нужно: {needed} ⭐️ | Баланс: {balance} ⭐️",
        "error_generic": "❌ Произошла ошибка.",
        "error_max_bots": "❌ Достигнут лимит серверов!",

        "lang_selected": "✅ Язык изменён!",
        "choose_lang": "🌐 <b>Выберите язык:</b>",
    },

    "en": {
        "start_caption": (
            "⚡️ <b>Hello, {name}!</b>\n"
            "━━━━━━━━━━━━━━━━━━\n\n"
            "🔥 Welcome to <b>ARCAI HOST</b>!\n"
            "💎 Premium Telegram Userbot Hosting\n\n"
            "✨ <i>Fast, reliable and affordable!</i>\n"
            "🚀 Hikka | Heroku — one click deploy!"
        ),
        "btn_create": "➕ New Server",
        "btn_my_bots": "🤖 My Servers",
        "btn_topup": "💳 Top Up",
        "btn_stats": "📊 Statistics",
        "btn_language": "🌐 Language",
        "btn_manual": "📖 Manual",
        "btn_back": "◀️ Back",

        "choose_plan": (
            "🎯 <b>Choose your server plan:</b>\n\n"
            "💎 Each plan has unique resources\n"
            "⚡️ NVMe disk | 🧠 RAM | 🖥 CPU"
        ),
        "plan_card": "📦 {name}\n💾 {nvme}GB NVMe | 🧠 {ram}GB RAM | 🖥 {cpu} CPU\n💰 {price} ⭐️",
        "btn_plan": "📦 {name} — {price}⭐️",

        "choose_type": (
            "🤖 <b>Choose userbot type:</b>\n\n"
            "🔥 <b>Hikka</b> — Professional userbot\n"
            "⚡️ <b>Heroku</b> — Powerful and fast"
        ),
        "btn_hikka": "🔥 Hikka",
        "btn_heroku": "⚡️ Heroku",

        "choose_login": (
            "🔐 <b>Choose login method:</b>\n\n"
            "📱 <b>API Login</b> — API ID + Hash + Phone\n"
            "📷 <b>QR Code</b> — Scan with camera"
        ),
        "btn_api_login": "📱 API Login",
        "btn_qr_login": "📷 QR Code",

        "enter_api_id": "🔢 <b>Enter API ID:</b>\n\n<i>Get it from my.telegram.org</i>",
        "enter_api_hash": "🔑 <b>Enter API Hash:</b>",
        "enter_phone": "📱 <b>Enter phone number:</b>\n\n<i>Example: +998901234567</i>",
        "enter_code": "📨 <b>Enter Telegram code:</b>",
        "enter_2fa": "🔒 <b>Enter 2FA password:</b>",

        "qr_scan": (
            "📷 <b>Scan the QR Code:</b>\n\n"
            "1️⃣ Telegram → Settings → Devices\n"
            "2️⃣ Tap «Link Desktop Device»\n"
            "3️⃣ Scan the QR code above\n\n"
            "⏳ <i>Waiting...</i>"
        ),

        "install_progress": "⏳ <b>Installing...</b>\n<i>This may take 1-3 minutes.</i>",
        "install_success": "✅ <b>{bot_type} installed successfully!</b>\n\n📦 Plan: {plan}\n💾 {nvme}GB NVMe | 🧠 {ram}GB RAM | 🖥 {cpu} CPU",
        "install_fail": "❌ <b>An error occurred!</b>\nFunds refunded.",

        "balance_text": "💰 <b>Balance: {balance} ⭐️</b>",
        "pay_instruction": (
            "💳 <b>Top Up Balance</b>\n\n"
            "🎁 Send <b>{amount} ⭐️</b> Star Gift to admin account\n\n"
            "📱 Payment is verified automatically!\n"
            "⚡️ Balance added instantly"
        ),
        "btn_send_gift": "🎁 {amount}⭐ Send Gift",
        "payment_received": "✅ <b>Payment received!</b>\n💰 +{amount} ⭐️ added to balance",
        "payment_waiting": "⏳ <b>Waiting for payment...</b>\n🎁 Send {amount} ⭐️ Gift",

        "my_bots_title": "🤖 <b>Your servers:</b>",
        "no_bots": "📭 You don't have any servers yet.\n➕ Create a new one!",
        "bot_card": (
            "🤖 <b>{name}</b>\n"
            "━━━━━━━━━━━━━━━━\n"
            "📦 Type: {type}\n"
            "💾 {nvme}GB NVMe | 🧠 {ram}GB RAM | 🖥 {cpu} CPU\n"
            "📡 Status: {status}\n"
            "🔐 Login: {login}"
        ),
        "btn_start": "▶️ Start",
        "btn_stop": "⏹ Stop",
        "btn_restart": "🔄 Restart",
        "btn_logs": "📜 Logs",
        "btn_backup": "📦 Backup",
        "btn_delete": "🗑 Delete",

        "delete_confirm": (
            "⚠️ <b>WARNING!</b>\n\n"
            "Are you sure you want to delete <b>{ub_name}</b>?\n\n"
            "❌ This action cannot be undone!"
        ),
        "btn_confirm_delete": "🗑 Yes, delete",
        "btn_cancel": "❌ Cancel",
        "delete_success": "✅ <b>{ub_name}</b> deleted successfully!",

        "promo_success": "✅ <b>Promo code activated!</b>\n💰 +{amount} ⭐️ added",
        "promo_used": "❌ You already used this code!",
        "promo_invalid": "❌ Code is invalid or expired.",

        "sub_required": (
            "⚠️ <b>Please subscribe to use the bot!</b>\n\n"
            "📢 @{channel}"
        ),
        "btn_sub_check": "✅ Check",
        "sub_not_found": "❌ You haven't subscribed yet!",

        "stats_text": (
            "📊 <b>Your Statistics:</b>\n"
            "━━━━━━━━━━━━━━━━\n"
            "💰 Balance: {balance} ⭐️\n"
            "🤖 Servers: {bots}\n"
            "📅 Joined: {joined}"
        ),

        "manual_text": (
            "📖 <b>ARCAI HOST Manual</b>\n"
            "━━━━━━━━━━━━━━━━━━\n\n"
            "1️⃣ Choose a plan (5-20GB)\n"
            "2️⃣ Select Hikka or Heroku\n"
            "3️⃣ Login via API or QR code\n"
            "4️⃣ Automatic installation!\n\n"
            "💳 <b>Payment:</b>\n"
            "🎁 Send Star Gift to admin account\n"
            "⚡️ Balance added automatically\n\n"
            "🆘 Support: @islomovh"
        ),

        "error_insufficient": "❌ <b>Insufficient balance!</b>\n💰 Required: {needed} ⭐️ | Balance: {balance} ⭐️",
        "error_generic": "❌ An error occurred.",
        "error_max_bots": "❌ Server limit reached!",

        "lang_selected": "✅ Language changed!",
        "choose_lang": "🌐 <b>Choose language:</b>",
    }
}


def get_text(key: str, lang: str = "uz", **kwargs) -> str:
    """Get localized text by key"""
    lang_dict = STRINGS.get(lang, STRINGS["uz"])
    text = lang_dict.get(key, STRINGS["uz"].get(key, f"[{key}]"))
    if kwargs:
        try:
            text = text.format(**kwargs)
        except (KeyError, IndexError):
            pass
    return text
