import asyncio
from aiohttp import web
import aiohttp
import database as db
from config_manager import config

# Simple Reverse Proxy for WebUI
# Maps http://bot-id.domain.com -> localhost:port

async def handle(request):
    host = request.headers.get('Host', '')
    
    # Logic: extract bot name from subdomain (e.g. ub_123_456.host.com)
    # OR use path: host.com/ub_123_456/
    
    # Let's use path for simplicity in this script, assuming user hits /web/ub_123_456/
    
    path = request.match_info.get('path', '')
    bot_name = request.match_info.get('bot_name', '')
    
    if not bot_name:
        return web.Response(text="Bot name not found")

    # Lookup port in DB
    bot_data = await db.get_userbot_data(bot_name)
    if not bot_data:
        return web.Response(text="Bot not found", status=404)
        
    port = bot_data['port']
    target_url = f"http://localhost:{port}/{path}"
    
    try:
        async with aiohttp.ClientSession() as session:
            # Proxy the method, headers, and body
            async with session.request(
                request.method,
                target_url,
                headers=request.headers,
                data=await request.read()
            ) as resp:
                body = await resp.read()
                return web.Response(body=body, status=resp.status, headers=resp.headers)
    except Exception as e:
        return web.Response(text=f"Proxy Error: {e}", status=502)

app = web.Application()
app.router.add_route('*', '/web/{bot_name}/{path:.*}', handle)

if __name__ == '__main__':
    web.run_app(app, port=8080)
