import json
import os

CONFIG_FILE = "config.json"

class _Config:
    def __init__(self):
        self._load()

    def _load(self):
        if not os.path.exists(CONFIG_FILE):
            print(f"⚠️ {CONFIG_FILE} topilmadi. config.example.json dan nusxa oling!")
            default_config = {
                "bot_token": "",
                "admin_ids": [],
                "log_channel_id": None,
                "dev_mode": False,
                "test_mode": False,
                "bot_name": "ARCAI HOST",
                "force_sub_channel": "arcaiuser",
                "api_id": 0,
                "api_hash": "",
                "gift_amount": 50,
                "server_plans": []
            }
            with open(CONFIG_FILE, "w") as f:
                json.dump(default_config, f, indent=4)

        with open(CONFIG_FILE, "r") as f:
            self._config = json.load(f)

        # Core
        self.BOT_TOKEN = self._config.get("bot_token", "")
        self.ADMIN_IDS = self._config.get("admin_ids", [])
        self.LOG_CHANNEL_ID = self._config.get("log_channel_id")
        self.DEV_MODE = self._config.get("dev_mode", False)
        self.TEST_MODE = self._config.get("test_mode", False)

        # Branding
        self.BOT_NAME = self._config.get("bot_name", "ARCAI HOST")
        self.FORCE_SUB_CHANNEL = self._config.get("force_sub_channel", "arcaiuser")

        # Payment / Pyrogram
        self.API_ID = self._config.get("api_id", 0)
        self.API_HASH = self._config.get("api_hash", "")
        self.GIFT_AMOUNT = self._config.get("gift_amount", 50)

        # Server Plans
        self.SERVER_PLANS = self._config.get("server_plans", [])

    def get_plan(self, index: int) -> dict:
        if 0 <= index < len(self.SERVER_PLANS):
            return self.SERVER_PLANS[index]
        return None

    def save(self):
        with open(CONFIG_FILE, "w") as f:
            json.dump(self._config, f, indent=4, ensure_ascii=False)

config = _Config()
