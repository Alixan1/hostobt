"""
ARCAI HOST — Admin Panel Handlers
Features: 10+ functions, server stats, user management, broadcast, promo codes, income reports
"""
from aiogram import Router, F, types
from aiogram.filters import Command, StateFilter
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
import psutil
import database as db
from config_manager import config
from process_manager import process_manager
from payment_checker import payment_checker
import logging
import asyncio

logger = logging.getLogger(__name__)
router = Router()


class AdminStates(StatesGroup):
    waiting_broadcast_text = State()
    waiting_broadcast_media = State()
    waiting_promo_code = State()
    waiting_promo_amount = State()
    waiting_promo_uses = State()
    waiting_user_search = State()
    waiting_balance_amount = State()
    waiting_manual_payment_user = State()
    waiting_manual_payment_amount = State()


def is_admin(user_id: int) -> bool:
    return user_id in config.ADMIN_IDS


# ============== ADMIN PANEL ENTRY ==============

@router.message(Command("admin"))
async def cmd_admin_panel(message: Message):
    if not is_admin(message.from_user.id):
        return
    await show_admin_menu(message)


async def show_admin_menu(message_or_call, edit: bool = False):
    text = (
        "⚡️ <b>ARCAI HOST — Admin Panel</b>\n"
        "━━━━━━━━━━━━━━━━━━\n\n"
        "🔧 Quyidagi funksiyalardan birini tanlang:"
    )

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🖥 Server", callback_data="adm_server"),
            InlineKeyboardButton(text="📊 Statistika", callback_data="adm_stats"),
        ],
        [
            InlineKeyboardButton(text="👥 Foydalanuvchilar", callback_data="adm_users"),
            InlineKeyboardButton(text="🔍 Qidirish", callback_data="adm_search"),
        ],
        [
            InlineKeyboardButton(text="🤖 Botlar", callback_data="adm_bots"),
            InlineKeyboardButton(text="📢 Broadcast", callback_data="adm_broadcast"),
        ],
        [
            InlineKeyboardButton(text="🎁 Promokodlar", callback_data="adm_promos"),
            InlineKeyboardButton(text="💰 Daromad", callback_data="adm_income"),
        ],
        [
            InlineKeyboardButton(text="💳 Manual to'lov", callback_data="adm_manual_pay"),
        ],
        [InlineKeyboardButton(text="❌ Yopish", callback_data="adm_close")]
    ])

    if isinstance(message_or_call, CallbackQuery):
        try:
            await message_or_call.message.edit_text(text, reply_markup=kb)
        except:
            await message_or_call.message.answer(text, reply_markup=kb)
    else:
        await message_or_call.answer(text, reply_markup=kb)


# ============== 1. SERVER STATUS ==============

@router.callback_query(F.data == "adm_server")
async def cb_admin_server(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return

    cpu_percent = psutil.cpu_percent(interval=1)
    ram = psutil.virtual_memory()
    disk = psutil.disk_usage("/")

    def bar(percent, length=10):
        filled = int(length * percent / 100)
        return "█" * filled + "▒" * (length - filled)

    text = (
        "🖥 <b>ARCAI HOST — Server Ma'lumotlari</b>\n"
        "━━━━━━━━━━━━━━━━━━\n\n"
        f"🔥 <b>CPU:</b> {cpu_percent}%\n"
        f"<code>[{bar(cpu_percent)}]</code>\n\n"
        f"🧠 <b>RAM:</b> {ram.used // (1024**3):.1f}GB / {ram.total // (1024**3):.1f}GB ({ram.percent}%)\n"
        f"<code>[{bar(ram.percent)}]</code>\n\n"
        f"💾 <b>Disk:</b> {disk.used // (1024**3):.1f}GB / {disk.total // (1024**3):.1f}GB ({disk.percent}%)\n"
        f"<code>[{bar(disk.percent)}]</code>\n\n"
        f"⚡️ <b>Uptime:</b> {_get_uptime()}"
    )

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="◀️ Orqaga", callback_data="adm_main")]
    ])
    await call.message.edit_text(text, reply_markup=kb)


def _get_uptime():
    import time
    boot = psutil.boot_time()
    uptime_s = time.time() - boot
    days = int(uptime_s // 86400)
    hours = int((uptime_s % 86400) // 3600)
    mins = int((uptime_s % 3600) // 60)
    return f"{days}d {hours}h {mins}m"


# ============== 2. STATISTICS ==============

@router.callback_query(F.data == "adm_stats")
async def cb_admin_stats(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return

    stats = await db.get_subscription_stats()
    user_stats = await db.get_user_stats()

    text = (
        "📊 <b>ARCAI HOST — Statistika</b>\n"
        "━━━━━━━━━━━━━━━━━━\n\n"
        f"👥 <b>Foydalanuvchilar:</b>\n"
        f"   📅 Bugun: {user_stats.get('today', 0)}\n"
        f"   📆 Hafta: {user_stats.get('week', 0)}\n"
        f"   📆 Oy: {user_stats.get('month', 0)}\n"
        f"   📊 Jami: {user_stats.get('total', 0)}\n\n"
        f"🤖 <b>Serverlar:</b>\n"
        f"   🟢 Aktiv: {stats.get('active_bots', 0)}\n"
        f"   📊 Jami: {stats.get('total_bots', 0)}\n\n"
        f"💰 <b>Umumiy daromad:</b> {stats.get('total_income', 0)} ⭐️"
    )

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="◀️ Orqaga", callback_data="adm_main")]
    ])
    await call.message.edit_text(text, reply_markup=kb)


# ============== 3. USERS MANAGEMENT ==============

@router.callback_query(F.data == "adm_users")
async def cb_admin_users(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return

    users, total = await db.get_users_paginated(page=1, per_page=10)

    text = f"👥 <b>Foydalanuvchilar</b> ({total} ta)\n━━━━━━━━━━━━━━━━\n\n"
    for u in users:
        status = "🚫" if u.get("is_banned") else "✅"
        username = f"@{u['username']}" if u.get('username') else "—"
        text += f"{status} <code>{u['tg_user_id']}</code> | {username} | 💰{u.get('balance', 0)}⭐\n"

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="◀️ Orqaga", callback_data="adm_main")]
    ])
    await call.message.edit_text(text, reply_markup=kb)


# ============== 4. USER SEARCH ==============

@router.callback_query(F.data == "adm_search")
async def cb_admin_search(call: CallbackQuery, state: FSMContext):
    if not is_admin(call.from_user.id):
        return

    await state.set_state(AdminStates.waiting_user_search)
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="❌ Bekor qilish", callback_data="adm_main")]
    ])
    await call.message.edit_text(
        "🔍 <b>Foydalanuvchi ID yoki @username ni kiriting:</b>",
        reply_markup=kb
    )


@router.message(AdminStates.waiting_user_search)
async def process_user_search(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return

    user = await db.search_user(message.text.strip())
    await state.clear()

    if not user:
        await message.answer("❌ Foydalanuvchi topilmadi!")
        return

    await show_user_profile(message, user)


async def show_user_profile(message_or_call, user: dict, edit: bool = False):
    uid = user["tg_user_id"]
    bots = await db.get_userbots_by_tg_id(uid)
    ban_status = "🚫 Bloklangan" if user.get("is_banned") else "✅ Faol"

    text = (
        f"👤 <b>Foydalanuvchi profili</b>\n"
        f"━━━━━━━━━━━━━━━━\n\n"
        f"🆔 ID: <code>{uid}</code>\n"
        f"👤 Ism: {user.get('full_name', '—')}\n"
        f"📱 Username: @{user.get('username', '—')}\n"
        f"💰 Balans: {user.get('balance', 0)} ⭐️\n"
        f"🌐 Til: {user.get('language', 'uz')}\n"
        f"📡 Status: {ban_status}\n"
        f"🤖 Serverlar: {len(bots)}\n"
        f"📅 Ro'yxatdan: {str(user.get('created_at', ''))[:10]}"
    )

    ban_text = "🔓 Blokdan chiqarish" if user.get("is_banned") else "🚫 Bloklash"
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text=ban_text, callback_data=f"adm_ban_{uid}"),
            InlineKeyboardButton(text="💰 Balans", callback_data=f"adm_setbal_{uid}"),
        ],
        [InlineKeyboardButton(text="◀️ Orqaga", callback_data="adm_main")]
    ])

    if isinstance(message_or_call, CallbackQuery):
        await message_or_call.message.edit_text(text, reply_markup=kb)
    else:
        await message_or_call.answer(text, reply_markup=kb)


@router.callback_query(F.data.startswith("adm_ban_"))
async def cb_toggle_ban(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return

    uid = int(call.data[8:])
    user = await db.get_user(uid)
    if not user:
        await call.answer("❌ Topilmadi!", show_alert=True)
        return

    if user.get("is_banned"):
        await db.unban_user(uid)
        await call.answer(f"✅ {uid} blokdan chiqarildi!", show_alert=True)
    else:
        await db.ban_user(uid)
        await call.answer(f"🚫 {uid} bloklandi!", show_alert=True)

    user = await db.get_user(uid)
    await show_user_profile(call, user, edit=True)


@router.callback_query(F.data.startswith("adm_setbal_"))
async def cb_set_balance(call: CallbackQuery, state: FSMContext):
    if not is_admin(call.from_user.id):
        return

    uid = int(call.data[11:])
    await state.update_data(target_uid=uid)
    await state.set_state(AdminStates.waiting_balance_amount)
    await call.message.edit_text(f"💰 <b>{uid}</b> uchun yangi balansni kiriting:")


@router.message(AdminStates.waiting_balance_amount)
async def process_balance_set(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return

    try:
        amount = int(message.text.strip())
        data = await state.get_data()
        uid = data.get("target_uid")
        await db.set_user_balance(uid, amount)
        await message.answer(f"✅ {uid} balansi: {amount} ⭐️")
    except ValueError:
        await message.answer("❌ Faqat raqam kiriting!")
    await state.clear()


# ============== 5. USERBOTS MANAGEMENT ==============

@router.callback_query(F.data == "adm_bots")
async def cb_admin_bots(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return

    bots = await db.get_all_userbots()
    if not bots:
        await call.message.edit_text("📭 Hech qanday server yo'q.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="◀️ Orqaga", callback_data="adm_main")]
            ]))
        return

    text = f"🤖 <b>Barcha serverlar</b> ({len(bots)} ta)\n━━━━━━━━━━━━━━━━\n\n"
    for b in bots[:15]:
        status = "🟢" if b.get("status") == "running" else "🔴"
        owner = f"@{b.get('owner_username', '?')}" if b.get('owner_username') else str(b.get('tg_user_id', '?'))
        text += (f"{status} <b>{b['ub_username']}</b> ({b.get('ub_type', '?')})\n"
                 f"   💾{b.get('nvme_gb', '?')}GB | 🧠{b.get('ram_gb', '?')}GB | 🖥{b.get('cpu_count', '?')}CPU | 👤{owner}\n")

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="◀️ Orqaga", callback_data="adm_main")]
    ])
    await call.message.edit_text(text, reply_markup=kb)


# ============== 6. BROADCAST ==============

@router.callback_query(F.data == "adm_broadcast")
async def cb_admin_broadcast(call: CallbackQuery, state: FSMContext):
    if not is_admin(call.from_user.id):
        return

    await state.set_state(AdminStates.waiting_broadcast_text)
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="❌ Bekor qilish", callback_data="adm_main")]
    ])
    await call.message.edit_text(
        "📢 <b>Broadcast xabarini yuboring:</b>\n\n<i>Matn, rasm yoki video yuboring</i>",
        reply_markup=kb
    )


@router.message(AdminStates.waiting_broadcast_text)
async def process_broadcast(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return

    await state.clear()
    users = await db.get_all_users()
    sent = 0
    failed = 0
    status_msg = await message.answer(f"📢 Broadcast boshlandi... (0/{len(users)})")

    for i, user in enumerate(users):
        try:
            if message.photo:
                await message.bot.send_photo(
                    user["tg_user_id"],
                    photo=message.photo[-1].file_id,
                    caption=message.caption or ""
                )
            elif message.video:
                await message.bot.send_video(
                    user["tg_user_id"],
                    video=message.video.file_id,
                    caption=message.caption or ""
                )
            else:
                await message.bot.send_message(user["tg_user_id"], message.text or "")
            sent += 1
        except Exception:
            failed += 1

        if (i + 1) % 20 == 0:
            try:
                await status_msg.edit_text(f"📢 Broadcast: {sent}/{len(users)} (❌{failed})")
            except:
                pass
            await asyncio.sleep(0.5)

    await status_msg.edit_text(
        f"✅ <b>Broadcast tugadi!</b>\n\n"
        f"📤 Yuborildi: {sent}\n"
        f"❌ Xato: {failed}\n"
        f"📊 Jami: {len(users)}"
    )


# ============== 7. PROMO CODES ==============

@router.callback_query(F.data == "adm_promos")
async def cb_admin_promos(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return

    promos = await db.get_all_promo_codes()
    text = "🎁 <b>Promokodlar</b>\n━━━━━━━━━━━━━━━━\n\n"

    if promos:
        for p in promos:
            status = "✅" if p.get("is_active") else "❌"
            text += f"{status} <code>{p['code']}</code> | 💰{p['amount']}⭐ | {p.get('used_count', 0)}/{p.get('max_uses', 1)}\n"
    else:
        text += "📭 Hech qanday promokod yo'q.\n"

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ Yangi promo", callback_data="adm_promo_new")],
        [InlineKeyboardButton(text="◀️ Orqaga", callback_data="adm_main")]
    ])
    await call.message.edit_text(text, reply_markup=kb)


@router.callback_query(F.data == "adm_promo_new")
async def cb_promo_new(call: CallbackQuery, state: FSMContext):
    if not is_admin(call.from_user.id):
        return

    await state.set_state(AdminStates.waiting_promo_code)
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="❌ Bekor qilish", callback_data="adm_promos")]
    ])
    await call.message.edit_text("🎁 <b>Promokod nomini kiriting:</b>", reply_markup=kb)


@router.message(AdminStates.waiting_promo_code)
async def process_promo_code(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    await state.update_data(promo_code=message.text.strip())
    await state.set_state(AdminStates.waiting_promo_amount)
    await message.answer("💰 <b>Promo miqdorini kiriting (Stars):</b>")


@router.message(AdminStates.waiting_promo_amount)
async def process_promo_amount(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    try:
        amount = int(message.text.strip())
        if amount <= 0:
            raise ValueError
        await state.update_data(promo_amount=amount)
        await state.set_state(AdminStates.waiting_promo_uses)
        await message.answer("🔢 <b>Nechta foydalanuvchi ishlatishi mumkin?</b>")
    except ValueError:
        await message.answer("❌ Musbat raqam kiriting!")


@router.message(AdminStates.waiting_promo_uses)
async def process_promo_uses(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    try:
        uses = int(message.text.strip())
        if uses <= 0:
            raise ValueError
        data = await state.get_data()
        code = data["promo_code"]
        amount = data["promo_amount"]

        await db.create_promo_code(code, amount, uses)
        await state.clear()
        await message.answer(
            f"✅ <b>Promokod yaratildi!</b>\n\n"
            f"🎁 Kod: <code>{code}</code>\n"
            f"💰 Miqdor: {amount} ⭐️\n"
            f"🔢 Limitlar: {uses} ta"
        )
    except ValueError:
        await message.answer("❌ Musbat raqam kiriting!")


# ============== 8. INCOME REPORT ==============

@router.callback_query(F.data == "adm_income")
async def cb_admin_income(call: CallbackQuery):
    if not is_admin(call.from_user.id):
        return

    report = await db.get_income_report(30)
    stats = await db.get_subscription_stats()

    text = (
        "💰 <b>Daromad hisoboti (30 kun)</b>\n"
        "━━━━━━━━━━━━━━━━\n\n"
        f"📊 Umumiy: <b>{stats.get('total_income', 0)} ⭐️</b>\n\n"
    )

    if report:
        for r in report[:10]:
            text += f"📅 {r.get('date', '?')} | 💰 {r.get('total', 0)}⭐ ({r.get('count', 0)} ta)\n"
    else:
        text += "📭 Hali tranzaksiyalar yo'q.\n"

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="◀️ Orqaga", callback_data="adm_main")]
    ])
    await call.message.edit_text(text, reply_markup=kb)


# ============== 9. MANUAL PAYMENT ==============

@router.callback_query(F.data == "adm_manual_pay")
async def cb_manual_payment(call: CallbackQuery, state: FSMContext):
    if not is_admin(call.from_user.id):
        return

    await state.set_state(AdminStates.waiting_manual_payment_user)
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="❌ Bekor qilish", callback_data="adm_main")]
    ])
    await call.message.edit_text(
        "💳 <b>To'lov qo'shish</b>\n\n"
        "👤 Foydalanuvchi ID sini kiriting:",
        reply_markup=kb
    )


@router.message(AdminStates.waiting_manual_payment_user)
async def process_manual_pay_user(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    try:
        uid = int(message.text.strip())
        user = await db.get_user(uid)
        if not user:
            await message.answer("❌ Foydalanuvchi topilmadi!")
            return
        await state.update_data(pay_uid=uid)
        await state.set_state(AdminStates.waiting_manual_payment_amount)
        await message.answer(f"💰 <b>{uid}</b> ga qancha Stars qo'shish kerak?")
    except ValueError:
        await message.answer("❌ Faqat raqam kiriting!")


@router.message(AdminStates.waiting_manual_payment_amount)
async def process_manual_pay_amount(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    try:
        amount = int(message.text.strip())
        if amount <= 0:
            raise ValueError
        data = await state.get_data()
        uid = data["pay_uid"]

        if payment_checker:
            await payment_checker.manual_confirm(message.from_user.id, uid, amount)
        else:
            await db.update_balance(uid, amount, "manual", f"Admin: {amount}⭐")

        await state.clear()
        await message.answer(f"✅ {uid} ga {amount} ⭐️ qo'shildi!")
    except ValueError:
        await message.answer("❌ Musbat raqam kiriting!")


# ============== NAVIGATION ==============

@router.callback_query(F.data == "adm_main")
async def cb_admin_main(call: CallbackQuery, state: FSMContext):
    if not is_admin(call.from_user.id):
        return
    await state.clear()
    await show_admin_menu(call)


@router.callback_query(F.data == "adm_close")
async def cb_admin_close(call: CallbackQuery, state: FSMContext):
    await state.clear()
    await call.message.delete()


@router.callback_query(F.data == "adm_noop")
async def cb_noop(call: CallbackQuery):
    await call.answer()
