#!/bin/bash
# Install script for Mini Userbot Host dependencies

echo "Installing system dependencies..."
apt-get update
apt-get install -y python3 python3-pip python3-venv git screen

# echo "Checking Docker..." 
# Docker is no longer required for this version
# systemctl start docker
# systemctl enable docker

echo "Setting up Python environment..."
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

echo "Setup complete! Run 'python3 bot.py' to start."
