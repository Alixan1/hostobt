# ARCAI HOST ⚡️

<p align="center">
  <img src="assets/banner.jpg" alt="ARCAI HOST Banner" width="600">
</p>

**Premium Telegram Userbot Hosting Platform** — Hikka & Heroku one-click deploy!

## ✨ Features

### 🚀 Server Plans
| Plan | NVMe | RAM | CPU | Price |
|------|------|-----|-----|-------|
| 📦 Starter | 5GB | 1GB | 1 | 50⭐ |
| 📦 Standard | 10GB | 2GB | 2 | 100⭐ |
| 📦 Pro | 15GB | 3GB | 3 | 150⭐ |
| 📦 Ultra | 20GB | 4GB | 4 | 200⭐ |

### 👤 User Features
- ➕ Create Heroku/Hikka userbots
- 🔐 Login: API (ID+Hash+Phone) or QR Code
- 🎛 Control panel (Start/Stop/Restart/Logs)
- 📦 Backup & Restore
- 🌐 Multi-language (Uzbek, Russian, English)
- 💰 Telegram Stars balance system
- 🎁 Auto payment via Star Gifts
- ✨ Animated premium emojis

### 🔧 Admin Features (10+)
- 🖥 Server monitoring (CPU/RAM/Disk)
- 📊 User statistics & income reports
- 👥 User management (ban/unban/balance)
- 💳 Manual payment confirmation
- 🤖 Userbot management
- 📢 Broadcast (text/photo/video)
- 🎁 Promo code CRUD
- 🔍 User search

## 🚀 Quick Start

```bash
git clone https://github.com/your-repo/arcai-host.git
cd arcai-host
pip install -r requirements.txt
```

### Configuration

Copy `config.example.json` to `config.json` and fill in:

```json
{
    "bot_token": "YOUR_BOT_TOKEN",
    "admin_ids": [YOUR_TELEGRAM_ID],
    "api_id": YOUR_API_ID,
    "api_hash": "YOUR_API_HASH"
}
```

### Run

```bash
python bot.py
```

## 📁 Project Structure

```
arcai-host/
├── bot.py               # Entry point
├── config.json          # Bot configuration
├── config_manager.py    # Config loader
├── database.py          # SQLite database
├── locales.py           # i18n (3 languages)
├── user_handlers.py     # User panel
├── admin_handlers.py    # Admin panel (10+ funcs)
├── payment_checker.py   # Auto Star Gift detection
├── bot_installer.py     # Userbot installation
├── process_manager.py   # Process lifecycle
├── backup_manager.py    # Backup/restore
├── assets/
│   └── banner.jpg       # ARCAI HOST banner
├── requirements.txt
└── .gitignore
```

## 📝 License

MIT License

## 👨‍💻 Author

Made with ⚡️ by ARCAI HOST Team
