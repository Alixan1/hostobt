import asyncio
import logging
import sys
from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties
from config_manager import config
import database as db
import user_handlers
import admin_handlers
from payment_checker import PaymentChecker
import payment_checker as pc_module

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(name)s | %(levelname)s | %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("logs/bot.log", encoding="utf-8")
    ]
)
logger = logging.getLogger(__name__)


async def main():
    # Initialize Database
    await db.init_db()
    logger.info("✅ Database initialized")

    # Initialize Bot
    bot = Bot(token=config.BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()

    # Initialize Payment Checker
    checker = PaymentChecker(bot, config)
    pc_module.payment_checker = checker

    # Startup Notification
    if config.ADMIN_IDS:
        try:
            plans_info = ""
            for i, p in enumerate(config.SERVER_PLANS):
                plans_info += f"\n   📦 {p['name']}: {p['nvme_gb']}GB/{p['ram_gb']}GB/{p['cpu_count']}CPU — {p['price_stars']}⭐"

            await bot.send_message(
                config.ADMIN_IDS[0],
                f"⚡️ <b>ARCAI HOST ishga tushdi!</b>\n"
                f"━━━━━━━━━━━━━━━━\n\n"
                f"🤖 Bot: @{(await bot.get_me()).username}\n"
                f"📦 Planlar:{plans_info}\n"
                f"💰 Gift miqdori: {config.GIFT_AMOUNT}⭐\n"
                f"📢 Kanal: @{config.FORCE_SUB_CHANNEL}\n\n"
                f"✅ Barcha tizimlar tayyor!"
            )
        except Exception as e:
            logger.warning(f"Could not send startup message: {e}")

    # Include Routers
    dp.include_router(user_handlers.router)
    dp.include_router(admin_handlers.router)

    # Start Payment Checker as background task
    asyncio.create_task(checker.start_monitoring())

    # Delete Webhook (if any) and start polling
    await bot.delete_webhook(drop_pending_updates=True)
    logger.info("⚡️ ARCAI HOST started polling...")
    await dp.start_polling(bot)


if __name__ == "__main__":
    # Ensure logs directory exists
    import os
    os.makedirs("logs", exist_ok=True)

    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logger.info("Bot stopped!")
